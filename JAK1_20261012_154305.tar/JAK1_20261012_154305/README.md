# JAK1_20261012_154305

JAK1 (P23458) window 569–1154, model_1, guided recycling (w=0.1, recycling fix: continue from best state), MSA 32/64.

- recycles: **30**, seeds: **5** (0..4), runtime 13.6 min
- openness = JH2–JH1 Cα-centroid distance (pipeline functions); references JAK1: open ma-a1sai 46.05 Å, closed ma-l9b1f 39.53 Å
- selected open: seed 1 (58.03 Å) → `selected_open.pdb`
- selected closed: seed 3 (54.84 Å) → `selected_closed.pdb`
- selected structures per seed: openness 54.84–58.03 Å
- `all/`: 150 conformations (every seed × every recycle) as gzip PDB (`all/seed_XXX/recycle_NN.pdb.gz`, `selected.pdb.gz` = recycle chosen by J), traces per seed, `all/index.csv` (openness, pLDDT, J per conformation)
