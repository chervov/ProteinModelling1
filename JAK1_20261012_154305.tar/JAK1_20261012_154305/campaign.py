#!/usr/bin/env python
"""
JAK1 JH2–JH1 guided-recycling campaign (runs detached inside the sandbox).

For every (recycles, seeds) setting:
  1. run the OpenFold guided-recycling runner (same command as the notebook)
     into its own folder -> nothing from earlier launches is mixed in;
  2. collect every conformation (all seeds x all recycles) into
       /content/protein_predictions/runs/JAK1_<YYYYmmdd_HHMMSS>/
         selected_open.pdb, selected_closed.pdb, selection_report.json,
         run_config.json, domain_ranges.json, experiment_config.json, README.md
         all/index.csv, all/seed_XXX/recycle_NN.pdb.gz, selected.pdb.gz, traces
  3. push that folder to GitHub: <repo>/Pr/JAK1_<YYYYmmdd_HHMMSS>/ (branch master).
Progress: /content/campaign/campaign.log and /content/campaign/status.json
"""
import ast, csv, datetime, gzip, json, os, re, shutil, subprocess, sys, time, traceback, typing
import numpy as np

CFG = json.load(open(sys.argv[1]))
TOKEN = os.environ.get("GITHUB_TOKEN", "")
ROOT = "/content/campaign"
STATUS = os.path.join(ROOT, "status.json")

def log(msg):
    print(f"[{datetime.datetime.now():%Y-%m-%d %H:%M:%S}] {msg}", flush=True)

def save_status(status):
    with open(STATUS + ".tmp", "w") as f:
        json.dump(status, f, indent=2)
    os.replace(STATUS + ".tmp", STATUS)

# ---- openness exactly as in the pipeline (runner's own functions)
_ns = {"np": np, "Dict": typing.Dict, "List": typing.List, "Optional": typing.Optional}
for node in ast.parse(open(CFG["runner"]).read()).body:
    if isinstance(node, ast.FunctionDef) and node.name in ("_parse_pdb_ca_coords", "_centroid_for_ranges"):
        exec(compile(ast.Module([node], []), CFG["runner"], "exec"), _ns)
_spec = json.load(open(CFG["domain_json"]))
_d1, _d2 = _spec["openness_metric"]["domain1"], _spec["openness_metric"]["domain2"]

def openness(pdb_path):
    c = _ns["_parse_pdb_ca_coords"](pdb_path, chain_id=_spec.get("chain_id"))
    return float(np.linalg.norm(_ns["_centroid_for_ranges"](c, _spec["domains"][_d1])
                                - _ns["_centroid_for_ranges"](c, _spec["domains"][_d2])))

def mean_plddt(pdb_path):
    b = [float(l[60:66]) for l in open(pdb_path) if l.startswith("ATOM") and l[12:16].strip() == "CA"]
    return sum(b) / len(b)

def gzip_copy(src, dst):
    with open(src, "rb") as fi, gzip.open(dst, "wb", compresslevel=6) as fo:
        shutil.copyfileobj(fi, fo)

# ---- one run
def run_one(recycles, seeds, name):
    work = os.path.join(ROOT, name)
    inference = os.path.join(work, "inference")
    os.makedirs(inference, exist_ok=True)
    exp_cfg = os.path.join(work, "experiment_config.json")
    with open(exp_cfg, "w") as f:
        json.dump(CFG["experiment_config"], f)
    cmd = [sys.executable, CFG["runner"], CFG["fasta_dir"], CFG["template_dir"],
           "--output_dir", inference, "--model_device", CFG["device"],
           "--config_preset", CFG["config_preset"], "--jax_param_path", CFG["jax_params"],
           "--use_precomputed_alignments", CFG["alignment_dir"],
           "--num_recycles_override", str(recycles),
           "--violation_loss_weight", str(CFG["violation_loss_weight"]),
           "--random_seeds", ",".join(map(str, range(seeds))),
           "--domain_ranges_json", CFG["domain_json"], "--experiment_config_json", exp_cfg,
           "--skip_relaxation", "--save_outputs", "--cpus", "2",
           "--stochastic_dropout", "--debug_write_selected_vs_last"]
    t0 = time.time()
    with open(os.path.join(work, "runner.log"), "w") as lf:
        rc = subprocess.run(cmd, cwd=CFG["openfold_dir"], stdout=lf, stderr=subprocess.STDOUT).returncode
    runtime = time.time() - t0
    if rc != 0:
        raise RuntimeError(f"runner exit code {rc}; see {work}/runner.log")

    # ---- collect into runs/<name>/
    run_dir = os.path.join(CFG["output_base_dir"], "runs", name)
    all_dir = os.path.join(run_dir, "all")
    os.makedirs(all_dir, exist_ok=True)
    sel_dir = os.path.join(inference, f"selection_{CFG['target']}")
    for fn in ("selected_open.pdb", "selected_closed.pdb", "selection_report.json"):
        shutil.copy2(os.path.join(sel_dir, fn), run_dir)
    shutil.copy2(CFG["domain_json"], run_dir)
    shutil.copy2(exp_cfg, run_dir)
    report = json.load(open(os.path.join(sel_dir, "selection_report.json")))

    rows = []
    for cand in sorted(report["candidates"], key=lambda c: c["seed"]):
        seed = int(cand["seed"])
        src = os.path.dirname(cand["pdb"])
        dst = os.path.join(all_dir, f"seed_{seed:03d}")
        os.makedirs(dst, exist_ok=True)
        gzip_copy(cand["pdb"], os.path.join(dst, "selected.pdb.gz"))
        for fn in ("recycle_metrics.jsonl", "metrics.json"):
            shutil.copy2(os.path.join(src, fn), dst)
        selected = int(json.load(open(os.path.join(src, "metrics.json")))["selected_recycle_index"])
        trace = {int(r["recycle"]): r for r in map(json.loads, open(os.path.join(src, "recycle_metrics.jsonl")))}
        rec_dir = os.path.join(src, "recycles")
        files = sorted(f for f in os.listdir(rec_dir) if re.search(r"_recycle\d+_unrelaxed\.pdb$", f))
        if not files:
            raise RuntimeError(f"no per-recycle structures in {rec_dir}")
        for fn in files:
            rec = int(re.search(r"_recycle(\d+)_unrelaxed\.pdb$", fn).group(1))
            p = os.path.join(rec_dir, fn)
            out = os.path.join(dst, f"recycle_{rec:02d}.pdb.gz")
            gzip_copy(p, out)
            t = trace.get(rec, {})
            rows.append({"seed": seed, "recycle": rec, "selected": rec == selected,
                         "openness_A": round(openness(p), 3), "mean_plddt": round(mean_plddt(p), 2),
                         "J": round(t.get("J", float("nan")), 4),
                         "violation_loss": round(t.get("structural_violation_loss", float("nan")), 4),
                         "file": os.path.relpath(out, run_dir)})
    with open(os.path.join(all_dir, "index.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

    run_config = {**{k: CFG[k] for k in ("target", "uniprot", "window_uniprot", "domain_mode", "domains_uniprot",
                                          "config_preset", "violation_loss_weight", "experiment_config")},
                  "name": name, "num_recycles": recycles, "num_seeds": seeds, "random_seeds": f"0..{seeds - 1}",
                  "stochastic_dropout": True, "openness_metric": f"{_d1}-{_d2} centroid distance (pipeline functions)",
                  "runtime_s": round(runtime, 1), "n_conformations": len(rows)}
    json.dump(run_config, open(os.path.join(run_dir, "run_config.json"), "w"), indent=2)
    sel_o, sel_c = report["selected_open"], report["selected_closed"]
    op = [r["openness_A"] for r in rows if r["selected"]]
    with open(os.path.join(run_dir, "README.md"), "w") as f:
        f.write(f"# {name}\n\n{CFG['target']} ({CFG['uniprot']}) window {CFG['window_uniprot'][0]}–{CFG['window_uniprot'][1]}, "
                f"{CFG['config_preset']}, guided recycling (w={CFG['violation_loss_weight']}, recycling fix: continue from best state), "
                f"MSA {CFG['experiment_config'].get('data.predict.max_msa_clusters')}/{CFG['experiment_config'].get('data.predict.max_extra_msa')}.\n\n"
                f"- recycles: **{recycles}**, seeds: **{seeds}** (0..{seeds - 1}), runtime {runtime / 60:.1f} min\n"
                f"- openness = {_d1}–{_d2} Cα-centroid distance (pipeline functions); "
                f"references JAK1: open ma-a1sai 46.05 Å, closed ma-l9b1f 39.53 Å\n"
                f"- selected open: seed {sel_o['seed']} ({sel_o['openness']:.2f} Å) → `selected_open.pdb`\n"
                f"- selected closed: seed {sel_c['seed']} ({sel_c['openness']:.2f} Å) → `selected_closed.pdb`\n"
                f"- selected structures per seed: openness {min(op):.2f}–{max(op):.2f} Å\n"
                f"- `all/`: {len(rows)} conformations (every seed × every recycle) as gzip PDB "
                f"(`all/seed_XXX/recycle_NN.pdb.gz`, `selected.pdb.gz` = recycle chosen by J), "
                f"traces per seed, `all/index.csv` (openness, pLDDT, J per conformation)\n")
    shutil.copy2(__file__, os.path.join(run_dir, "campaign.py"))
    return run_dir, runtime, len(rows), sel_o, sel_c

# ---- push a run folder to GitHub (fresh sparse clone, one commit)
def git_push(run_dir, name):
    if not TOKEN:
        raise RuntimeError("no GITHUB_TOKEN")
    url = f"https://x-access-token:{TOKEN}@github.com/{CFG['repo']}.git"
    target = f"Pr/{name}"
    for attempt in range(1, 6):
        tmp = os.path.join(ROOT, f"git_{name}")
        shutil.rmtree(tmp, ignore_errors=True)
        def git(*args, cwd=tmp):
            r = subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, timeout=3600)
            if r.returncode:
                raise RuntimeError(f"git {args[0]} failed: {(r.stdout + r.stderr).replace(TOKEN, '***')[-800:]}")
            return r
        try:
            git("clone", "--depth", "1", "--filter=blob:none", "--sparse", "--branch", CFG["branch"], url, tmp, cwd=ROOT)
            git("sparse-checkout", "set", target)
            git("config", "user.name", "JAK1 campaign (molab)")
            git("config", "user.email", "jak1-campaign@users.noreply.github.com")
            git("config", "http.postBuffer", "1048576000")
            shutil.copytree(run_dir, os.path.join(tmp, target), dirs_exist_ok=True)
            git("add", "--sparse", target)
            git("commit", "-q", "-m", f"JAK1 campaign: {name}")
            git("push", "origin", CFG["branch"])
            shutil.rmtree(tmp, ignore_errors=True)
            return f"https://github.com/{CFG['repo']}/tree/{CFG['branch']}/{target}"
        except Exception as e:
            log(f"  git push attempt {attempt} failed: {e}")
            time.sleep(60 * attempt)
    raise RuntimeError("git push failed after 5 attempts")

# ---- main
status = {"started": f"{datetime.datetime.now():%Y-%m-%d %H:%M:%S}", "runs": []}
for recycles, seeds in CFG["plan"]:
    name = f"{CFG['target']}_{datetime.datetime.now():%Y%m%d_%H%M%S}"
    entry = {"name": name, "recycles": recycles, "seeds": seeds, "state": "running",
             "start": f"{datetime.datetime.now():%Y-%m-%d %H:%M:%S}"}
    status["runs"].append(entry); save_status(status)
    log(f"=== {name}: {recycles} recycles x {seeds} seeds")
    try:
        run_dir, runtime, n, sel_o, sel_c = run_one(recycles, seeds, name)
        entry.update(state="saved", run_dir=run_dir, runtime_min=round(runtime / 60, 1), conformations=n,
                     open=f"seed {sel_o['seed']} {sel_o['openness']:.2f} A", closed=f"seed {sel_c['seed']} {sel_c['openness']:.2f} A")
        save_status(status)
        log(f"  inference+save done in {runtime / 60:.1f} min, {n} conformations -> {run_dir}")
        entry["github"] = git_push(run_dir, name)
        entry["state"] = "done"
        log(f"  pushed: {entry['github']}")
    except Exception as e:
        entry.update(state="failed", error=str(e)[-1000:])
        log(f"  FAILED: {e}\n{traceback.format_exc()[-2000:]}")
    entry["end"] = f"{datetime.datetime.now():%Y-%m-%d %H:%M:%S}"
    save_status(status)
    time.sleep(2)   # distinct timestamps
status["finished"] = f"{datetime.datetime.now():%Y-%m-%d %H:%M:%S}"
save_status(status)
log("campaign finished")
