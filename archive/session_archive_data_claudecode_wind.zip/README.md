# Session archive — Claude Code on Windows, 24 October – 1 November 2026

One Claude Code session running on a Windows 11 machine (`data/claudecode/wind`), with **no Python
installed** — which is why every script here is PowerShell and why the heavy work was pushed to
molab sandboxes or to web APIs.

Two threads: assembling public-database annotation for all four JAK-family kinases, and settling
whether the dual-state PyRosetta ΔΔG values are real.

```
README.md       this file: what was done, where it was pushed, how to reproduce
transcript/     the full conversation (JSONL), CREDENTIALS REDACTED
scripts/        every script written during the session (PowerShell, plus marimo code-mode drivers)
data/           the deliverables as pushed, data/notes/ the intermediate extracts behind them,
                data/ddmut/ the in-flight DDMut run (see "Unfinished" below)
```

---

## 1. What was pushed, and where

Everything below landed in `chervov/ProteinModelling1`. Commits are from this session; the
repository received unrelated commits from another machine in the same window (see §5).

### Variant annotation — `external_data/`

| path | contents |
|---|---|
| `external_data/<GENE>/<gene>_variants_inf.csv` | per-protein variant tables for JAK1, JAK2, JAK3, TYK2: ClinVar (protein-level variants, review status, condition, somatic impact), gnomAD v4 (AC/AF/homozygotes plus a benign/pathogenic call on frequency), cBioPortal, COSMIC, OncoKB, CIViC, LOVD, DECIPHER, OMIM allelic variants, "Seen in" |
| `..._variants_inf_predict.csv` | the same plus AlphaMissense, REVEL, CADD phred, SIFT, PolyPhen-2 HVAR, MetaRNN, ESM1b, and the Rosetta `ddG closed` / `ddG open` / `ddG open-closed` columns |
| `..._variants_inf_predict_ext.csv` | the same plus ~70 further dbNSFP columns via myvariant.info |
| `external_data/<GENE>/<gene>_sources_summary.md` | per-source yield: how many variants each database contributed |
| `external_data/scores_interpretation.md` | how to read each predictor, with damaging thresholds |
| `external_data/jak_alignment_position_map.csv`, `jak_sequences.fasta` | the JAK-family alignment and the position map every homology claim rests on |
| `external_data/JAK3/jak3_homology_inf.md` | JAK3 Y581C: paralog equivalents, predictor scores for every homologous substitution, and the 3D neighbourhood from AF-P52333-F1 |
| `external_data/JAK2/jak2_homology_inf.md` | the same for JAK2 V1110E, G571R, V578I, L805I |
| `external_data/JAK2/jak2_omim.md`, `external_data/omim_allelic_variants.csv` | OMIM allelic-variant extraction |
| `external_data/<GENE>/evidence_review_*/` | per-variant evidence dossiers and the raw JSON behind them |

### The ΔΔG investigation — `data/ddg/`, `pipeline/ddg/`, `colab/`

| path | commit | contents |
|---|---|---|
| `conclusions_ddG_difference_feature.md` §§8–10 | `30d049b`, `bdb458f`, `fca21cf` | the written argument; **§10 supersedes §8 and §9** on whether a ramped protocol fixes the tail (it does not) |
| `pipeline/ddg/diagnose_clash.py` + `data/ddg/clash_diagnosis.json` | `65c583e`, `44f051c` | 17 variants × 3 protocols: repack-only, `fa_rep` decomposition, mobile-backbone minimisation |
| `pipeline/ddg/compare_ddg_monomer.py` + `data/ddg/kellogg_ddg_monomer.json` | `e540c3a`, `b0347d4` | Rosetta's own `ddGMover` (= `ddg_monomer`, Kellogg 2011) on the same variants |
| `data/ddg/TYK2_relaxed_closed.pdb.gz` | `b57bfb3` | **the relaxed pose**, published so no notebook has to spend ~35 min on FastRelax again |
| `pipeline/ddg/notebook_clash_diagnosis.py` | `ac9d53c` | the whole diagnosis as a marimo notebook, 15 cells, run-all |
| `colab/tyk2_ddg_clash_diagnosis.ipynb` | `659b414` | the same for Google Colab (there is no Colab CLI; a repo-hosted `.ipynb` is the only route) |
| `README.md`, `pipeline/ddg/README.md` | `a0749e7`, `9ac787a` | Colab badge, repo map, the published-pose and ddGMover findings |
| `data/ddg/ddg_approximation_review.md` | `89d6702`, `46c6e37` | review of the biophysical approximator — see §4 |
| `pipeline/ddg/check_approximator.ps1` | `8259351` | the independent reimplementation behind that review |
| `data/ddg/ddg_approximation.md` | `2621b46` | corrections to the retraction block another session wrote |
| `archive/session_archive_20261024-25.zip` | `07dd9f6` | the first half of this session, same layout as this archive |

---

## 2. The ΔΔG result, in one place

**The extreme stored values are not energies, and the protocol is not the reason.** Three
independent lines:

1. The extremes are ~100% `fa_rep` (Lennard-Jones repulsion), and a mobile backbone shrinks them
   10–150×.
2. The ordering survives the protocol change at Spearman **0.904**, so the ranking is stable even
   though the magnitudes are not.
3. Rosetta's own `ddg_monomer` — repulsive ramp, constrained minimisation, best of several decoys —
   returns **+2832 REU for G746W** against the pipeline's **−2989**, while giving textbook values for
   ordinary substitutions (**H667F 2.08 kcal/mol**, **R775A 0.62 kcal/mol**).

The decisive scale argument: the whole folded protein scores **−2689 REU**, so a ΔΔG of −3000 implies
a mutant at **+311 REU**, which no folded structure has. Every extreme position is a buried glycine
that cannot host a bulky residue under any fixed-backbone treatment.

**Use the ranks, never the values as energies.** This is what `pipeline/ddg/README.md` said from the
start.

Cross-check added 1 November: **DDMut** puts the same five variants at **1.0–3.0 kcal/mol**
(G746W −1.82, G801W −2.97, G746A −1.00, H667F −0.99, R775A −1.05; DDMut's own sign, negative =
destabilising). Physical magnitudes — but compressed, barely separating G746W from R775A, and its
ordering disagrees with Rosetta's. Complementary failures, not interchangeable methods.

---

## 3. How to reproduce

**The ΔΔG diagnosis, no sandbox needed.** Open
`colab/tyk2_ddg_clash_diagnosis.ipynb` through
`colab.research.google.com/github/chervov/ProteinModelling1/blob/main/colab/tyk2_ddg_clash_diagnosis.ipynb`
and Run all. It installs PyRosetta, downloads the published relaxed pose, and reproduces protocols A
and B, the `fa_rep` shares and the ddGMover table. Nothing to configure.

**On a molab box:** open `pipeline/ddg/notebook_clash_diagnosis.py` and run all. Same content,
reactive — changing `TEST_POSITIONS` re-runs the table, chart and conclusion.

**The approximator review:** `pipeline/ddg/check_approximator.ps1`, no arguments. It fetches
`jak2_variants_multimethod.csv` itself and prints the three tests.

**The annotation tables:** `scripts/` holds the fetchers — `clinvar_fetch.ps1`, `gnomad_fetch.ps1`,
`cbio_fetch.ps1`, `civic_fetch.ps1`, `dbnsfp_fetch.ps1` / `dbnsfp_full.ps1`, `omim_allelic.ps1`,
`lovd`/`decipher` paths inside `fetch_gene_sources.ps1`, then `build_gene_tables.ps1` and
`build_all_genes.ps1` to assemble, and `add_*.ps1` to insert a column at a chosen position rather
than at the end.

**To drive a live marimo kernel from PowerShell:** `scripts/marimo-exec.ps1 -Url <sandbox> -File x.py`.
It is a port of the marimo-pair skill's `execute-code.sh`, which needs bash. Long timeouts and
session retries, because a box at 100% CPU is slow to answer.

**To push without git:** `scripts/gh_put.ps1 -repo -branch -local -remote -message -tokenFile`.
Strips the UTF-8 BOM and retries, because GitHub's ruleset check intermittently returns 403/500 on
the first attempt.

---

## 4. The approximator review — what it found

`data/ddg/ddg_approximation.md` proposed a volume-and-flag heuristic for ΔΔG. Reimplemented and
tested:

- **1 of 8** values in its verification table reproduce from its own code (G571R: code gives
  **+8.83**, the table claimed +3.4; L805I: code gives **0.00**, the table claimed +0.7).
- Across **1,900** substitution/burial combinations it returns **0 negative values, minimum exactly
  0.00** — it cannot express the stabilising half of its own defined sign convention.
- Against the four methods in `jak2_variants_multimethod.csv`, Spearman is **−0.12 / +0.19 / +0.15 /
  −0.06** (ThermoMPNN / FoldX / mCSM / DDMut): no stability ranking information.
- Its hand-set burial flags contradict the repository's own RSA — G571R was flagged buried in a tight
  turn, but its RSA is **73.9% exposed**.

**No table in the repository carries approximator output**, so nothing needed retracting. The
document has since been formally retracted by its author.

---

## 5. Unfinished, and things the next session should know

**A DDMut run is in flight.** 2,246 TYK2 missense variants were prepared;
`data/ddmut/pending_jobs.txt` holds the server-side job IDs. **DDMut jobs outlive the client**, so
they are retrievable by ID long after the submitting script gave up:

```
curl -s -X GET https://biosig.lab.uq.edu.au/ddmut/api/prediction_list -F "job_id=<id>"
```

`scripts/ddmut_collect.ps1` does this in a loop. Expect queue latency of **hours, not minutes** — a
20-variant job did not return within 10 minutes when three other jobs of ours were queued behind it.
`data/ddmut/chunks/` holds the mutation lists; `random300.txt` is a seeded random sample across all
20 wild-type residues and is the one to use for statistics, because `chunk01`/`chunk02` were
produced by an alphabetical sort and cover only wild types **A, C, D, E, F, G**.

**Two format traps with the BioSig servers.** The DDMut API page documents the mutation-list format
as `<wt><pos><mut>`; the real format is `<chain> <wt><pos><mut>` and the documented one is rejected.
And mCSM has no API page (`/mcsm/api` is 404) but its batch form endpoint
`/mcsm/stability_prediction_list` accepts programmatic POSTs.

**Server availability, checked 1 November 2026.** mCSM-Stability and DUET are up (DUET has no batch
mode). **PoPMuSiC is unavailable** — `soft.depassistant.org` does not resolve at all, the real host
`dezyme.com` serves "Site en maintenance", and `soft.dezyme.com` answers but with an expired TLS
certificate. There is no PoPMuSiC 3.1 in the literature; the published server is 2.1 (2011).

**Dead ends, recorded so they are not repeated.**

- **StructMAn cannot score substitutions.** It annotates positions only; its own example output
  shows every residue as X→X. Verified twice, including an SMLF upload.
- **CCLE expression cannot test JAK2 L805I.** The only line carrying it (SARC9371_BONE) has no
  RNA-seq, and calibration on lines that do showed the approach cannot detect even V617F (SET-2
  ranks 51/188 on a JAK2-target signature).
- **There is no Google Colab CLI.** Google never shipped one.
- **AlphaGenome was not used.** It needs an API key this session did not have, and a Python
  environment this machine does not have. It predicts regulatory tracks from DNA sequence and says
  nothing about missense effects on a fold — relevant only if the tables are ever extended to
  non-coding JAK variants.

**One data defect found.** `tyk2_variants_inf.csv` contains **R896I**, but position 896 in P29597 is
**Tyr**, not Arg. It was excluded from the DDMut submission. Worth tracing to whichever source
contributed that row.

**Another machine commits to this repository concurrently.** On 1 November a commit from elsewhere
replaced a note this session had pushed to `ddg_approximation.md` minutes earlier, without conflict
or warning. Re-read a file before assuming your version is still there.

---

## 6. Credentials

Scrubbed before archiving: **27** molab agent tokens replaced with `[REDACTED-molab-token]`, verified
across all text files. The GitHub token never entered the transcript — it was read from a file into a
variable and never printed.

A bare 64-hex string is deliberately **not** treated as a secret here: the transcript's own `hash`
and `shapeHash` fields are 64-hex and chain the messages together, and blanking them (5,695 of them,
on a first attempt) destroys the thing this archive exists to restore. Only hex in a credential
context is redacted. `scripts/make_archive.ps1` did it and can be re-run to re-check.

Both tokens used in this session should be treated as compromised regardless, since they were typed
into a chat window. Rotate them.

---

## 7. Two PowerShell traps that cost real time

1. **PowerShell 5.1 reads a BOM-less `.ps1` as ANSI**, so any non-ASCII character in a script becomes
   mojibake in whatever it writes. Keep `.ps1` files pure ASCII and put non-ASCII content in separate
   `.md` files read as UTF-8 — or build the character from its code point, as
   `scripts/correct_approx_doc.ps1` does with `[char]0x00A7`. This bit three times.
2. **PowerShell variables are case-insensitive**, so `$v = ...` silently clobbers a `$V` lookup table
   — which it did, mid-loop, producing a table of zeros that looked plausible. And
   `$a[($i+1)..($n-1)]` runs **backwards** when `i` is the last index, duplicating the final element.
