param($jobFile, $outDir, $hours = 5)
# Collect DDMut jobs that were already submitted, by job id. Server-side jobs outlive the
# script that submitted them, so a poll that gave up loses nothing as long as the id is kept.
$ErrorActionPreference = 'Continue'
$api = 'https://biosig.lab.uq.edu.au/ddmut/api/prediction_list'
New-Item -ItemType Directory -Force $outDir | Out-Null
$jobs = @{}
foreach ($line in Get-Content $jobFile) {
  $p = $line -split '\s+'
  if ($p.Count -ge 2) { $jobs[$p[0]] = $p[1] }
}
$deadline = (Get-Date).AddHours($hours)
while ((Get-Date) -lt $deadline -and $jobs.Count) {
  foreach ($id in @($jobs.Keys)) {
    $dst = "$outDir\$($jobs[$id]).json"
    if (Test-Path $dst) { $jobs.Remove($id); continue }
    $r = & curl.exe -s -X GET $api -F "job_id=$id" --max-time 90
    $s = ($r -join '')
    if ($s -and $s -notmatch 'RUNNING' -and $s.Length -gt 40) {
      [IO.File]::WriteAllText($dst, $s, (New-Object Text.UTF8Encoding($false)))
      "$($jobs[$id]) (job $id): collected $(Get-Date -Format HH:mm:ss), $($s.Length) chars"
      $jobs.Remove($id)
    }
  }
  if ($jobs.Count) { Start-Sleep -Seconds 120 }
}
if ($jobs.Count) { "still running at $(Get-Date -Format HH:mm:ss): $(($jobs.Values) -join ', ')" }
else { "all jobs collected" }
