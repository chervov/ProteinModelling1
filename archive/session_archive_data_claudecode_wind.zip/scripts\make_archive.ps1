param($stage, $zipOut)
# Build archive/session_archive_20261024-25.zip in the same layout as the 20261017-19 one:
# README.md, scripts/, data/, transcript/. Secrets are redacted before anything is staged.
# Pure ASCII on purpose (PowerShell 5.1 reads BOM-less .ps1 as ANSI and mangles non-ASCII).
$ErrorActionPreference = 'Stop'
$proj = 'C:\Users\alche\.claude\projects\C--Users-alche-AppData-Local-Claude-Data-claude-pzs8sxrjxfjjc-scratch-workspaces-ab52c12e-4684-438e-9eb2-34a6de0d2ac5-d9533145-c7cf-4453-a5e1-32bd3c869cb5-scratch-2026-10-24-c10c73'
$sid = 'd9bbe1e9-a14a-47d2-9f40-afad3bc787d9'
$tasks = "C:\Users\alche\AppData\Local\Temp\claude\C--Users-alche-AppData-Local-Claude-Data-claude-pzs8sxrjxfjjc-scratch-workspaces-ab52c12e-4684-438e-9eb2-34a6de0d2ac5-d9533145-c7cf-4453-a5e1-32bd3c869cb5-scratch-2026-10-24-c10c73\$sid\tasks"

if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
foreach ($d in 'scripts', 'data', "transcript\$sid\tool-results") {
  New-Item -ItemType Directory -Force "$stage\$d" | Out-Null
}

# ---- 1. redact the transcript -------------------------------------------------
$secrets = @{}
foreach ($f in 'gh_token.txt', 'molab_token.txt') {
  if (Test-Path ".\$f") {
    $v = (Get-Content ".\$f" -Raw).Trim()
    if ($v.Length -ge 16) { $secrets[$v] = "[REDACTED-$($f -replace '_token\.txt','')-token]" }
  }
}
# A bare 64-hex string is NOT treated as a secret: the transcript's own `hash` and
# `shapeHash` fields are 64-hex and chain the messages together, so blanking them would
# break the thing this archive exists to restore. Only hex in a credential context goes.
$patterns = [ordered]@{
  'github-pat'   = 'gh[pousr]_[A-Za-z0-9]{16,}|github_pat_[A-Za-z0-9_]{20,}'
  'bearer'       = '(?i)(bearer\s+)[A-Za-z0-9_\-\.]{20,}'
  'token-in-ctx' = '(?i)(token["'': =]{1,4}|token=|\?token=)[0-9a-f]{32,}'
  'aws-key'      = 'AKIA[0-9A-Z]{16}'
  'private-key'  = '-----BEGIN [A-Z ]*PRIVATE KEY-----'
}
$counts = [ordered]@{}

function Scrub([string]$text) {
  foreach ($k in $script:secrets.Keys) {
    $n = ([regex]::Matches($text, [regex]::Escape($k))).Count
    if ($n) { $script:counts[$script:secrets[$k]] = [int]$script:counts[$script:secrets[$k]] + $n }
    $text = $text.Replace($k, $script:secrets[$k])
  }
  foreach ($name in $script:patterns.Keys) {
    $n = ([regex]::Matches($text, $script:patterns[$name])).Count
    if ($n) { $script:counts["[REDACTED-$name]"] = [int]$script:counts["[REDACTED-$name]"] + $n }
    $text = [regex]::Replace($text, $script:patterns[$name], "[REDACTED-$name]")
  }
  return $text
}

function Verify([string]$path) {
  $t = [IO.File]::ReadAllText($path, [Text.Encoding]::UTF8)
  foreach ($k in $script:secrets.Keys) {
    if ($t.Contains($k)) { throw "SECRET SURVIVED in $path - refusing to continue" }
  }
  foreach ($name in $script:patterns.Keys) {
    if ([regex]::IsMatch($t, $script:patterns[$name])) { throw "pattern $name survived in $path" }
  }
}

$trIn = "$proj\$sid.jsonl"
$trOut = "$stage\transcript\transcript.jsonl"
$raw = [IO.File]::ReadAllText($trIn, [Text.Encoding]::UTF8)
[IO.File]::WriteAllText($trOut, (Scrub $raw), (New-Object Text.UTF8Encoding($false)))
Verify $trOut
$utf8 = New-Object Text.UTF8Encoding($false)

if (Test-Path "$proj\$sid\custom-title.json") {
  Copy-Item "$proj\$sid\custom-title.json" "$stage\transcript\$sid\custom-title.json"
}
if (Test-Path $tasks) {
  foreach ($f in Get-ChildItem $tasks -File) {
    $dst = "$stage\transcript\$sid\tool-results\$($f.BaseName).txt"
    [IO.File]::WriteAllText($dst, (Scrub ([IO.File]::ReadAllText($f.FullName, [Text.Encoding]::UTF8))), $utf8)
    Verify $dst
  }
}

# ---- 2. scripts: everything I wrote to drive this session ---------------------
foreach ($src in (Get-ChildItem .\tools -File), (Get-ChildItem .\marimo -File)) {
  foreach ($f in $src) {
    $dst = "$stage\scripts\$($f.Name)"
    if ($f.Extension -in '.ps1', '.py', '.md', '.txt', '.json') {
      [IO.File]::WriteAllText($dst, (Scrub ([IO.File]::ReadAllText($f.FullName, [Text.Encoding]::UTF8))), $utf8)
      Verify $dst
    } else { Copy-Item $f.FullName $dst }
  }
}

# ---- 3. data: the deliverables, plus the authored notes behind them ----------
foreach ($f in Get-ChildItem .\upload -File) { Copy-Item $f.FullName "$stage\data\$($f.Name)" }
foreach ($f in Get-ChildItem . -File -Filter '*.csv') { Copy-Item $f.FullName "$stage\data\$($f.Name)" }
New-Item -ItemType Directory -Force "$stage\data\notes" | Out-Null
foreach ($f in Get-ChildItem .\sources -Recurse -File -Include *.md, *.json) {
  if ($f.Length -lt 200KB) { Copy-Item $f.FullName "$stage\data\notes\$($f.Name)" -ErrorAction SilentlyContinue }
}

# The DDMut run: mutation lists, the server-side job ids (jobs outlive the client, so these
# are what another session needs to collect the results) and whatever has come back so far.
if (Test-Path .\ddmut) {
  New-Item -ItemType Directory -Force "$stage\data\ddmut\chunks", "$stage\data\ddmut\out" | Out-Null
  foreach ($f in Get-ChildItem .\ddmut -File) { Copy-Item $f.FullName "$stage\data\ddmut\$($f.Name)" }
  foreach ($f in Get-ChildItem .\ddmut\chunks -File -ErrorAction SilentlyContinue) {
    Copy-Item $f.FullName "$stage\data\ddmut\chunks\$($f.Name)"
  }
  foreach ($f in Get-ChildItem .\ddmut\out -File -ErrorAction SilentlyContinue) {
    Copy-Item $f.FullName "$stage\data\ddmut\out\$($f.Name)"
  }
  # the decompressed pose is 1.6 MB and already published as data/ddg/TYK2_relaxed_closed.pdb.gz
  Remove-Item "$stage\data\ddmut\TYK2_relaxed_closed.pdb" -ErrorAction SilentlyContinue
}

# ---- 4. final sweep over everything staged ------------------------------------
$checked = 0
foreach ($f in Get-ChildItem $stage -Recurse -File) {
  if ($f.Extension -in '.ps1', '.py', '.md', '.txt', '.json', '.csv', '.jsonl', '.ipynb') { Verify $f.FullName; $checked++ }
}

# ---- 5. zip ------------------------------------------------------------------
Add-Type -AssemblyName System.IO.Compression.FileSystem
if (Test-Path $zipOut) { Remove-Item $zipOut }
[IO.Compression.ZipFile]::CreateFromDirectory($stage, $zipOut, [IO.Compression.CompressionLevel]::Optimal, $false)

'redactions:'
$counts.GetEnumerator() | ForEach-Object { "  {0,-30} {1}" -f $_.Key, $_.Value }
"files staged: $((Get-ChildItem $stage -Recurse -File).Count); secret-scanned: $checked"
"zip: {0:N2} MB" -f ((Get-Item $zipOut).Length / 1MB)
