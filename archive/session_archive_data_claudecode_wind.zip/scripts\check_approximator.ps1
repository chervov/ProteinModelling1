# Faithful PowerShell reimplementation of ddg_approximator.py's compute_ddg, used to check
# whether the table in section 5 of ddg_approximation.md is what the code actually produces.
$V = @{G=60.1;A=88.6;S=89.0;C=108.5;D=111.1;P=112.7;T=116.1;N=114.1;V=140.0;E=138.4;
       Q=143.8;H=153.2;I=166.7;L=166.7;M=162.9;K=168.6;F=189.9;Y=193.6;W=227.8;R=225.0}
$Q = @{D=-1.0;E=-1.0;K=1.0;R=1.0;H=0.1;G=0.0;A=0.0;S=0.0;C=0.0;P=0.0;
       T=0.0;N=0.0;V=0.0;Q=0.0;I=0.0;L=0.0;M=0.0;F=0.0;Y=0.0;W=0.0}

function Approx($wt, $mut, $burial = 0.8, $turn = $false, $salt = $false, $cat = $false, $auto = $false) {
  $alpha = 0.040; $kappa = 0.024; $born = 1.42; $glyP = 2.42; $proP = 1.45
  $dv = $V[$mut] - $V[$wt]
  $dq = [math]::Abs($Q[$mut] - $Q[$wt])
  $st = 0.0; $cav = 0.0; $el = 0.0; $bb = 0.0
  if ($dv -gt 0) { $st += $alpha * $dv * $burial; if ($auto) { $st += 1.2 } }
  if ($wt -eq 'G' -and $mut -ne 'G') { $st += $(if ($turn) { $glyP } else { 1.2 }) }
  if ($dv -lt 0) {
    $cav += $kappa * [math]::Abs($dv) * $burial
    if ($wt -in @('F','Y','W') -and $mut -in @('A','V','G','S')) { $cav += 1.1 }
  }
  if ($dq -gt 0) {
    if ($burial -gt 0.5) { $el += $born * $burial }
    if ($cat) { $el += 1.0 }
  }
  if ($salt -and [math]::Abs($Q[$wt]) -gt 0 -and $Q[$mut] -eq 0) { $el += 2.2 }
  if ($wt -eq 'P' -and $mut -ne 'P') { $bb += $proP }
  elseif ($wt -ne 'P' -and $mut -eq 'P') { $bb += $(if ($cat) { 1.8 } else { 1.2 }) }
  if ($wt -in @('V','I','L') -and $mut -in @('V','I','L')) {
    $st = [math]::Min($st, 0.4); $cav = [math]::Min($cav, 0.4)
  }
  return [pscustomobject]@{ dv = $dv; steric = $st; cavity = $cav; elec = $el; bb = $bb
                            total = [math]::Round($st + $cav + $el + $bb, 2) }
}
