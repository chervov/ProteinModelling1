param($pdb, $chunkDir, $outDir)
# Submit each mutation-list chunk to DDMut, wait for it, save its JSON. One chunk at a time,
# so the free academic server never has more than one job of ours in its queue.
$ErrorActionPreference = 'Continue'
$api = 'https://biosig.lab.uq.edu.au/ddmut/api/prediction_list'
New-Item -ItemType Directory -Force $outDir | Out-Null

foreach ($c in Get-ChildItem $chunkDir -Filter '*.txt' | Sort-Object Name) {
  $dst = "$outDir\$($c.BaseName).json"
  if (Test-Path $dst) { "$($c.BaseName): already done"; continue }
  $sub = & curl.exe -s -X POST $api -F "pdb_file=@$pdb" -F "mutations_list=@$($c.FullName)"
  $id = $null
  try { $id = ($sub | ConvertFrom-Json).job_id } catch { }
  if (-not $id) { "$($c.BaseName): SUBMIT FAILED - $sub"; continue }
  "$($c.BaseName): job $id submitted $(Get-Date -Format HH:mm:ss)"
  $got = $false
  foreach ($i in 1..90) {
    Start-Sleep -Seconds 20
    $r = & curl.exe -s -X GET $api -F "job_id=$id"
    if ($r -and $r -notmatch 'RUNNING') {
      [IO.File]::WriteAllText($dst, $r, (New-Object Text.UTF8Encoding($false)))
      "$($c.BaseName): done in $([int]($i * 20 / 60)) min"
      $got = $true; break
    }
  }
  if (-not $got) { "$($c.BaseName): TIMED OUT (job $id still running)" }
  Start-Sleep -Seconds 5
}
"finished: $((Get-ChildItem $outDir -Filter '*.json' -ErrorAction SilentlyContinue).Count) of $((Get-ChildItem $chunkDir -Filter '*.txt').Count) chunks"
