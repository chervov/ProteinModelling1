param($id, $out, $tries = 60, $every = 30)
# Poll a DDMut job until it stops saying RUNNING. Writes the final JSON to $out.
for ($i = 1; $i -le $tries; $i++) {
  Start-Sleep -Seconds $every
  $r = & curl.exe -s -X GET 'https://biosig.lab.uq.edu.au/ddmut/api/prediction_list' -F "job_id=$id"
  if ($r -and $r -notmatch 'RUNNING') {
    [IO.File]::WriteAllText($out, $r, (New-Object Text.UTF8Encoding($false)))
    "DONE after $([int]($i * $every / 60)) min"
    $r
    return
  }
}
"still RUNNING after $([int]($tries * $every / 60)) min"
