param($outDir, $inDir, $ddgJson, $resultDir)
# Merge the DDMut chunk results into the TYK2 tables and compare them with the stored Rosetta
# ddG and with the deep mutational scan. Sign is flipped to the repo's convention
# (jak2_variants_multimethod.csv): POSITIVE = destabilising.
$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force $resultDir | Out-Null

# ---- 1. collect predictions --------------------------------------------------
$pred = @{}
foreach ($f in Get-ChildItem $outDir -Filter '*.json' | Sort-Object Name) {
  $j = Get-Content $f.FullName -Raw | ConvertFrom-Json
  foreach ($p in $j.PSObject.Properties) {
    if ($p.Name -eq 'results_page') { continue }
    $v = $p.Value
    if ($null -ne $v.mutation -and $null -ne $v.prediction) {
      $pred[[string]$v.mutation] = [math]::Round(-1 * [double]$v.prediction, 3)   # sign flip
    }
  }
}
"DDMut predictions collected: $($pred.Count)"
$vals = $pred.Values | Sort-Object
"range: $($vals[0]) .. $($vals[-1])   median $($vals[[int]($vals.Count/2)])"

# ---- 2. write the column into each TYK2 table --------------------------------
$newCol = 'DDMut ddG'
foreach ($name in 'tyk2_variants_inf.csv', 'tyk2_variants_inf_predict.csv', 'tyk2_variants_inf_predict_ext.csv') {
  $rows = Import-Csv "$inDir\$name"
  $cols = @($rows[0].PSObject.Properties.Name)
  if ($cols -contains $newCol) { $cols = $cols | Where-Object { $_ -ne $newCol } }
  $anchor = if ($cols -contains 'ddG open-closed') { 'ddG open-closed' } else { 'DMS abundance (VAMP-seq)' }
  $i = [array]::IndexOf($cols, $anchor)
  $order = @($cols[0..$i]) + @($newCol)
  if ($i + 1 -le $cols.Count - 1) { $order += @($cols[($i + 1)..($cols.Count - 1)]) }

  $hit = 0
  $out = foreach ($r in $rows) {
    $val = ''
    if ($pred.ContainsKey($r.Variant)) { $val = $pred[$r.Variant]; $hit++ }
    $r | Add-Member -NotePropertyName $newCol -NotePropertyValue $val -Force
    $r | Select-Object $order
  }
  $out | Export-Csv "$resultDir\$name" -NoTypeInformation -Encoding UTF8
  "$name : $hit of $($rows.Count) rows filled, column after '$anchor'"
}

# ---- 3. stats ----------------------------------------------------------------
function Ranks([double[]]$x) {
  $idx = 0..($x.Count - 1) | Sort-Object { $x[$_] }
  $r = New-Object double[] $x.Count
  $i = 0
  while ($i -lt $idx.Count) {
    $j = $i
    while ($j + 1 -lt $idx.Count -and $x[$idx[$j + 1]] -eq $x[$idx[$i]]) { $j++ }
    $avg = ($i + $j) / 2.0 + 1
    for ($k = $i; $k -le $j; $k++) { $r[$idx[$k]] = $avg }
    $i = $j + 1
  }
  return $r
}
function Pear([double[]]$a, [double[]]$b) {
  $ma = ($a | Measure-Object -Average).Average; $mb = ($b | Measure-Object -Average).Average
  $num = 0.0; $da = 0.0; $db = 0.0
  for ($i = 0; $i -lt $a.Count; $i++) {
    $x = $a[$i] - $ma; $y = $b[$i] - $mb
    $num += $x * $y; $da += $x * $x; $db += $y * $y
  }
  if ($da -eq 0 -or $db -eq 0) { return [double]::NaN }
  return $num / [math]::Sqrt($da * $db)
}
function Spear([double[]]$a, [double[]]$b) { Pear (Ranks $a) (Ranks $b) }
function Auc([double[]]$score, [int[]]$label) {
  # P(score of a positive > score of a negative), ties at 0.5, via ranks
  $r = Ranks $score
  $np = 0; $sum = 0.0
  for ($i = 0; $i -lt $label.Count; $i++) { if ($label[$i] -eq 1) { $np++; $sum += $r[$i] } }
  $nn = $label.Count - $np
  if ($np -eq 0 -or $nn -eq 0) { return [double]::NaN }
  return ($sum - $np * ($np + 1) / 2.0) / ($np * $nn)
}

# Rosetta ddG, keyed by variant. Stored sign: negative = destabilising, so flip to match.
$ros = @{}
foreach ($rec in (Get-Content $ddgJson -Raw | ConvertFrom-Json)) {
  $ros["$($rec.wt)$($rec.pos)$($rec.alt)"] = -1 * [double]$rec.ddg_closed
}
"Rosetta records: $($ros.Count)"

$tab = Import-Csv "$resultDir\tyk2_variants_inf_predict.csv"
$dd = @(); $rr = @(); $sig = @(); $ddSig = @(); $abu = @(); $ddAbu = @(); $rosAbu = @()
foreach ($r in $tab) {
  if ($r.$newCol -eq '') { continue }
  $d = [double]$r.$newCol
  if ($ros.ContainsKey($r.Variant)) { $dd += $d; $rr += $ros[$r.Variant] }
  $s = $r.'DMS signalling (IFN-a 100U/mL)'
  if ($s -match '^-?\d+(\.\d+)?') { $ddSig += $d; $sig += [double]$Matches[0] }
  $a = $r.'DMS abundance (VAMP-seq)'
  if ($a -match '^-?\d+(\.\d+)?') {
    $ddAbu += $d; $abu += [double]$Matches[0]
    $rosAbu += $(if ($ros.ContainsKey($r.Variant)) { $ros[$r.Variant] } else { [double]::NaN })
  }
}
''
"n DDMut vs Rosetta      : $($dd.Count)   Spearman $([math]::Round((Spear $dd $rr), 3))   Pearson $([math]::Round((Pear $dd $rr), 3))"
"n DDMut vs DMS signalling: $($sig.Count)   Spearman $([math]::Round((Spear $ddSig $sig), 3))"
"n DDMut vs DMS abundance : $($abu.Count)   Spearman $([math]::Round((Spear $ddAbu $abu), 3))"

# AUC: can the predictor pick out the variants the scan calls low-abundance?
$thr = -1.0
$lab = @(); $keepD = @(); $keepR = @()
for ($i = 0; $i -lt $abu.Count; $i++) {
  if ([double]::IsNaN($rosAbu[$i])) { continue }
  $lab += [int]($abu[$i] -lt $thr); $keepD += $ddAbu[$i]; $keepR += $rosAbu[$i]
}
"AUC (abundance < $thr, n=$($lab.Count), positives=$(($lab | Measure-Object -Sum).Sum)):"
"   DDMut   $([math]::Round((Auc $keepD $lab), 3))"
"   Rosetta $([math]::Round((Auc $keepR $lab), 3))"
