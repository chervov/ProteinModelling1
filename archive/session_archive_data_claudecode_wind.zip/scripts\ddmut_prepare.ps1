param($pdb, $table, $outDir, $chunk = 300)
# Turn the TYK2 variant table into DDMut mutation-list chunks, keeping only variants whose
# wild-type residue actually matches the structure. Format is "<chain> <wt><pos><mut>" per line
# (the API docs say otherwise; the help page is right).
$ErrorActionPreference = 'Stop'
$three = @{
  ALA='A';ARG='R';ASN='N';ASP='D';CYS='C';GLN='Q';GLU='E';GLY='G';HIS='H';ILE='I'
  LEU='L';LYS='K';MET='M';PHE='F';PRO='P';SER='S';THR='T';TRP='W';TYR='Y';VAL='V'
}
$res = @{}
foreach ($line in [IO.File]::ReadLines($pdb)) {
  if ($line.StartsWith('ATOM') -and $line.Substring(12, 4).Trim() -eq 'CA') {
    $res[[int]$line.Substring(22, 4).Trim()] = $three[$line.Substring(17, 3)]
  }
}
"structure: $($res.Count) residues, $(($res.Keys | Measure-Object -Min).Minimum)-$(($res.Keys | Measure-Object -Max).Maximum)"

$keep = @(); $skipMissing = @(); $skipMismatch = @()
foreach ($row in (Import-Csv $table)) {
  $v = $row.Variant
  if ($v -notmatch '^([ACDEFGHIKLMNPQRSTVWY])(\d+)([ACDEFGHIKLMNPQRSTVWY])$') { continue }
  $wt = $Matches[1]; $pos = [int]$Matches[2]; $mut = $Matches[3]
  if (-not $res.ContainsKey($pos)) { $skipMissing += $v; continue }
  if ($res[$pos] -ne $wt) { $skipMismatch += "$v (structure has $($res[$pos])$pos)"; continue }
  $keep += $v
}
$keep = $keep | Sort-Object -Unique
"kept $($keep.Count); not in structure $($skipMissing.Count); wild-type mismatch $($skipMismatch.Count)"
if ($skipMismatch.Count) { "mismatch examples: $(($skipMismatch | Select-Object -First 5) -join '; ')" }

if (Test-Path $outDir) { Remove-Item $outDir -Recurse -Force }
New-Item -ItemType Directory -Force $outDir | Out-Null
$n = 0
for ($i = 0; $i -lt $keep.Count; $i += $chunk) {
  $n++
  $slice = $keep[$i..([Math]::Min($i + $chunk - 1, $keep.Count - 1))]
  [IO.File]::WriteAllLines("$outDir\chunk$('{0:d2}' -f $n).txt", ($slice | ForEach-Object { "A $_" }))
}
"wrote $n chunks of up to $chunk into $outDir"
