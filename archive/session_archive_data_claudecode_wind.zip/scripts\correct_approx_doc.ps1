param($src, $dst)
# Corrections to the retraction note another session wrote into ddg_approximation.md.
# Every replacement is asserted, so a silent no-op cannot slip through.
# Pure ASCII file; the replacement strings carry no non-ASCII characters.
$ErrorActionPreference = 'Stop'
$t = [IO.File]::ReadAllText($src, [Text.Encoding]::UTF8)

$edits = @(
  # 1. the RSA values are from an AlphaFold model, not a crystal structure
  @{ old = 'manual flags contradicted true crystallographic RSA values in `jak2_rsa.csv`:'
     new = 'manual flags contradicted the measured RSA values in `jak2_rsa.csv` (relative solvent accessibility reported by mCSM on the AlphaFold model AF-O60674-F1 -- no full-length experimental JAK2 structure exists, so these are model values, not crystallographic ones):'
     n = 1 },
  @{ old = 'but crystallographic RSA shows'; new = 'but the measured RSA is'; n = 4 },
  # 2. the independent reimplementation was PowerShell; no Python was run
  @{ old = 'reimplementation in PowerShell/Python, and benchmarking'
     new = 'reimplementation in PowerShell, and benchmarking'; n = 1 },
  # 3. H667 is not "strictly LOF", and Y581C has no functional data at all
  @{ old = 'is refuted by deep mutational scanning (DMS) datasets (e.g. TYK2 DMS where JH2 H667 mutations are strictly LOF, and JAK3 Y581C).'
     new = 'is contradicted by the TYK2 deep mutational scan, where every substitution at the JH2 position H667 *reduces* IFN-alpha signalling rather than increasing it -- although the mildest, H667C at $-0.13 \pm 0.28$, is indistinguishable from wild type. JAK3 Y581C is not counter-evidence either way: it has no functional measurement at all, and `external_data/JAK3/jak3_homology_inf.md` concludes that its direction cannot be inferred from position plus predicted effect.'
     n = 1 },
  # 4. cite the evidence
  @{ old = '> ### What Remains Valid as a Conceptual Framework:'
     new = @'
> ### Evidence behind this audit:
> - [`ddg_approximation_review.md`](ddg_approximation_review.md) -- the full review, with the three tests and the per-variant breakdown.
> - [`../../pipeline/ddg/check_approximator.ps1`](../../pipeline/ddg/check_approximator.ps1) -- an independent reimplementation of `compute_ddg` that reproduces every number quoted above. Run it with no arguments; it fetches `jak2_variants_multimethod.csv` itself and needs no Python.
>
> ### What Remains Valid as a Conceptual Framework:
'@
     n = 1 },
  # 5. the benchmark section is no longer section 5, so stop pointing at it.
  #    The section sign is built from its code point: a literal one in this ASCII .ps1 would be
  #    mangled by PowerShell 5.1 reading the file as ANSI.
  @{ old = ('The table below contrasts the values originally published in ' + [char]0x00A7 + '5 against')
     new = 'The table below contrasts the values originally published in the benchmark section of this document against'
     n = 1 },
  # 6. table vs code, not code vs truth: both are wrong, but this row is about the mismatch
  # multiplication sign built from its code point, same ANSI reason as above
  @{ old = ('**2.6' + [char]0x00D7 + ' Overestimate in code:**')
     new = '**Table understates the code 2.6x:**'; n = 1 },
  # 7. residue volumes still out of order at the end of the table (line endings may be LF)
  @{ old = "| **W** | Trp | 227.8 | 0 | -0.9 |`n| **R** | Arg | 225.0 | +1 | -4.5 |"
     new = "| **R** | Arg | 225.0 | +1 | -4.5 |`n| **W** | Trp | 227.8 | 0 | -0.9 |"
     n = 1 }
)
$t = $t -replace "`r`n", "`n"   # normalise first, so the row swap above matches either way

foreach ($e in $edits) {
  $found = ([regex]::Matches($t, [regex]::Escape($e.old))).Count
  if ($found -ne $e.n) {
    throw "expected $($e.n) occurrence(s) of `"$($e.old.Substring(0, [Math]::Min(60, $e.old.Length)))...`" but found $found"
  }
  $t = $t.Replace($e.old, $e.new)
  "ok  x$found  $($e.old.Substring(0, [Math]::Min(58, $e.old.Length)))"
}

[IO.File]::WriteAllText($dst, $t, (New-Object Text.UTF8Encoding($false)))
$chk = [IO.File]::ReadAllText($dst, [Text.Encoding]::UTF8)
''
"crystallographic left: $(([regex]::Matches($chk,'crystallographic')).Count)"
"review linked: $(([regex]::Matches($chk,'ddg_approximation_review')).Count)"
"check script linked: $(([regex]::Matches($chk,'check_approximator')).Count)"
"size $([math]::Round((Get-Item $dst).Length/1KB,1)) KB (was $([math]::Round((Get-Item $src).Length/1KB,1)) KB)"
