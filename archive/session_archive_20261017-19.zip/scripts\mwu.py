"""Mann-Whitney U (two-sided, normal approximation with tie correction) — no SciPy needed."""
import math
from statistics import median


def mwu(a, b):
    n1, n2 = len(a), len(b)
    allv = sorted([(v, 0) for v in a] + [(v, 1) for v in b])
    ranks, i = [0.0] * len(allv), 0
    while i < len(allv):
        j = i
        while j + 1 < len(allv) and allv[j + 1][0] == allv[i][0]:
            j += 1
        r = (i + j) / 2 + 1
        for k in range(i, j + 1):
            ranks[k] = r
        i = j + 1
    r1 = sum(r for r, (v, g) in zip(ranks, allv) if g == 0)
    u1 = r1 - n1 * (n1 + 1) / 2
    u = min(u1, n1 * n2 - u1)
    mu = n1 * n2 / 2
    counts = {}
    for v, _ in allv:
        counts[v] = counts.get(v, 0) + 1
    tie = sum(t ** 3 - t for t in counts.values())
    n = n1 + n2
    sd = math.sqrt(n1 * n2 / 12 * ((n + 1) - tie / (n * (n - 1))))
    z = (abs(u - mu) - 0.5) / sd
    return 2 * (1 - 0.5 * (1 + math.erf(z / math.sqrt(2))))


wt = [19.7, 91.2, 57.6, 89.0, 19.7, 77.8, 67.0, 16.2, 90.9, 65.3, 15.9, 23.2, 71.3, 21.1, 67.7, 17.1]
m1 = [85.9, 83.6, 90.3, 89.5, 22.0, 88.5, 90.1, 89.0]
m2 = [2.0, 14.7, 1.7, 20.6, 91.5, 1.4, 88.5, 1.5]
m = m1 + m2
print(f"reference-distance metric (mutation_analysis.md's 'vs closed/AF2' column)")
print(f"  WT     n=16 median {median(wt):.1f}  (published value 61.5 - check)")
print(f"  M511I  n=16 median {median(m):.1f}  halves {median(m1):.1f} / {median(m2):.1f}")
print(f"  M511I vs WT:        MW p = {mwu(m, wt):.3f}")
print(f"  M511I half vs half: MW p = {mwu(m1, m2):.4f}")
print(f"  within 15 A of reference: WT {sum(v < 15 for v in wt)}/16, M511I {sum(v < 15 for v in m)}/16")
