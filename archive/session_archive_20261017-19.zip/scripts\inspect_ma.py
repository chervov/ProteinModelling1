"""Inspect a ModelArchive JAK pair model: chains, UniProt mapping, pLDDT, domain distances, interface."""
import difflib, sys, urllib.request, json
import numpy as np

pdb = sys.argv[1]
UNI = {"JAK1": "P23458", "JAK3": "P52333"}
THREE = {"ALA":"A","ARG":"R","ASN":"N","ASP":"D","CYS":"C","GLN":"Q","GLU":"E","GLY":"G","HIS":"H","ILE":"I",
         "LEU":"L","LYS":"K","MET":"M","PHE":"F","PRO":"P","SER":"S","THR":"T","TRP":"W","TYR":"Y","VAL":"V"}

atoms = {}
for l in open(pdb):
    if l.startswith("ATOM"):
        ch, r = l[21], int(l[22:26])
        atoms.setdefault(ch, {}).setdefault(r, {"aa": THREE.get(l[17:20], "X"), "xyz": [], "b": float(l[60:66])})
        atoms[ch][r]["xyz"].append([float(l[30:38]), float(l[38:46]), float(l[46:54])])
        if l[12:16].strip() == "CA":
            atoms[ch][r]["ca"] = np.array(atoms[ch][r]["xyz"][-1])

import os
DATA = os.path.dirname(os.path.abspath(pdb))

def uniprot(acc):
    # pre-downloaded: <acc>.fasta and <acc>.json (fields=ft_domain) next to the PDB
    seq = "".join(open(os.path.join(DATA, f"{acc}.fasta")).read().splitlines()[1:])
    feats = json.load(open(os.path.join(DATA, f"{acc}.json")))["features"]
    doms = {f["description"]: (f["location"]["start"]["value"], f["location"]["end"]["value"]) for f in feats if f["type"] == "Domain"}
    return seq, doms

unis = {g: uniprot(a) for g, a in UNI.items()}
maps = {}
for ch, res in atoms.items():
    nums = sorted(res)
    seq = "".join(res[n]["aa"] for n in nums)
    best = None
    for g, (useq, doms) in unis.items():
        sm = difflib.SequenceMatcher(None, seq, useq, autojunk=False)
        m = sum(b.size for b in sm.get_matching_blocks())
        if not best or m > best[1]:
            best = (g, m, sm)
    g, m, sm = best
    mp = {nums[b.a + k]: b.b + k + 1 for b in sm.get_matching_blocks() for k in range(b.size)}
    maps[ch] = (g, mp)
    u = sorted(mp.values())
    b = [res[n]["b"] for n in nums]
    print(f"chain {ch}: {len(nums)} residues, model {nums[0]}-{nums[-1]} -> {g} UniProt {u[0]}-{u[-1]}, "
          f"identity {m}/{len(seq)}, mean pLDDT {np.mean(b):.1f}")
    for dn, (s, e) in unis[g][1].items():
        rs = [n for n in nums if s <= mp.get(n, -1) <= e]
        if rs:
            print(f"   {dn:18s} UniProt {s}-{e}: {len(rs)} res modelled, pLDDT {np.mean([res[n]['b'] for n in rs]):.1f}")

def cen(ch, dom):
    g, mp = maps[ch]; s, e = unis[g][1][dom]
    return np.mean([atoms[ch][n]["ca"] for n in atoms[ch] if s <= mp.get(n, -1) <= e and "ca" in atoms[ch][n]], axis=0)

chs = sorted(atoms)
for ch in chs:
    print(f"chain {ch} ({maps[ch][0]}) JH2–JH1 centroid distance: {np.linalg.norm(cen(ch,'Protein kinase 1') - cen(ch,'Protein kinase 2')):.1f} Å")

# interface: residue pairs with any heavy atoms within 5 Å
a, b = chs[0], chs[1]
def domname(ch, n):
    g, mp = maps[ch]; u = mp.get(n)
    for dn, (s, e) in unis[g][1].items():
        if u and s <= u <= e:
            return {"Protein kinase 1": "JH2", "Protein kinase 2": "JH1"}.get(dn, dn)
    return "linker"
contacts = {}
B = {n: np.array(v["xyz"]) for n, v in atoms[b].items()}
for na, va in atoms[a].items():
    A = np.array(va["xyz"])
    for nb, xb in B.items():
        if np.linalg.norm(va["ca"] - atoms[b][nb]["ca"]) > 20:
            continue
        if (np.linalg.norm(A[:, None] - xb[None], axis=2) < 5).any():
            key = (domname(a, na), domname(b, nb))
            contacts.setdefault(key, set()).add((na, nb))
print(f"\nInterface {a}({maps[a][0]}) – {b}({maps[b][0]}), residue pairs within 5 Å:")
for (da, db), pairs in sorted(contacts.items(), key=lambda kv: -len(kv[1])):
    ua = sorted({maps[a][1].get(x) for x, _ in pairs if maps[a][1].get(x)})
    ub = sorted({maps[b][1].get(y) for _, y in pairs if maps[b][1].get(y)})
    print(f"  {maps[a][0]} {da} – {maps[b][0]} {db}: {len(pairs)} pairs; {maps[a][0]} res {ua[0]}-{ua[-1]}, {maps[b][0]} res {ub[0]}-{ub[-1]}")
