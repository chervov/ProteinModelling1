"""Selected-structure domain distances per seed from a backed-up inference folder (long-path safe)."""
import glob, json, os, sys
import numpy as np

DOM = {"FERM": (26, 431), "JH2": (589, 875), "JH1": (897, 1176)}


def ca(path):
    out, b = {}, {}
    for l in open(path):
        if l.startswith("ATOM") and l[12:16].strip() == "CA":
            r = int(l[22:26]); out[r] = np.array([float(l[30:38]), float(l[38:46]), float(l[46:54])]); b[r] = float(l[60:66])
    return out, b


def cen(c, d):
    lo, hi = DOM[d]
    return np.mean([v for k, v in c.items() if lo <= k <= hi], axis=0)


inf = "\\\\?\\" + os.path.abspath(sys.argv[1])
rows = []
for sd in sorted(glob.glob(os.path.join(inf, "seed_*"))):
    pdb = glob.glob(os.path.join(sd, "predictions", "*", "*_model_1_unrelaxed.pdb"))
    pdb = [p for p in pdb if "_last_" not in p]
    if not pdb:
        continue
    c, b = ca(pdb[0])
    met = glob.glob(os.path.join(sd, "predictions", "*", "metrics.json")) + glob.glob(os.path.join(sd, "predictions", "metrics.json"))
    rec = json.load(open(met[0])).get("selected_recycle_index") if met else None
    rows.append((int(sd.rsplit("_", 1)[1]), rec, np.mean(list(b.values())),
                 np.linalg.norm(cen(c, "JH2") - cen(c, "JH1")), np.linalg.norm(cen(c, "FERM") - cen(c, "JH1"))))
print("seed recycle pLDDT JH2-JH1 FERM-JH1")
for r in rows:
    print(f"{r[0]:4d} {str(r[1]):>7} {r[2]:5.1f} {r[3]:7.1f} {r[4]:8.1f}")
print("FERM", [round(r[4], 1) for r in rows])
print("JH2", [round(r[3], 1) for r in rows])
