"""Bimodality check, and mutation effects measured as open/compact state counts (Fisher) rather than medians."""
import csv, math
from collections import defaultdict
from statistics import median

C = math.comb


def fisher2(a, b, c, d):
    n, r1, c1 = a + b + c + d, a + b, a + c
    probs = {k: C(r1, k) * C(n - r1, c1 - k) / C(n, c1)
             for k in range(max(0, c1 - (n - r1)), min(r1, c1) + 1)}
    p0 = probs[a]
    return min(1.0, sum(p for p in probs.values() if p <= p0 + 1e-12))


rows = list(csv.DictReader(open("master_seeds.csv", encoding="utf-8")))
cond = defaultdict(list)
for r in rows:
    if r["template"] != "none" or not r["ferm_jh1"]:
        continue
    cond[(r["target"], r["mutation"], r["msa"])].append(float(r["ferm_jh1"]))

OPEN = 80.0      # FERM-JH1 above this = extended/open; below ~60 = compact
GAP_LO, GAP_HI = 60.0, 80.0


def bimodal(v):
    """fraction of seeds sitting in the 60-80 A gap between the two basins"""
    return sum(GAP_LO <= x <= GAP_HI for x in v) / len(v)


print("=" * 104)
print("BIMODALITY: how many seeds sit in neither basin (FERM-JH1 60-80 A)")
print("=" * 104)
for k in sorted(cond):
    v = cond[k]
    if len(v) < 5:
        continue
    o = sum(x > OPEN for x in v)
    c = sum(x < GAP_LO for x in v)
    mid = len(v) - o - c
    flag = "  BIMODAL" if (o >= 2 and c >= 2) else ""
    print(f"  {k[0]:5s} {k[1]:6s} {k[2]:9s} n={len(v):3d}  open {o:2d}  compact {c:2d}  between {mid:2d}  "
          f"median {median(v):5.1f}{flag}")

print()
print("=" * 104)
print("MUTATION EFFECT AS STATE COUNTS  (open = FERM-JH1 > 80 A), Fisher exact")
print("=" * 104)
print(f"  {'target':5s} {'mutation':9s} {'msa':9s} {'WT open':>9s} {'mut open':>9s} {'Fisher p':>9s}")
res = []
for k in sorted(cond):
    tgt, mut, msa = k
    if mut == "WT":
        continue
    wt = cond.get((tgt, "WT", msa))
    if not wt or len(wt) < 5 or len(cond[k]) < 5:
        continue
    a, b = sum(x > OPEN for x in wt), len(wt) - sum(x > OPEN for x in wt)
    c, d = sum(x > OPEN for x in cond[k]), len(cond[k]) - sum(x > OPEN for x in cond[k])
    p = fisher2(a, b, c, d)
    star = "  <<<" if p < 0.05 else ""
    print(f"  {tgt:5s} {mut:9s} {msa:9s} {a:4d}/{a+b:<4d} {c:4d}/{c+d:<4d} {p:9.4f}{star}")
    res.append((p, tgt, mut, msa, f"{a}/{a+b}", f"{c}/{c+d}"))

print()
print("=" * 104)
print("RANKED BY SIGNIFICANCE")
print("=" * 104)
for p, tgt, mut, msa, w, m in sorted(res):
    verdict = "opens" if int(m.split("/")[0]) / int(m.split("/")[1]) > int(w.split("/")[0]) / int(w.split("/")[1]) else "closes"
    print(f"  p={p:.5f}  {tgt} {mut} at {msa}: wild type {w} open -> mutant {m} open  ({verdict})")
