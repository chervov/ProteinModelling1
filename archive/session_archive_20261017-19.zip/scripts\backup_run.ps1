# Copies a molab run folder to this computer through marimo's server-side file API (never touches the kernel).
param(
    [string]$Url = "https://sb-e4d409dd2ae4c514.sb.molab.run",
    [string]$Remote = "/content/protein_predictions/runs/TYK2_P982A_20261017_181325",
    [string]$Local = "TYK2_P982A_20261017_181325"
)
$tok = $env:MARIMO_TOKEN
function Post($ep, $path) {
    $body = @{ path = $path } | ConvertTo-Json -Compress
    [IO.File]::WriteAllText("$PWD\bk_req.json", $body)
    $out = curl.exe -s --max-time 60 -X POST "$Url/api/files/$ep" -H "Authorization: Bearer [REDACTED] -H "Content-Type: application/json" --data-binary "@bk_req.json"
    if ($LASTEXITCODE -ne 0) { throw "curl $LASTEXITCODE on $path" }
    return ($out -join "`n") | ConvertFrom-Json
}
$n = 0
function Copy-Tree($remote, $local) {
    New-Item -ItemType Directory -Force $local | Out-Null
    foreach ($f in (Post "list_files" $remote).files) {
        $dst = Join-Path $local $f.name
        if ($f.isDirectory) { Copy-Tree $f.path $dst }
        else {
            $c = (Post "file_details" $f.path).contents
            [IO.File]::WriteAllText($dst, $c, (New-Object Text.UTF8Encoding $false))
            $script:n++
        }
    }
}
Copy-Tree $Remote $Local
"copied $n files"
