"""Parse every downloaded run (conclusions.md + run_config.json) into one CSV of per-seed selected values."""
import csv, glob, json, os, re

rows = []
meta_rows = []
for md in sorted(glob.glob("repo_md/*.md")):
    run = os.path.basename(md)[:-3]
    cfg_path = f"repo_md/{run}.json"
    cfg = {}
    if os.path.exists(cfg_path):
        try:
            cfg = json.load(open(cfg_path, encoding="utf-8"))
        except Exception:
            cfg = {}
    target = cfg.get("target") or run.split("_")[0]
    muts = ",".join(cfg.get("mutations") or []) or "WT"
    c, e = cfg.get("max_msa_clusters"), cfg.get("max_extra_msa")
    msa = "full" if (c is None and e is None) else f"{c}/{e}"
    tmpl = cfg.get("template_source")
    tmpl = "none" if not tmpl else (",".join(tmpl) if isinstance(tmpl, list) else str(tmpl))
    nrec = cfg.get("num_recycles")
    text = open(md, encoding="utf-8", errors="replace").read()

    # locate the per-seed table
    hdr_i, cols = None, None
    lines = text.splitlines()
    for i, l in enumerate(lines):
        # two table formats in this repo: TYK2/JAK3 (seed|recycle|pLDDT|JH2-JH1|FERM-JH1|vs ref)
        # and the earlier JAK1/JAK2 one (seed|FERM-JH1|vs open|vs closed|...|class|trajectory)
        if l.startswith("|") and re.match(r"\|\s*seed\s*\|", l, re.I) and re.search(r"pLDDT|FERM", l, re.I):
            cols = [x.strip().lower() for x in l.strip("|").split("|")]
            hdr_i = i
            break
    n_seed = 0
    if hdr_i is not None:
        def col(*names):
            for n in names:
                for j, cn in enumerate(cols):
                    if n in cn:
                        return j
            return None
        i_seed, i_rec, i_pl = col("seed"), col("recycle"), col("plddt")
        i_jj = col("jh2–jh1", "jh2-jh1", "jh1–jh2", "jh1-jh2")
        i_fj = col("ferm–jh1", "ferm-jh1", "ferm")
        i_cls = col("class")
        i_vo, i_vc = col("vs open"), col("vs closed")
        if i_jj is not None and "contact" in cols[i_jj]:
            i_jj = None   # that column is a contact count, not a distance
        for l in lines[hdr_i + 2:]:
            if not l.startswith("|"):
                break
            cells = [x.strip() for x in l.strip("|").split("|")]
            if len(cells) < len(cols):
                continue
            def num(j):
                if j is None or j >= len(cells):
                    return ""
                m = re.search(r"-?\d+\.?\d*", cells[j].replace("**", ""))
                return m.group(0) if m else ""
            s = num(i_seed)
            if s == "":
                continue
            cls = cells[i_cls].replace("**", "").strip() if (i_cls is not None and i_cls < len(cells)) else ""
            rows.append({"run": run, "target": target, "mutation": muts, "msa": msa, "template": tmpl,
                         "recycles": nrec, "seed": s, "sel_recycle": num(i_rec), "plddt": num(i_pl),
                         "jh2_jh1": num(i_jj), "ferm_jh1": num(i_fj),
                         "vs_open": num(i_vo), "vs_closed": num(i_vc), "class": cls})
            n_seed += 1
    meta_rows.append({"run": run, "target": target, "mutation": muts, "msa": msa, "template": tmpl,
                      "recycles": nrec, "seeds_parsed": n_seed, "has_config": bool(cfg)})

with open("master_seeds.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)
with open("master_runs.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(meta_rows[0].keys()))
    w.writeheader()
    w.writerows(meta_rows)

print(f"{len(meta_rows)} runs, {len(rows)} seed rows")
no_tbl = [m["run"] for m in meta_rows if m["seeds_parsed"] == 0]
print(f"runs with no parsable per-seed table: {len(no_tbl)}")
for r in no_tbl:
    print("   ", r)
no_cfg = [m["run"] for m in meta_rows if not m["has_config"]]
if no_cfg:
    print("runs with no run_config.json:", no_cfg)
