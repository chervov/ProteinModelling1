# Session archive — 17–19 October 2026

Working session covering the TYK2 MSA depth scan, the V678F positive control, completion of JAK3 M511I and
JAK2 V617F, and a re-analysis of every run in this repository.

## Contents

```
transcript/     full conversation transcript (JSONL) + session metadata, CREDENTIALS REDACTED
scripts/        the tooling written during the session
data/           master_seeds.csv, master_runs.csv — every run's per-seed values, parsed
```

## Credentials

The transcript has been scrubbed before archiving: **994** molab agent tokens, **532** `Authorization: Bearer`
headers, **6** GitHub personal access tokens, **4** `x-access-token` URLs and **4** email addresses were
replaced with `[REDACTED_*]` placeholders, and a verification pass confirms nothing credential-shaped
remains. `scripts/scrub.py` is the tool that did it and can be re-run to re-check.

Note: the tokens that appeared in this session should be treated as compromised regardless, since they were
typed into a chat window. Rotate them.

## Scripts

| file | purpose |
|---|---|
| `marimo-exec.ps1` | run Python in a live marimo kernel over HTTP (PowerShell port of the marimo-pair helper, which needs bash/jq/curl). **Includes a busy-kernel guard** — see below. |
| `monitor.ps1` | watch a molab sandbox through the file API and copy results locally every 3 min, so a terminated sandbox costs at most one interval |
| `backup_run.ps1` | copy a finished run folder off a sandbox |
| `build_partial.py` | rebuild a repo-format run folder from an incremental backup when the sandbox died before the notebook's save step |
| `push_run.ps1` / `push_file.ps1` | push a folder or single file to GitHub via the REST API, no git needed; tree built in chunks (one call times out past ~150 entries) |
| `write_conclusions_generic.py` | generate a run's `conclusions.md` in the repo's standard format; domains/reference are parameterised per target |
| `analyze_backup.py` | per-seed domain distances straight from a backup, no kernel needed |
| `build_master.py` | parse every run's `conclusions.md` + `run_config.json` into one per-seed table |
| `analyze_master.py` | coverage, mutation-vs-wild-type tests, depth profiles, batch variance, pLDDT by depth |
| `analyze_states.py` | the same comparisons as open/compact state counts (Fisher) — the right test for these bimodal distributions |
| `mwu.py` | Mann-Whitney U with tie correction, pure Python (local SciPy is broken) |
| `queue_config.py` / `queue_seeds.py` | set the notebook's config cell and queue a run fire-and-forget |

## Three failure modes this tooling exists to avoid

1. **Disconnecting from `/api/kernel/execute` interrupts the kernel.** marimo calls `session.try_interrupt()`
   when the HTTP client disconnects, so a timed-out status probe raises `KeyboardInterrupt` in the running
   cell. This interrupted three runs on 17 October and killed a kernel outright on 18 October (the OpenFold
   subprocess was reparented to init and kept computing with no notebook to collect it). `marimo-exec.ps1`
   now scans `/proc/*/cmdline` and refuses to send code while a job is running.
2. **Sandboxes end without warning**, about 6.5 h in observed cases, sometimes mid-run. Hence `monitor.ps1`
   backing up continuously and `build_partial.py` rebuilding from what was saved.
3. **A stale `<TARGET>.fasta`** left in a sandbox's shared `fasta/` folder makes the runner try to predict
   the previous target too, and it dies on the missing alignment directory. Clear `fasta/` when switching
   target.

## Findings

See [`cross_run_analysis_20261018.md`](../cross_run_analysis_20261018.md) and
[`conclusions_20261018_205000.md`](../conclusions_20261018_205000.md) in the repository root. In short:

- The canonical activating mutations are detectable (JAK2 V617F at 512/8192: 7/16 → 16/16 open, p = 0.0008).
- Detection only works where wild type is partially open; at a floor or ceiling every test returns p = 1.00.
- The V617F "depth reversal" was traced to an anomalous JAK2 wild-type point at 256/1024, not to the mutation.
- **Batch-to-batch variance between runs of the same condition is as large as the effects being measured.**
  A coordinate here is either saturated and reproducible, or responsive and irreproducible. Quantifying that
  variance is the prerequisite for further mutation screening.
