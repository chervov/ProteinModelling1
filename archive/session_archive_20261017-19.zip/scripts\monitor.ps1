# Watches a molab marimo sandbox through the server's file API (works while the kernel is busy;
# never touches the kernel, so it cannot interrupt a run).
# Copies new/changed result files under /content/protein_predictions whose path contains $Match
# to $BackupDir as they appear, so a terminated sandbox loses at most one interval of work.
# Exits (so the caller is notified) on: sandbox unreachable, stall, results found, or max time.
param(
    [string]$Url,
    [int]$IntervalSec = 180,
    [int]$StallMin = 45,
    [int]$MaxHours = 5,
    [string]$Log = "monitor.log",
    [string]$Match = "",      # only a selection_report.json whose path contains this counts as "results"
    [string]$BackupDir = ""   # local folder for incremental copies ("" = no backup)
)
$tok = $env:MARIMO_TOKEN
$start = Get-Date
$lastChange = Get-Date
$lastSig = ""
$fails = 0
$req = "$PWD\mon_req_$([IO.Path]::GetFileNameWithoutExtension($Log)).json"
$copied = @{}   # remote path -> lastModified already copied
$backupAbs = if ($BackupDir) { [IO.Path]::GetFullPath((Join-Path $PWD $BackupDir)).TrimEnd("\") } else { "" }
$textExt = @(".pdb", ".json", ".jsonl", ".csv", ".log", ".txt", ".md", ".a3m", ".sto", ".fasta", ".cif")

function Api($path, $json, $maxTime = 20) {
    $args = @("-s", "--max-time", "$maxTime", "-H", "Authorization: Bearer [REDACTED]
    if ($json) {
        [IO.File]::WriteAllText($req, $json)
        $args += @("-X", "POST", "-H", "Content-Type: application/json", "--data-binary", "@$req")
    }
    $out = & curl.exe @args "$Url$path"
    if ($LASTEXITCODE -ne 0 -or -not $out) { throw "curl exit $LASTEXITCODE" }
    return (($out -join "`n") | ConvertFrom-Json)
}

function ListTree($path, $depth) {
    $r = Api "/api/files/list_files" (@{ path = $path } | ConvertTo-Json -Compress)
    foreach ($f in $r.files) {
        $f
        if ($f.isDirectory -and $depth -gt 0 -and $f.path -ne "/content/openfold") { ListTree $f.path ($depth - 1) }
    }
}

function Say($msg) { $line = "$(Get-Date -Format 'HH:mm:ss') $msg"; Add-Content -Path $Log -Value $line; Write-Output $line }

function Backup($files) {
    if (-not $BackupDir) { return }
    $n = 0
    foreach ($f in $files) {
        if ($f.isDirectory -or $f.path -notlike "/content/protein_predictions/*" -or $f.path -notlike "*$Match*") { continue }
        if ($textExt -notcontains [IO.Path]::GetExtension($f.name).ToLower()) { continue }
        if ($copied[$f.path] -eq $f.lastModified) { continue }
        try {
            $c = (Api "/api/files/file_details" (@{ path = $f.path } | ConvertTo-Json -Compress) 90).contents
            # \\?\ prefix: these paths exceed Windows' 260-character MAX_PATH
            $dst = "\\?\" + $backupAbs + "\" + $f.path.Substring("/content/protein_predictions/".Length).Replace("/", "\")
            [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($dst)) | Out-Null
            [IO.File]::WriteAllText($dst, $c, (New-Object Text.UTF8Encoding $false))
            $copied[$f.path] = $f.lastModified
            $n++
        } catch { Say "backup failed for $($f.path): $($_.Exception.Message)" }
    }
    if ($n) { Say "backed up $n new/changed files (total $($copied.Count)) to $BackupDir" }
}

Say "monitor started for $Url"
$files = @()
while ($true) {
    try {
        $st = Api "/api/status" $null
        $files = @(ListTree "/content" 7)
        $fails = 0
        $nonDir = @($files | Where-Object { -not $_.isDirectory })
        $newest = $files | Sort-Object lastModified -Descending | Select-Object -First 1
        $sig = "$($files.Count)|$($newest.path)|$($newest.lastModified)"
        if ($sig -ne $lastSig) { $lastChange = Get-Date; $lastSig = $sig }
        $idle = [int]((Get-Date) - $lastChange).TotalMinutes
        Say ("status={0} entries={1} files={2} newest={3} idle={4}m" -f $st.status, $files.Count, $nonDir.Count, $newest.path, $idle)
        Backup $files
        $done = @($files | Where-Object { $_.name -eq "selection_report.json" -and $_.path -like "*$Match*" })
        if ($done.Count -gt 0) { Say "EVENT results: $($done[0].path)"; exit 0 }
        if ($idle -ge $StallMin) { Say "EVENT stall: no new files for $idle min"; exit 2 }
    } catch {
        $fails++
        Say "check failed ($fails): $($_.Exception.Message)"
        if ($fails -ge 3) { Say "EVENT unreachable: sandbox not responding"; exit 3 }
    }
    if (((Get-Date) - $start).TotalHours -ge $MaxHours) { Say "EVENT maxtime"; exit 4 }
    Start-Sleep -Seconds $IntervalSec
}
