# PowerShell port of marimo-pair's execute-code.sh.
# Usage: .\marimo-exec.ps1 -Url URL [-File KEY | -Session ID] (-Code "..." | -CodeFile path)
# Auth: MARIMO_TOKEN env var.
param(
    [Parameter(Mandatory)] [string]$Url,
    [string]$Code,
    [string]$CodeFile,
    [string]$File,
    [string]$Session,
    [int]$TimeoutSec = 600,
    [switch]$Force   # skip the busy-kernel guard
)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
if ($CodeFile) { $Code = Get-Content -Raw -Encoding UTF8 $CodeFile }
if (-not $Code) { throw "Pass -Code or -CodeFile." }

$base = $Url.TrimEnd('/')
$headers = @{}
if ($env:MARIMO_TOKEN) { $headers['Authorization'] = "Bearer $($env:MARIMO_TOKEN)" }

# Busy-kernel guard. A client disconnect on /api/kernel/execute makes marimo call
# session.try_interrupt(), which kills whatever cell is running — so never POST while a job is active.
if (-not $Force) {
    try {
        $procs = Invoke-RestMethod -Uri "$base/api/files/list_files" -Method Post -Headers $headers `
            -ContentType 'application/json' -Body '{"path":"/proc"}' -TimeoutSec 20
        foreach ($d in ($procs.files | Where-Object { $_.name -match '^\d+$' })) {
            $cl = (Invoke-RestMethod -Uri "$base/api/files/file_details" -Method Post -Headers $headers `
                -ContentType 'application/json' -Body (@{ path = "/proc/$($d.name)/cmdline" } | ConvertTo-Json -Compress) `
                -TimeoutSec 20).contents -replace "`0", " "
            if ($cl -match 'run_pretrained_openfold|pip install|download_alphafold_params|aria2c|colabfold|ninja') {
                throw "Kernel is BUSY (pid $($d.name): $($cl.Trim().Substring(0, [Math]::Min(60, $cl.Trim().Length)))). " +
                      "Sending code now risks interrupting it. Wait, or pass -Force if you are sure."
            }
        }
    } catch {
        if ($_.Exception.Message -like "Kernel is BUSY*") { throw }
        # guard itself failed (sandbox gone etc.) - let the real call report it
    }
}

if (-not $Session) {
    $sessions = Invoke-RestMethod -Uri "$base/api/sessions" -Headers $headers -TimeoutSec 15
    $entries = @($sessions.PSObject.Properties)
    if ($File) { $entries = @($entries | Where-Object { $_.Value.path -eq $File -or $_.Value.filename -eq $File }) }
    if ($entries.Count -eq 0) { throw "No active sessions. Make sure the notebook is open in the browser." }
    if ($entries.Count -gt 1) {
        $entries | ForEach-Object { Write-Host "$($_.Name)  $($_.Value.path)$($_.Value.filename)" }
        throw "Multiple sessions; pass -File or -Session."
    }
    $Session = $entries[0].Name
}

$h = $headers.Clone()
$h['Marimo-Session-Id'] = $Session
$body = [Text.Encoding]::UTF8.GetBytes((@{ code = $Code } | ConvertTo-Json -Compress))
$resp = Invoke-WebRequest -Uri "$base/api/kernel/execute" -Method Post -Headers $h `
    -ContentType 'application/json' -Body $body -UseBasicParsing -TimeoutSec $TimeoutSec
$text = [Text.Encoding]::UTF8.GetString($resp.RawContentStream.ToArray())

$event = ''; $ok = $true; $done = $false
foreach ($line in ($text -split "`n")) {
    $line = $line.TrimEnd("`r")
    if ($line.StartsWith('event:')) { $event = $line.Substring(6).Trim() }
    elseif ($line.StartsWith('data:')) {
        $p = $line.Substring(5).Trim() | ConvertFrom-Json
        switch ($event) {
            'stdout' { Write-Output $p.data }
            'stderr' { Write-Output $p.data }
            'done'   { $done = $true; if ($p.success -eq $false) { $ok = $false } elseif ($p.output.data) { Write-Output $p.output.data } }
        }
    }
}
if (-not $done) { Write-Output "Execution did not complete. Raw response:"; Write-Output $text; exit 1 }
if (-not $ok) { exit 1 }
