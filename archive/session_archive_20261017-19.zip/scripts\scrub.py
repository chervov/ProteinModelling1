"""Redact credentials from the exported transcript before anything is published.
Scrubs: GitHub PATs, 64-hex molab agent tokens, Bearer headers, and the user's email."""
import os, re, sys

ROOT = sys.argv[1]
PATTERNS = [
    (re.compile(r"github_pat_[A-Za-z0-9_]{20,}"), "[REDACTED_GITHUB_PAT]"),
    (re.compile(r"gh[pousr]_[A-Za-z0-9]{30,}"), "[REDACTED_GITHUB_TOKEN]"),
    (re.compile(r"\b[0-9a-f]{64}\b"), "[REDACTED_MOLAB_TOKEN]"),
    (re.compile(r"(Authorization:\s*Bearer\s+)\S+", re.I), r"\1[REDACTED]"),
    (re.compile(r"(MARIMO_TOKEN\s*=\s*)[\"']?[A-Za-z0-9]{16,}[\"']?"), r"\1[REDACTED]"),
    (re.compile(r"x-access-token:[REDACTED]@\s]+@"), "x-access-token:[REDACTED]@"),
    (re.compile(r"al\.chervov@gmail\.com"), "[REDACTED_EMAIL]"),
]

total = {}
for dirpath, _, files in os.walk(ROOT):
    for fn in files:
        p = os.path.join(dirpath, fn)
        try:
            raw = open(p, "rb").read()
            text = raw.decode("utf-8", errors="surrogateescape")
        except Exception as e:
            print("SKIP (unreadable)", p, e)
            continue
        out = text
        for rx, repl in PATTERNS:
            out, n = rx.subn(repl, out)
            if n:
                total[rx.pattern] = total.get(rx.pattern, 0) + n
        if out != text:
            open(p, "wb").write(out.encode("utf-8", errors="surrogateescape"))
            print(f"scrubbed {os.path.relpath(p, ROOT)}")

print("\nreplacements by pattern:")
for k, v in sorted(total.items(), key=lambda x: -x[1]):
    print(f"  {v:5d}  {k}")

# verification pass: nothing credential-shaped may remain
LEAK = [
    re.compile(r"github_pat_[A-Za-z0-9_]{20,}"),
    re.compile(r"gh[pousr]_[A-Za-z0-9]{30,}"),
    re.compile(r"\b[0-9a-f]{64}\b"),
]
bad = 0
for dirpath, _, files in os.walk(ROOT):
    for fn in files:
        p = os.path.join(dirpath, fn)
        try:
            t = open(p, "rb").read().decode("utf-8", errors="surrogateescape")
        except Exception:
            continue
        for rx in LEAK:
            for m in rx.finditer(t):
                bad += 1
                if bad <= 5:
                    print("LEAK", os.path.relpath(p, ROOT), m.group(0)[:12] + "...")
print(f"\nVERIFY: {bad} credential-shaped strings remaining")
sys.exit(1 if bad else 0)
