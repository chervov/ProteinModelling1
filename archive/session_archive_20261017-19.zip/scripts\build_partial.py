"""Rebuild a run folder (repo layout) from a backed-up inference folder whose sandbox died before the
notebook's save step: all/seed_XXX/recycle_NN.pdb.gz + selected.pdb.gz + traces, run_config.json,
selected_metrics.json and conclusions.md (same tables as the other TYK2 runs).
Usage: python build_partial.py <backup inference dir> <out run dir> <ref AF2 pdb> <mutations,comma> <msa e.g. 32/64> <title> <intro>"""
import glob, gzip, json, os, re, shutil, sys
import numpy as np

src, out, ref_pdb, muts, msa, title, intro = sys.argv[1:8]
muts = "" if muts.lower() == "none" else muts   # PowerShell drops empty args, so wild type passes "none"
LP = "\\\\?\\"
src = LP + os.path.abspath(src)
DOM = {"FERM": (26, 431), "JH2": (589, 875), "JH1": (897, 1176)}


def read(path):
    ca, b = {}, {}
    for l in open(path):
        if l.startswith("ATOM") and l[12:16].strip() == "CA":
            r = int(l[22:26]); ca[r] = np.array([float(l[30:38]), float(l[38:46]), float(l[46:54])]); b[r] = float(l[60:66])
    return ca, b


def cen(ca, d):
    lo, hi = DOM[d]
    return np.mean([v for k, v in ca.items() if lo <= k <= hi], axis=0)


def jh1_rmsd(ca, ref):
    fit = [r for r in range(*DOM["JH2"]) if r in ca and r in ref]
    mov = [r for r in range(*DOM["JH1"]) if r in ca and r in ref]
    P, Q = np.array([ca[r] for r in fit]), np.array([ref[r] for r in fit])
    pc, qc = P.mean(0), Q.mean(0)
    u, s, vt = np.linalg.svd((P - pc).T @ (Q - qc))
    d = np.sign(np.linalg.det(vt.T @ u.T))
    R = vt.T @ np.diag([1, 1, d]) @ u.T
    A = np.array([ca[r] for r in mov]) @ R.T + (qc - pc @ R.T)
    return float(np.sqrt(((A - np.array([ref[r] for r in mov])) ** 2).sum(1).mean()))


def metrics(path, ref):
    ca, b = read(path)
    return {"plddt": float(np.mean(list(b.values()))),
            "jh2_jh1": float(np.linalg.norm(cen(ca, "JH2") - cen(ca, "JH1"))),
            "ferm_jh1": float(np.linalg.norm(cen(ca, "FERM") - cen(ca, "JH1"))),
            "vs_af2": jh1_rmsd(ca, ref)}


def gz(src_path, dst_path):
    with open(src_path, "rb") as fi, gzip.open(dst_path, "wb") as fo:
        shutil.copyfileobj(fi, fo)


ref, _ = read(ref_pdb)
name = os.path.basename(out)
os.makedirs(os.path.join(out, "all"), exist_ok=True)
traj, sel, index = {}, {}, ["seed,recycle,selected,plddt,jh2_jh1,ferm_jh1,vs_af2"]
for sd in sorted(glob.glob(os.path.join(src, "seed_*"))):
    seed = int(sd.rsplit("_", 1)[1])
    mdir = os.path.join(sd, "predictions", "TYK2_model_1")
    recs = sorted(glob.glob(os.path.join(mdir, "recycles", "*_recycle*_unrelaxed.pdb")))
    if not recs or not os.path.exists(os.path.join(mdir, "TYK2_model_1_unrelaxed.pdb")):
        continue
    sel[seed] = json.load(open(os.path.join(mdir, "metrics.json")))["selected_recycle_index"]
    dst = os.path.join(out, "all", f"seed_{seed:03d}")
    os.makedirs(dst, exist_ok=True)
    traj[seed] = {}
    for p in recs:
        r = int(re.search(r"recycle(\d+)_", p).group(1))
        traj[seed][r] = metrics(p, ref)
        gz(p, os.path.join(dst, f"recycle_{r:02d}.pdb.gz"))
    gz(os.path.join(mdir, "TYK2_model_1_unrelaxed.pdb"), os.path.join(dst, "selected.pdb.gz"))
    for f in ("metrics.json", "recycle_metrics.jsonl"):
        shutil.copy2(os.path.join(mdir, f), dst)
    for r, m in traj[seed].items():
        index.append(f"{seed},{r},{int(r == sel[seed])},{m['plddt']:.2f},{m['jh2_jh1']:.2f},{m['ferm_jh1']:.2f},{m['vs_af2']:.2f}")
open(os.path.join(out, "all", "index.csv"), "w").write("\n".join(index) + "\n")
seeds = sorted(traj)
recycles = sorted(traj[seeds[0]])
c, e = msa.split("/")
json.dump({"target": "TYK2", "uniprot": "P29597", "window_uniprot": [1, 1187], "mutations": [m for m in muts.split(",") if m],
           "max_msa_clusters": int(c), "max_extra_msa": int(e), "num_recycles": 15, "config_preset": "model_1",
           "random_seeds": "0,1,2,3,4,5,6,7", "seeds_completed": seeds, "template_source": None,
           "note": "rebuilt from incremental backup; sandbox terminated before the notebook's selection/save steps"},
          open(os.path.join(out, "run_config.json"), "w"), indent=2)
json.dump({str(s): {"selected_recycle": sel[s], **traj[s][sel[s]]} for s in seeds},
          open(os.path.join(out, "selected_metrics.json"), "w"), indent=1)

allc = [(s, r, m) for s in seeds for r, m in traj[s].items()]
L = [f"# {name} — {title}\n", intro + "\n\n\n"]
L.append("## References (centroid distances, Å)\n\n| reference | JH2–JH1 | FERM–JH1 |\n|---|--:|--:|")
L.append(f"| AF2 (AF-P29597-F1) | {np.linalg.norm(cen(ref, 'JH2') - cen(ref, 'JH1')):.1f} | {np.linalg.norm(cen(ref, 'FERM') - cen(ref, 'JH1')):.1f} |\n")
L.append("## Selected structure per seed (JH1 RMSD after superposing JH2, Å)\n")
L.append("| seed | recycle | pLDDT | JH2–JH1 (Å) | FERM–JH1 (Å) | vs AF2 | nearest |\n|--:|--:|--:|--:|--:|--:|---|")
for s in seeds:
    m = traj[s][sel[s]]
    L.append(f"| {s} | {sel[s]} | {m['plddt']:.1f} | {m['jh2_jh1']:.1f} | {m['ferm_jh1']:.1f} | {m['vs_af2']:.1f} | AF2 |")
best = min(allc, key=lambda x: x[2]["vs_af2"])
L.append("\n## All conformations\n\n| reference | closest (Å) | seed | recycle | pLDDT | within 15 Å |\n|---|--:|--:|--:|--:|--:|")
L.append(f"| AF2 (AF-P29597-F1) | {best[2]['vs_af2']:.1f} | {best[0]} | {best[1]} | {best[2]['plddt']:.1f} | {sum(x[2]['vs_af2'] <= 15 for x in allc)} |\n")
L.append("## Mean over seeds per recycle (Å)\n\n| recycle | pLDDT | FERM–JH1 | vs AF2 |\n|--:|--:|--:|--:|")
for r in recycles:
    ms = [traj[s][r] for s in seeds]
    L.append(f"| {r} | {np.mean([m['plddt'] for m in ms]):.1f} | {np.mean([m['ferm_jh1'] for m in ms]):.1f} | {np.mean([m['vs_af2'] for m in ms]):.1f} |")
rng = lambda k: (min(x[2][k] for x in allc), max(x[2][k] for x in allc))
L.append(f"\npLDDT {rng('plddt')[0]:.1f}–{rng('plddt')[1]:.1f}; JH2–JH1 {rng('jh2_jh1')[0]:.1f}–{rng('jh2_jh1')[1]:.1f} Å; "
         f"FERM–JH1 {rng('ferm_jh1')[0]:.1f}–{rng('ferm_jh1')[1]:.1f} Å (FERM–JH1 > ~80 Å = open, < ~50 Å = closed).")
L.append("## Per-seed trajectories (FERM–JH1 centroid distance, Å; open ~90+, closed ~40–45)\n\n| seed | recycles 1–15 | final |\n|--:|---|---|")
for s in seeds:
    vals = [traj[s][r]["ferm_jh1"] for r in recycles]
    st = "open-like (> 80)" if vals[-1] > 80 else ("closed-like (< 50)" if vals[-1] < 50 else "intermediate")
    L.append(f"| {s} | {' '.join(f'{v:.0f}' for v in vals)} | {st} |")
open(os.path.join(out, "conclusions.md"), "w", encoding="utf-8").write("\n".join(L) + "\n")
print(f"built {out}: seeds {seeds}, selected FERM–JH1", [round(traj[s][sel[s]]["ferm_jh1"], 1) for s in seeds])
