"""CA-centroid distances between TYK2 domains (UniProt numbering) for each seed PDB."""
import sys
import numpy as np

DOMAINS = {"FERM": (26, 431), "JH2": (589, 875), "JH1": (897, 1176)}


def ca(path):
    res = {}
    for line in open(path):
        if line.startswith("ATOM") and line[12:16].strip() == "CA":
            res[int(line[22:26])] = [float(line[30:38]), float(line[38:46]), float(line[46:54])]
    return res


def centroid(res, lo, hi):
    return np.mean([v for k, v in res.items() if lo <= k <= hi], axis=0)


print("seed  JH2-JH1  FERM-JH1")
for path in sys.argv[1:]:
    r = ca(path)
    c = {n: centroid(r, *rng) for n, rng in DOMAINS.items()}
    print(f"{path.split('seed')[-1].split('.')[0]:>4}  {np.linalg.norm(c['JH2'] - c['JH1']):7.1f}  {np.linalg.norm(c['FERM'] - c['JH1']):8.1f}")
