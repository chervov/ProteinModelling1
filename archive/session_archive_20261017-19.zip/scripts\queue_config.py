# Kernel scratchpad: prepend CONFIG = {"TARGET_INDEX": "2", "MUTATIONS": '["M511I"]', ...} and TAG = "...".
# Rewrites those lines in the config cell and queues the config cell + everything after it (fire-and-forget).
import marimo._code_mode as cm, re
from marimo._runtime.commands import ExecuteCellsCommand

ctx = cm.get_context()
idx, cfg = next((i, c) for i, c in enumerate(ctx.cells) if "TARGET_INDEX" in c.code and "MAX_MSA_CLUSTERS" in c.code)
new = cfg.code
for k, v in CONFIG.items():
    new, n = re.subn(rf"(?m)^{k} = .*$", f"{k} = {v}   # {TAG}", new)
    assert n == 1, k
async with cm.get_context() as c2:
    _ = c2.cells[cfg.id].code
    c2.edit_cell(cfg.id, code=new)
ctx = cm.get_context()
for k in ("TARGET_INDEX", "MUTATIONS", "RANDOM_SEEDS", "MAX_MSA_CLUSTERS", "MAX_EXTRA_MSA", "TEMPLATE_SOURCE"):
    print(re.search(rf"(?m)^{k} = .*$", ctx.cells[cfg.id].code).group(0))
cells = [c for i, c in enumerate(ctx.cells) if i >= idx and c.code.strip()]
ctx.enqueue_command(ExecuteCellsCommand(cell_ids=[c.id for c in cells], codes=[c.code for c in cells]))
print(f"queued {len(cells)} cells from config cell {cfg.id}")
