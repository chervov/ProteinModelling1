"""Cross-cutting analysis of every parsed run in the repo."""
import csv, math
from collections import defaultdict
from statistics import median, pstdev


def mwu(a, b):
    """Mann-Whitney U, two-sided, normal approx with tie correction."""
    n1, n2 = len(a), len(b)
    if n1 < 3 or n2 < 3:
        return float("nan")
    allv = sorted([(v, 0) for v in a] + [(v, 1) for v in b])
    ranks, i = [0.0] * len(allv), 0
    while i < len(allv):
        j = i
        while j + 1 < len(allv) and allv[j + 1][0] == allv[i][0]:
            j += 1
        for k in range(i, j + 1):
            ranks[k] = (i + j) / 2 + 1
        i = j + 1
    r1 = sum(r for r, (v, g) in zip(ranks, allv) if g == 0)
    u1 = r1 - n1 * (n1 + 1) / 2
    u = min(u1, n1 * n2 - u1)
    counts = defaultdict(int)
    for v, _ in allv:
        counts[v] += 1
    tie = sum(t ** 3 - t for t in counts.values())
    n = n1 + n2
    sd = math.sqrt(n1 * n2 / 12 * ((n + 1) - tie / (n * (n - 1))))
    if sd == 0:
        return float("nan")
    z = (abs(u - n1 * n2 / 2) - 0.5) / sd
    return 2 * (1 - 0.5 * (1 + math.erf(z / math.sqrt(2))))


rows = list(csv.DictReader(open("master_seeds.csv", encoding="utf-8")))
def f(r, k):
    try:
        return float(r[k])
    except Exception:
        return None

# group: (target, mutation, msa, template) -> list of seed dicts, and per-run
cond = defaultdict(list)
runs = defaultdict(list)
for r in rows:
    key = (r["target"], r["mutation"], r["msa"], r["template"])
    cond[key].append(r)
    runs[(key, r["run"])].append(r)

print("=" * 100)
print("1. COVERAGE  (target / mutation / MSA / template -> seeds, runs)")
print("=" * 100)
for k in sorted(cond, key=lambda x: (x[0], x[1] != "WT", x[1], x[2])):
    v = cond[k]
    fj = [f(r, "ferm_jh1") for r in v if f(r, "ferm_jh1") is not None]
    nr = len({r["run"] for r in v})
    med = f"{median(fj):6.1f}" if fj else "     -"
    print(f"  {k[0]:5s} {k[1]:8s} msa {k[2]:10s} tmpl {k[3][:14]:14s}  n={len(v):3d} runs={nr}  medianFERM-JH1 {med}")

print()
print("=" * 100)
print("2. MUTATION vs MATCHED WILD TYPE  (same target, MSA and template)")
print("=" * 100)
print(f"  {'target':5s} {'mutation':9s} {'msa':9s} {'tmpl':6s} {'n_mut':>5s} {'n_wt':>5s} "
      f"{'med_mut':>8s} {'med_wt':>7s} {'delta':>7s} {'MW p':>8s}")
hits = []
for k in sorted(cond):
    tgt, mut, msa, tmpl = k
    if mut == "WT":
        continue
    wt = cond.get((tgt, "WT", msa, tmpl))
    if not wt:
        continue
    a = [f(r, "ferm_jh1") for r in cond[k] if f(r, "ferm_jh1") is not None]
    b = [f(r, "ferm_jh1") for r in wt if f(r, "ferm_jh1") is not None]
    if len(a) < 3 or len(b) < 3:
        continue
    p = mwu(a, b)
    d = median(a) - median(b)
    star = "  <<<" if p < 0.05 else ""
    print(f"  {tgt:5s} {mut:9s} {msa:9s} {tmpl[:6]:6s} {len(a):5d} {len(b):5d} "
          f"{median(a):8.1f} {median(b):7.1f} {d:+7.1f} {p:8.3f}{star}")
    if p < 0.05:
        hits.append((tgt, mut, msa, d, p))

print()
print("=" * 100)
print("3. WILD-TYPE DEPTH PROFILE  (median FERM-JH1 per MSA depth, no template)")
print("=" * 100)
order = {"32/64": 0, "64/256": 1, "96/384": 2, "128/512": 3, "160/640": 4, "256/1024": 5, "512/8192": 6, "full": 7}
for tgt in ("JAK1", "JAK2", "JAK3", "TYK2"):
    out = []
    for k in sorted(cond, key=lambda x: order.get(x[2], 99)):
        if k[0] == tgt and k[1] == "WT" and k[3] == "none":
            fj = [f(r, "ferm_jh1") for r in cond[k] if f(r, "ferm_jh1") is not None]
            if fj:
                out.append(f"{k[2]}:{median(fj):.0f}(n{len(fj)})")
    if out:
        print(f"  {tgt:5s} " + "  ".join(out))

print()
print("=" * 100)
print("4. BATCH VARIANCE  (same condition split over >1 run)")
print("=" * 100)
for k in sorted(cond):
    rs = sorted({r["run"] for r in cond[k]})
    if len(rs) < 2:
        continue
    parts = []
    vals = []
    for rn in rs:
        fj = [f(r, "ferm_jh1") for r in cond[k] if r["run"] == rn and f(r, "ferm_jh1") is not None]
        if fj:
            parts.append(f"{rn.split('_')[-1]}: n{len(fj)} med {median(fj):.1f}")
            vals.append(fj)
    if len(vals) == 2:
        p = mwu(vals[0], vals[1])
        star = "  <<< halves disagree" if p < 0.10 else ""
        print(f"  {k[0]:5s} {k[1]:8s} {k[2]:9s} | " + " | ".join(parts) + f" | MW p={p:.3f}{star}")

print()
print("=" * 100)
print("5. CONFIDENCE vs MSA DEPTH  (mean pLDDT of selected structures)")
print("=" * 100)
by_msa = defaultdict(list)
for r in rows:
    pl = f(r, "plddt")
    if pl:
        by_msa[(r["target"], r["msa"])].append(pl)
for k in sorted(by_msa, key=lambda x: (x[0], order.get(x[1], 99))):
    v = by_msa[k]
    print(f"  {k[0]:5s} msa {k[1]:9s} n={len(v):3d}  mean pLDDT {sum(v)/len(v):5.1f}  sd {pstdev(v):4.1f}")

print()
print("=" * 100)
print("6. SIGNIFICANT RESULTS")
print("=" * 100)
for h in sorted(hits, key=lambda x: x[4]):
    print(f"  {h[0]} {h[1]} at {h[2]}: FERM-JH1 {h[3]:+.1f} A, p={h[4]:.4f}")
