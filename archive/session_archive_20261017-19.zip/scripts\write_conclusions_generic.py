# Runs in the marimo kernel (scratchpad). Prepend TITLE = "...", INTRO = "..." before sending.
# Writes RUN_DIR/conclusions.md (same layout as the other TYK2 runs) and RUN_DIR/selected_metrics.json.
import glob, json, os, re
import numpy as np

DOM = globals().get("DOM_OVERRIDE") or {"FERM": (26, 431), "JH2": (589, 875), "JH1": (897, 1176)}
REF = globals().get("REF_NAME") or "AF-P29597-F1"
run = RUN_DIR
name = os.path.basename(run)


def read(path):
    ca, b = {}, {}
    for l in open(path):
        if l.startswith("ATOM") and l[12:16].strip() == "CA":
            r = int(l[22:26]); ca[r] = np.array([float(l[30:38]), float(l[38:46]), float(l[46:54])]); b[r] = float(l[60:66])
    return ca, b


def cen(ca, d):
    lo, hi = DOM[d]
    return np.mean([v for k, v in ca.items() if lo <= k <= hi], axis=0)


def jh1_rmsd_after_jh2_fit(ca, ref):
    fit = [r for r in range(DOM["JH2"][0], DOM["JH2"][1] + 1) if r in ca and r in ref]
    mov = [r for r in range(DOM["JH1"][0], DOM["JH1"][1] + 1) if r in ca and r in ref]
    P, Q = np.array([ca[r] for r in fit]), np.array([ref[r] for r in fit])
    pc, qc = P.mean(0), Q.mean(0)
    u, s, vt = np.linalg.svd((P - pc).T @ (Q - qc))
    d = np.sign(np.linalg.det(vt.T @ u.T))
    R = vt.T @ np.diag([1, 1, d]) @ u.T
    A = np.array([ca[r] for r in mov]) @ R.T + (qc - pc @ R.T)
    B = np.array([ref[r] for r in mov])
    return float(np.sqrt(((A - B) ** 2).sum(1).mean()))


def metrics(path, ref):
    ca, b = read(path)
    return {
        "plddt": float(np.mean(list(b.values()))),
        "jh2_jh1": float(np.linalg.norm(cen(ca, "JH2") - cen(ca, "JH1"))),
        "ferm_jh1": float(np.linalg.norm(cen(ca, "FERM") - cen(ca, "JH1"))),
        "vs_af2": jh1_rmsd_after_jh2_fit(ca, ref),
    }


ref_ca, _ = read(REF_AF2_PDB)
ref_jh2_jh1 = np.linalg.norm(cen(ref_ca, "JH2") - cen(ref_ca, "JH1"))
ref_ferm_jh1 = np.linalg.norm(cen(ref_ca, "FERM") - cen(ref_ca, "JH1"))
report = json.load(open(os.path.join(run, "selection_report.json")))
sel = {int(c["seed"]): int(c["metrics"]["selected_recycle_index"]) for c in report["candidates"]}

traj = {}
for sd in sorted(glob.glob(os.path.join(run, "all", "seed_*"))):
    seed = int(sd.rsplit("_", 1)[1])
    traj[seed] = {}
    for p in sorted(glob.glob(os.path.join(sd, "recycle_*.pdb"))):
        traj[seed][int(re.search(r"recycle_(\d+)", p).group(1))] = metrics(p, ref_ca)
seeds = sorted(traj)
recycles = sorted(traj[seeds[0]])
allc = [(s, r, m) for s in seeds for r, m in traj[s].items()]

L = [f"# {name} — {TITLE}\n", INTRO + "\n\n\n"]
L.append("## References (centroid distances, Å)\n\n| reference | JH2–JH1 | FERM–JH1 |\n|---|--:|--:|")
L.append(f"| AF2 ({REF}) | {ref_jh2_jh1:.1f} | {ref_ferm_jh1:.1f} |\n")
L.append("## Selected structure per seed (JH1 RMSD after superposing JH2, Å)\n")
L.append("| seed | recycle | pLDDT | JH2–JH1 (Å) | FERM–JH1 (Å) | vs AF2 | nearest |\n|--:|--:|--:|--:|--:|--:|---|")
for s in seeds:
    m = traj[s][sel[s]]
    L.append(f"| {s} | {sel[s]} | {m['plddt']:.1f} | {m['jh2_jh1']:.1f} | {m['ferm_jh1']:.1f} | {m['vs_af2']:.1f} | AF2 |")
best = min(allc, key=lambda x: x[2]["vs_af2"])
L.append("\n## All conformations\n\n| reference | closest (Å) | seed | recycle | pLDDT | within 15 Å |\n|---|--:|--:|--:|--:|--:|")
L.append(f"| AF2 ({REF}) | {best[2]['vs_af2']:.1f} | {best[0]} | {best[1]} | {best[2]['plddt']:.1f} | "
         f"{sum(1 for x in allc if x[2]['vs_af2'] <= 15)} |\n")
L.append("## Mean over seeds per recycle (Å)\n\n| recycle | pLDDT | FERM–JH1 | vs AF2 |\n|--:|--:|--:|--:|")
for r in recycles:
    ms = [traj[s][r] for s in seeds if r in traj[s]]
    L.append(f"| {r} | {np.mean([m['plddt'] for m in ms]):.1f} | {np.mean([m['ferm_jh1'] for m in ms]):.1f} | {np.mean([m['vs_af2'] for m in ms]):.1f} |")
rng = lambda k: (min(x[2][k] for x in allc), max(x[2][k] for x in allc))
L.append(f"\npLDDT {rng('plddt')[0]:.1f}–{rng('plddt')[1]:.1f}; JH2–JH1 {rng('jh2_jh1')[0]:.1f}–{rng('jh2_jh1')[1]:.1f} Å; "
         f"FERM–JH1 {rng('ferm_jh1')[0]:.1f}–{rng('ferm_jh1')[1]:.1f} Å. " + (globals().get("THRESH_NOTE") or
         "(open = AF2 TYK2; closed reference: JAK1 ma-l9b1f mapped (see TYK2 analysis); FERM–JH1 > ~80 Å = open, < ~50 Å = closed)."))
L.append(f"Nearest reference over all conformations: AF2 {len(allc)}.")
L.append("## Per-seed trajectories (FERM–JH1 centroid distance, Å; open ~90+, closed ~40–45)\n\n| seed | recycles 1–15 | final |\n|--:|---|---|")
for s in seeds:
    vals = [traj[s][r]["ferm_jh1"] for r in recycles]
    fin = vals[-1]
    state = "open-like (> 80)" if fin > 80 else ("closed-like (< 50)" if fin < 50 else "intermediate")
    L.append(f"| {s} | {' '.join(f'{v:.0f}' for v in vals)} | {state} |")

json.dump({str(s): {"selected_recycle": sel[s], **traj[s][sel[s]]} for s in seeds},
          open(os.path.join(run, "selected_metrics.json"), "w"), indent=1)
open(os.path.join(run, "conclusions.md"), "w").write("\n".join(L) + "\n")
print("\n".join(L))
