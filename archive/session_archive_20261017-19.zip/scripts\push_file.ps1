# Pushes one local file to a path in the repo as a single commit (no git needed).
# Token read from %USERPROFILE%\.github_token, never printed.
param(
    [Parameter(Mandatory)] [string]$File,
    [Parameter(Mandatory)] [string]$RepoPath,
    [Parameter(Mandatory)] [string]$Message,
    [string]$Repo = "chervov/ProteinModelling1",
    [string]$Branch = "main",
    [string]$TokenFile = "$env:USERPROFILE\.github_token"
)
$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Set-Location $PSScriptRoot
$token = (Get-Content -Raw $TokenFile).Trim()
if (-not $token -or $token -eq "PASTE_YOUR_GITHUB_TOKEN_HERE") { throw "Put your GitHub token into $TokenFile first." }
$h = @{ Authorization = "Bearer $token"; Accept = "application/vnd.github+json"; "X-GitHub-Api-Version" = "2022-11-28" }
$api = "https://api.github.com/repos/$Repo"
function Gh($method, $path, $body) {
    $a = @{ Method = $method; Uri = "$api$path"; Headers = $h; TimeoutSec = 120 }
    if ($body) { $a.Body = ($body | ConvertTo-Json -Depth 6 -Compress); $a.ContentType = "application/json" }
    Invoke-RestMethod @a
}
$b64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes((Resolve-Path $File)))
$blob = Gh POST "/git/blobs" @{ content = $b64; encoding = "base64" }
for ($i = 1; $i -le 5; $i++) {
    $tip = (Gh GET "/git/ref/heads/$Branch").object.sha
    $base = (Gh GET "/git/commits/$tip").tree.sha
    $tree = Gh POST "/git/trees" @{ base_tree = $base; tree = @(@{ path = $RepoPath; mode = "100644"; type = "blob"; sha = $blob.sha }) }
    $commit = Gh POST "/git/commits" @{ message = $Message; tree = $tree.sha; parents = @($tip) }
    try {
        Gh PATCH "/git/refs/heads/$Branch" @{ sha = $commit.sha; force = $false } | Out-Null
        "Pushed: https://github.com/$Repo/blob/$Branch/$RepoPath"
        exit 0
    } catch { Start-Sleep -Seconds (3 * $i) }
}
throw "Push failed after 5 attempts."
