# Pushes a local run folder to GitHub as ONE commit via the REST API (no git needed).
# Token is read from %USERPROFILE%\.github_token and never printed.
# Usage: powershell -NoProfile -ExecutionPolicy Bypass -File push_run.ps1
param(
    [string]$Folder = "TYK2_P982A_20261017_181325",
    [string]$Repo = "chervov/ProteinModelling1",
    [string]$Branch = "main",
    [string]$Dest = "TYK2/runs",
    [string]$TokenFile = "$env:USERPROFILE\.github_token",
    [string]$Message = ""   # default: "TYK2 modelling run <folder>"
)
$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Set-Location $PSScriptRoot

$token = (Get-Content -Raw $TokenFile).Trim()
if (-not $token -or $token -eq "PASTE_YOUR_GITHUB_TOKEN_HERE") { throw "Put your GitHub token into $TokenFile first." }
$h = @{ Authorization = "Bearer $token"; Accept = "application/vnd.github+json"; "X-GitHub-Api-Version" = "2022-11-28" }
$api = "https://api.github.com/repos/$Repo"
function Gh($method, $path, $body) {
    $args = @{ Method = $method; Uri = "$api$path"; Headers = $h; TimeoutSec = 120 }
    if ($body) { $args.Body = ($body | ConvertTo-Json -Depth 6 -Compress); $args.ContentType = "application/json" }
    Invoke-RestMethod @args
}

$name = Split-Path $Folder -Leaf
$root = (Resolve-Path $Folder).Path
$files = Get-ChildItem $root -Recurse -File
Write-Host "Uploading $($files.Count) files from $name ..."

# 1) one blob per file
$entries = @()
$i = 0
foreach ($f in $files) {
    $i++
    $rel = $f.FullName.Substring($root.Length + 1).Replace("\", "/")
    $b64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes($f.FullName))
    $blob = Gh POST "/git/blobs" @{ content = $b64; encoding = "base64" }
    $entries += @{ path = "$Dest/$name/$rel"; mode = "100644"; type = "blob"; sha = $blob.sha }
    if ($i % 20 -eq 0) { Write-Host "  $i / $($files.Count) blobs" }
}

# 2) tree + commit on top of the branch tip; retry if someone pushed meanwhile
for ($attempt = 1; $attempt -le 5; $attempt++) {
    $tip = (Gh GET "/git/ref/heads/$Branch").object.sha
    $baseTree = (Gh GET "/git/commits/$tip").tree.sha
    # build the tree in chunks: one big tree call times out past ~150 entries
    $chunk = 80
    $treeSha = $baseTree
    for ($s = 0; $s -lt $entries.Count; $s += $chunk) {
        $slice = $entries[$s..([Math]::Min($s + $chunk - 1, $entries.Count - 1))]
        $treeSha = (Gh POST "/git/trees" @{ base_tree = $treeSha; tree = $slice }).sha
        Write-Host "  tree chunk $([Math]::Min($s + $chunk, $entries.Count)) / $($entries.Count)"
    }
    $commit = Gh POST "/git/commits" @{ message = $(if ($Message) { $Message } else { "TYK2 modelling run $name" }); tree = $treeSha; parents = @($tip) }
    try {
        Gh PATCH "/git/refs/heads/$Branch" @{ sha = $commit.sha; force = $false } | Out-Null
        Write-Host "Pushed: https://github.com/$Repo/tree/$Branch/$Dest/$name"
        exit 0
    } catch {
        Write-Host "Branch moved, retrying ($attempt) ..."
        Start-Sleep -Seconds (5 * $attempt)
    }
}
throw "Push failed after 5 attempts."
