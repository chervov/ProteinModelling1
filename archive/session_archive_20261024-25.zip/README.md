# Session archive — 24–25 October 2026

Working session covering variant annotation for the whole JAK family from public databases, the
JAK3 Y581C and JAK2 priority-variant homology analyses, and the investigation into why the
PyRosetta ddG values reach −3000.

## Contents

```
transcript/     full conversation transcript (JSONL) + background task outputs, CREDENTIALS REDACTED
scripts/        the tooling written during the session (PowerShell + marimo driver scripts)
data/           the deliverables pushed to the repo during the session, plus data/notes/ with the
                intermediate extracts and drafts they were built from
```

## Credentials

Scrubbed before archiving: **27** molab agent tokens replaced with `[REDACTED-molab-token]`, and a
verification pass over all 104 text files confirms nothing credential-shaped remains. The GitHub
token never entered the transcript — it was read from a file into a variable and never printed.
`scripts/make_archive.ps1` did the redaction and can be re-run to re-check.

**A bare 64-hex string is deliberately not treated as a secret here.** The transcript's own `hash`
and `shapeHash` fields are 64-hex and chain the messages together; blanking them (5,695 of them, on
the first attempt) destroys the thing this archive exists to restore. Only hex in a credential
context — after `token=`, `?token=`, `Bearer` — is redacted. The molab token is caught by exact
string match instead.

Note: both tokens used in this session should be treated as compromised regardless, since they were
typed into a chat window. Rotate them.

## What was done

**1. Variant annotation across the family.** Built one table per protein (JAK1, JAK2, JAK3, TYK2)
from ClinVar (protein-level variants, review status, conditions), gnomAD v4 (AC/AF/homozygotes plus
a benign/pathogenic call on the frequency criteria), cBioPortal, COSMIC, OncoKB, CIViC, LOVD,
DECIPHER, OMIM allelic variants, and dbNSFP predictors (AlphaMissense, REVEL, CADD, SIFT,
PolyPhen-2 HVAR, MetaRNN, ESM1b, EVE). Pushed to `external_data/<GENE>/`.

**2. Homology analyses.** JAK3 Y581C and the four JAK2 priority variants mapped onto their paralog
equivalents, with predictor scores for every homologous substitution and 3D neighbourhoods from the
AlphaFold models. Key finding: Y581 sits at a three-way JH2–FERM–JH1 contact whose neighbours are
recurrent activating sites in the other JAKs, but the direction (gain vs loss) cannot be inferred
from the available data.

**3. The ddG investigation — the main result.** Three independent lines settled whether the extreme
stored ddG values are real:

- the extremes are ~100% `fa_rep` (steric overlap), and a mobile backbone shrinks them 10–150×;
- the ordering survives the protocol change (Spearman 0.904);
- **Rosetta's own `ddg_monomer` returns the same magnitudes** (+2832 REU for G746W against the
  pipeline's −2989) while giving textbook values for ordinary mutations (H667F 2.08 kcal/mol,
  R775A 0.62 kcal/mol).

So there is no implementation defect, in the pipeline or in PyRosetta. The decisive scale argument:
the whole folded protein scores −2689 REU, so a ddG of −3000 implies a mutant at +311 REU, which no
folded structure has. Every extreme position is a buried glycine that cannot host a bulky residue
under any fixed-backbone treatment. **Rank the values; never quote them as energies.** Written up as
sections 8–10 of [`conclusions_ddG_difference_feature.md`](../conclusions_ddG_difference_feature.md).

**4. Reusable notebooks.** The relaxed pose was published as
[`data/ddg/TYK2_relaxed_closed.pdb.gz`](../data/ddg/TYK2_relaxed_closed.pdb.gz) so neither notebook
has to spend ~35 min on FastRelax:
[`pipeline/ddg/notebook_clash_diagnosis.py`](../pipeline/ddg/notebook_clash_diagnosis.py) (marimo,
15 cells) and [`colab/tyk2_ddg_clash_diagnosis.ipynb`](../colab/tyk2_ddg_clash_diagnosis.ipynb)
(Colab, Run all).

## Dead ends, recorded so they are not repeated

- **StructMAn cannot score substitutions.** It annotates positions only; its own example output
  shows every residue as X→X. Verified twice, including an SMLF upload.
- **CCLE expression cannot test JAK2 L805I.** The only cell line carrying it (SARC9371_BONE) has no
  RNA-seq, and a calibration on lines that do showed the approach cannot detect even V617F (SET-2
  ranks 51/188 on a JAK2-target signature).
- **There is no Google Colab CLI.** Google never shipped one; a repo-hosted `.ipynb` opened through
  `colab.research.google.com/github/...` is the only route.

## Scripts

| file | purpose |
|---|---|
| `marimo-exec.ps1` | run Python in a live marimo kernel over HTTP (PowerShell port of the marimo-pair helper, which needs bash). Long timeouts and session retries, for a box pinned at 100% CPU |
| `gh_put.ps1` | create or update one repo file via the contents API; strips the UTF-8 BOM and retries, because GitHub's ruleset check intermittently times out with 403/500 on the first attempt |
| `make_archive.ps1` | build this archive: redact, stage, verify, zip |
| `append_section8/9/10.ps1` | insert a new section into `conclusions_ddG_difference_feature.md` ahead of its data footer, then verify no mojibake was introduced |
| `add_ddg_column.ps1`, `add_*_columns.ps1` | add annotation columns to the variant tables at a chosen position rather than at the end |
| `marimo/*.py` | the code-mode scripts that built and edited the molab notebook cell by cell |

## Two PowerShell traps that cost time

1. **PowerShell 5.1 reads a BOM-less `.ps1` as ANSI**, so any non-ASCII character in a script turns
   into mojibake in the file it writes. Keep `.ps1` files pure ASCII and put non-ASCII content in
   separate `.md` files read as UTF-8. This bit twice.
2. **PowerShell variables are case-insensitive**, so `$d` silently clobbers `$D`; and
   `$a[($i+1)..($n-1)]` runs *backwards* when `i` is the last index, duplicating the final element.
   Both produced wrong tables before being caught.
