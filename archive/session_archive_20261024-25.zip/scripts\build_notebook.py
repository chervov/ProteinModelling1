import marimo._code_mode as cm

CELLS = [
("intro", '''import marimo as mo

mo.md(
    """
    # TYK2 ddG: are the extreme values real?

    The dual-state ddG run (`data/ddg/`) produces values down to **-3000**, far outside any
    physical folding free energy. This notebook reproduces the pipeline on one structure and
    tests whether those numbers are **steric clash artefacts** rather than energies.

    Three protocols on the same relaxed pose:

    | | what it does |
    |---|---|
    | **A** | the pipeline: `mutate_residue(pack_radius=8)`, side chains only |
    | **fa_rep** | how much of the ddG is the Lennard-Jones repulsive term |
    | **B** | A plus backbone + side-chain minimisation of the 8 A shell |

    Sign convention follows the paper: **ddG = E(WT) - E(mut)**, so *negative = destabilising*.
    """
)'''),

("setup", '''import os, sys, time, json, subprocess, urllib.request

def ensure_pyrosetta():
    """PyRosetta is not on PyPI; install via the RosettaCommons installer (free for academic use)."""
    try:
        import pyrosetta  # noqa: F401
        return "already installed"
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "pyrosetta-installer"], check=True)
        import pyrosetta_installer
        pyrosetta_installer.install_pyrosetta()
        return "installed now (~1.5 GB)"

pyrosetta_status = ensure_pyrosetta()
print("PyRosetta:", pyrosetta_status)'''),

("config", '''WORK = "/tmp/ddg"
STRUCTURE_URL = ("https://raw.githubusercontent.com/chervov/ProteinModelling1/main/"
                 "TYK2/af3/tyk2_af3_closed.pdb")
SHELL = 8.0          # repack radius, as in pipeline/ddg/worker.py

# Three positions with the most extreme stored ddG (all glycine), two ordinary ones.
TEST_POSITIONS = [746, 964, 801, 667, 775]
TEST_ALTS = ["W", "F", "A", "G"]

os.makedirs(WORK, exist_ok=True)
print(f"{len(TEST_POSITIONS)} positions x {len(TEST_ALTS)} substitutions")'''),

("rosetta_init", '''import pyrosetta
from pyrosetta import pose_from_pdb, get_fa_scorefxn
from pyrosetta.toolbox import mutate_residue
from pyrosetta.rosetta.core.scoring import ScoreType
from pyrosetta.rosetta.core.kinematics import MoveMap
from pyrosetta.rosetta.protocols.minimization_packing import MinMover
from pyrosetta.rosetta.protocols.relax import FastRelax
from pyrosetta.rosetta.protocols.constraint_generator import (
    CoordinateConstraintGenerator, AddConstraints)

pyrosetta.init("-mute all -ex1 -ex2aro -ignore_unrecognized_res "
               "-ignore_zero_occupancy false -detect_disulf false")
scorefxn = get_fa_scorefxn()
print("scorefunction:", scorefxn.get_name())'''),

("pose", '''def load_relaxed_pose():
    """Fetch the structure and FastRelax it with coordinate constraints, exactly as worker.py.
    Cached on disk: the first run takes ~35 min for 1187 residues, later runs are instant."""
    src = f"{WORK}/tyk2_af3_closed.pdb"
    if not os.path.exists(src):
        urllib.request.urlretrieve(STRUCTURE_URL, src)
    cached = f"{WORK}/TYK2_relaxed_closed.pdb"
    if os.path.exists(cached) and os.path.getsize(cached) > 100_000:
        return pose_from_pdb(cached), "loaded from cache"
    p = pose_from_pdb(src)
    gen = CoordinateConstraintGenerator()
    add = AddConstraints(); add.add_generator(gen); add.apply(p)
    sf_cst = scorefxn.clone(); sf_cst.set_weight(ScoreType.coordinate_constraint, 1.0)
    t0 = time.time(); FastRelax(sf_cst, 1).apply(p)
    p.dump_pdb(cached)
    return p, f"relaxed in {time.time() - t0:.0f}s"

pose, pose_note = load_relaxed_pose()
total_wt = scorefxn(pose)
print(f"{pose.total_residue()} residues, {total_wt:.0f} REU total "
      f"({total_wt / pose.total_residue():.2f} REU/residue) - {pose_note}")'''),

("functions", '''def weighted_terms(p):
    """Weighted score terms of a pose, as a dict."""
    scorefxn(p)
    totals = p.energies().total_energies()
    return {st.name: totals[st] * scorefxn.get_weight(st)
            for st in scorefxn.get_nonzero_weighted_scoretypes()}

def minimise_shell(p, position, radius=SHELL):
    """Protocol B: let the backbone and side chains near the mutation move."""
    mm = MoveMap()
    centre = p.residue(position).xyz("CA")
    for i in range(1, p.total_residue() + 1):
        if p.residue(i).has("CA") and (p.residue(i).xyz("CA") - centre).norm() <= radius:
            mm.set_chi(i, True); mm.set_bb(i, True)
    MinMover(mm, scorefxn, "lbfgs_armijo_nonmonotone", 0.01, True).apply(p)
    return p

def ddg_for(position, alt):
    """Returns protocol A, protocol B, and the fa_rep share of A."""
    native = pose.residue(position).name1()
    if native == alt:
        return None
    wt = pose.clone(); mutate_residue(wt, position, native, pack_radius=SHELL)
    mut = pose.clone(); mutate_residue(mut, position, alt, pack_radius=SHELL)
    a = scorefxn(wt) - scorefxn(mut)
    d_rep = weighted_terms(mut).get("fa_rep", 0.0) - weighted_terms(wt).get("fa_rep", 0.0)
    b = scorefxn(minimise_shell(wt.clone(), position)) - scorefxn(minimise_shell(mut.clone(), position))
    return {"variant": f"{native}{position}{alt}", "pos": position, "wt": native, "alt": alt,
            "A_repack_only": round(a, 1), "B_flexible_bb": round(b, 1),
            "fa_rep_share": round(d_rep / a, 2) if abs(a) > 1e-9 else None}'''),

("run", '''results = []
for _pos in TEST_POSITIONS:
    for _alt in TEST_ALTS:
        _rec = ddg_for(_pos, _alt)
        if _rec:
            results.append(_rec)
            print(_rec["variant"], _rec["A_repack_only"], "->", _rec["B_flexible_bb"], flush=True)
print(f"{len(results)} variants")'''),

("table", '''import pandas as pd

ddg_table = pd.DataFrame(results).sort_values("A_repack_only")
ddg_table["shrink_factor"] = (ddg_table.A_repack_only / ddg_table.B_flexible_bb).round(1)
mo.ui.table(ddg_table, selection=None)'''),

("chart", '''import altair as alt

_long = ddg_table.melt(id_vars="variant", value_vars=["A_repack_only", "B_flexible_bb"],
                       var_name="protocol", value_name="ddG")
chart = alt.Chart(_long).mark_bar().encode(
    y=alt.Y("variant:N", sort=list(ddg_table.variant), title=None),
    x=alt.X("ddG:Q", title="ddG (REU, negative = destabilising)"),
    color=alt.Color("protocol:N", title=None),
    yOffset="protocol:N",
).properties(height=420, width=520, title="Repack-only vs flexible backbone")
mo.ui.altair_chart(chart)'''),

("conclusion", '''_extreme = ddg_table[ddg_table.A_repack_only < -500]
mo.md(f"""
## What this shows

- **{len(_extreme)} of {len(ddg_table)}** variants score below -500 under the pipeline protocol;
  their mean `fa_rep` share is **{_extreme.fa_rep_share.mean():.0%}** - the ddG *is* the
  repulsive term and nothing else.
- Letting the backbone move shrinks them by a median factor of
  **{_extreme.shrink_factor.median():.0f}x**.
- Every extreme position is a **glycine**: replacing it with W or F in a fixed backbone is the
  case Flex ddG says needs backbone movement.
- The ordinary position (775) is unaffected by the protocol choice, so this is specific to
  clash-prone sites rather than a global offset.

The pipeline's own design decision stands: **only the ordering is meaningful.** The amplitudes
are not energies. See `conclusions_ddG_difference_feature.md` SS8-9.
""")'''),
]


async def main():
    async with cm.get_context() as ctx:
        ctx.packages.add("pandas", "altair")
        existing = list(ctx.cells.keys())
        prev = None
        for name, code in CELLS:
            prev = ctx.create_cell(code, name=name, after=prev, hide_code=False)
        for cid in existing:
            if not (ctx.cells[cid].code or "").strip():
                ctx.delete_cell(cid)
    print("created", len(CELLS), "cells")


await main()
