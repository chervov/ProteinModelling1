import marimo._code_mode as cm

CONFIG = '''WORK = "/tmp/ddg"
RAW = "https://raw.githubusercontent.com/chervov/ProteinModelling1/main/"
STRUCTURE_URL = RAW + "TYK2/af3/tyk2_af3_closed.pdb"
# The relaxed pose is published, so a fresh box skips the ~35 min FastRelax.
RELAXED_URL = RAW + "data/ddg/TYK2_relaxed_closed.pdb.gz"
SHELL = 8.0          # repack radius, as in pipeline/ddg/worker.py

# Three positions with the most extreme stored ddG (all glycine), two ordinary ones.
TEST_POSITIONS = [746, 964, 801, 667, 775]
TEST_ALTS = ["W", "F", "A", "G"]

os.makedirs(WORK, exist_ok=True)
print(f"{len(TEST_POSITIONS)} positions x {len(TEST_ALTS)} substitutions")'''

POSE = '''def load_relaxed_pose():
    """Return the relaxed pose, cheapest route first.

    1. local cache, 2. the relaxed pose published in the repo, 3. relax it here (~35 min).
    Relaxation is FastRelax under coordinate constraints, exactly as pipeline/ddg/worker.py.
    """
    cached = f"{WORK}/TYK2_relaxed_closed.pdb"
    if os.path.exists(cached) and os.path.getsize(cached) > 100_000:
        return pose_from_pdb(cached), "local cache"
    try:
        import gzip
        with urllib.request.urlopen(RELAXED_URL, timeout=300) as r:
            open(cached, "wb").write(gzip.decompress(r.read()))
        return pose_from_pdb(cached), "downloaded the published relaxed pose"
    except Exception as exc:
        print("download failed, relaxing locally:", exc)
    src = f"{WORK}/tyk2_af3_closed.pdb"
    if not os.path.exists(src):
        urllib.request.urlretrieve(STRUCTURE_URL, src)
    p = pose_from_pdb(src)
    gen = CoordinateConstraintGenerator()
    add = AddConstraints(); add.add_generator(gen); add.apply(p)
    sf_cst = scorefxn.clone(); sf_cst.set_weight(ScoreType.coordinate_constraint, 1.0)
    t0 = time.time(); FastRelax(sf_cst, 1).apply(p)
    p.dump_pdb(cached)
    return p, f"relaxed here in {time.time() - t0:.0f}s"

pose, pose_note = load_relaxed_pose()
total_wt = scorefxn(pose)
print(f"{pose.total_residue()} residues, {total_wt:.0f} REU total "
      f"({total_wt / pose.total_residue():.2f} REU/residue) - {pose_note}")'''

MD_KELLOGG = '''mo.md(
    """
    ## 4. Cross-check: Rosetta's own ddG application

    The obvious suspicion is that the repack-only protocol is at fault. To test it we run
    **`ddGMover`**, which *is* `ddg_monomer` (Kellogg et al. 2011): it ramps the repulsive term,
    minimises under coordinate constraints and takes the best of several decoys - everything the
    pipeline protocol lacks.

    Results below are the stored run (5 variants, ~6 min each). Call
    `run_ddg_monomer(position, alt)` to recompute any of them yourself.

    Note the sign: **Rosetta positive = destabilising**, the opposite of the paper's convention.
    """
)'''

KELLOGG = '''def run_ddg_monomer(position, alt, iterations=3):
    """Rosetta's own ddG protocol for one substitution. Returns (REU, kcal/mol, seconds).

    ~6 min per variant, so the table below uses the stored run instead of recomputing.
    """
    from pyrosetta.rosetta.protocols.ddg import ddGMover
    from pyrosetta.rosetta.utility import vector1_core_chemical_AA
    from pyrosetta.rosetta.core.chemical import aa_from_oneletter_code
    muts = vector1_core_chemical_AA(pose.total_residue())
    for i in range(1, pose.total_residue() + 1):
        muts[i] = pose.residue(i).aa()
    muts[position] = aa_from_oneletter_code(alt)
    mover = ddGMover(scorefxn, scorefxn, muts)
    mover.set_min_cst(True); mover.set_min(True); mover.set_mean(False)
    mover.restrict_to_nbrs(True); mover.num_iterations(iterations)
    work = pose.clone()
    t0 = time.time(); mover.apply(work)
    reu = mover.ddG()
    return reu, reu / 2.94, time.time() - t0   # 2.94 = documented REU -> kcal/mol factor

kellogg_table = pd.DataFrame(
    json.load(urllib.request.urlopen(RAW + "data/ddg/kellogg_ddg_monomer.json", timeout=120))
)
mo.ui.table(kellogg_table, selection=None)'''

CONCLUSION = '''_extreme = ddg_table[ddg_table.A_repack_only < -500]
mo.md(f"""
## What this shows

**The extreme values are not energies.** The whole folded protein scores **{total_wt:.0f} REU**
over {pose.total_residue()} residues. A ddG of -3000 therefore puts the mutant at
**+{-total_wt - 3000:.0f} REU** - a positive total energy, which no folded structure has.

- **{len(_extreme)} of {len(ddg_table)}** variants fall below -500 under the pipeline protocol, and
  their mean `fa_rep` share is **{_extreme.fa_rep_share.mean():.0%}**: the ddG *is* the repulsive
  term and nothing else.
- Every extreme position is a **glycine**; G->A at the same sites is 10-50x milder.
- The ordinary position (**775**) is unaffected by the protocol choice.

**But the protocol is not the culprit.** Rosetta's own `ddg_monomer` (section 4) returns
**+2832 REU for G746W** - the same magnitude as the pipeline's -2989 - while giving textbook
values for ordinary mutations (**H667F 2.08 kcal/mol**, **R775A 0.62 kcal/mol**). Two independently
written protocols agree, so there is no implementation defect. These positions are buried glycines
that simply cannot host a tryptophan in a fixed backbone, and every standard method reports that
as a saturated "does not fit" flag.

**What to do with the values.** Rank them; never quote them as energies. That is what
`conclusions_ddG_difference_feature.md` (SS8-10) concludes and what the pipeline README already
said: *"only the ordering is meaningful"*.
""")'''


async def main():
    async with cm.get_context() as ctx:
        for n in ("config", "pose", "conclusion"):
            _ = ctx.cells[n].code
        ctx.edit_cell("config", code=CONFIG)
        ctx.edit_cell("pose", code=POSE)
        ctx.edit_cell("conclusion", code=CONCLUSION)
        ctx.create_cell(MD_KELLOGG, name="md_kellogg", before="conclusion", hide_code=False)
        ctx.create_cell(KELLOGG, name="kellogg", before="conclusion", hide_code=False)
        for n in ("config", "pose", "md_kellogg", "kellogg", "conclusion"):
            ctx.run_cell(n)
    print("added ddGMover section")

await main()
