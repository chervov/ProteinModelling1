param($out, $gene = 'JAK1')
# Download all ClinVar records for a gene via NCBI E-utilities and save the fields we need as JSON.
$base = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/'
$s = Invoke-RestMethod "$($base)esearch.fcgi?db=clinvar&term=$gene[gene]&retmax=5000&retmode=json"
$ids = @($s.esearchresult.idlist)
$rows = New-Object System.Collections.Generic.List[object]
for ($i = 0; $i -lt $ids.Count; $i += 200) {
  $chunk = $ids[$i..([Math]::Min($i + 199, $ids.Count - 1))] -join ','
  $r = Invoke-RestMethod "$($base)esummary.fcgi?db=clinvar&retmode=json&id=$chunk"
  foreach ($uid in $r.result.uids) {
    $d = $r.result.$uid
    $g = $d.germline_classification
    $ci = $d.clinical_impact_classification
    $rows.Add([pscustomobject]@{
      uid        = $uid
      accession  = $d.accession
      title      = $d.title
      genes      = (@($d.genes) | ForEach-Object { $_.symbol }) -join '/'
      cls        = $g.description
      review     = $g.review_status
      evaluated  = $g.last_evaluated
      traits     = (@($g.trait_set) | ForEach-Object { $_.trait_name } | Select-Object -Unique) -join '; '
      somatic    = $ci.description
      somaticRev = $ci.review_status
      somaticTr  = (@($ci.trait_set) | ForEach-Object { $_.trait_name } | Select-Object -Unique) -join '; '
    })
  }
  Start-Sleep -Milliseconds 400
}
$rows | ConvertTo-Json -Depth 3 | Out-File -Encoding utf8 $out
"Saved $($rows.Count) of $($ids.Count) records"
