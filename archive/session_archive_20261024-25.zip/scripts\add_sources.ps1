param($table, $sources)
# Append gnomAD, cBioPortal, OncoKB, LOVD and DECIPHER columns to the existing rows of the main table (in place).
$utf8 = New-Object System.Text.UTF8Encoding($false)
function Q($s) { $s = [string]$s; if ($s -match '[",\r\n]') { '"' + ($s -replace '"', '""') + '"' } else { $s } }
$cols = 'gnomAD allele count','gnomAD AF','gnomAD homozygotes','cBioPortal patients','cBioPortal studies','cBioPortal top cancer types','OncoKB oncogenic','OncoKB mutation effect','LOVD entries','LOVD reported effect','DECIPHER'
$src = @{}; Import-Csv $sources | ForEach-Object { $src[$_.Variant] = $_ }
$lines = [IO.File]::ReadAllLines($table, $utf8)
$rows = Import-Csv $table -Encoding UTF8
$out = New-Object System.Collections.Generic.List[string]
$out.Add($lines[0] + ',' + ($cols -join ','))
$hit = 0
for ($i = 0; $i -lt $rows.Count; $i++) {
  $m = [regex]::Match($rows[$i].Variant, '^(?:Known GOF: )?([A-Z*]\d+(?:[A-Z]|\*|fs|del|_\w+)\S*)$')
  $s = $null
  if ($m.Success) {
    $v = $m.Groups[1].Value
    $s = $src[$v]
    if (-not $s -and $v -match '^\*\d+[A-Z]$') { $s = $src.Values | Where-Object { $_.Variant -like "$v`ext*" } | Select-Object -First 1 }  # stop-loss naming differs
  }
  $vals = foreach ($c in $cols) { if ($s) { $s.$c } else { '' } }
  if ($s -and (@($vals) -ne '').Count) { $hit++ }
  $out.Add($lines[$i + 1] + ',' + (($vals | ForEach-Object { Q $_ }) -join ','))
}
[IO.File]::WriteAllLines($table, $out, $utf8)
"rows: $($rows.Count); rows with data from at least one new source: $hit"
