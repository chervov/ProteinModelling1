param($ddg, $dmsSignal, $dmsAbund, $out)
# Join the repo's TYK2 ddG (closed/open/delta) with the TYK2 deep mutational scan and correlate.
$three = @{Ala='A';Arg='R';Asn='N';Asp='D';Cys='C';Gln='Q';Glu='E';Gly='G';His='H';Ile='I';Leu='L';Lys='K';Met='M';Phe='F';Pro='P';Ser='S';Thr='T';Trp='W';Tyr='Y';Val='V';Ter='*'}
function ToOne($p) { $p = $p -replace '^p\.', ''; [regex]::Replace($p, 'Ala|Arg|Asn|Asp|Cys|Gln|Glu|Gly|His|Ile|Leu|Lys|Met|Phe|Pro|Ser|Thr|Trp|Tyr|Val|Ter', { param($m) $three[$m.Value] }) }
$j = Get-Content -Raw $ddg | ConvertFrom-Json
$D = @{}
foreach ($r in @($j)) { $D["$($r.wt)$($r.pos)$($r.alt)"] = $r }
"ddG substitutions: $($D.Count)"
$sig = @{}; foreach ($r in (Import-Csv $dmsSignal)) { if ($r.hgvs_pro -and $r.score -ne 'NA') { $sig[(ToOne $r.hgvs_pro)] = [double]$r.score } }
$ab = @{}; foreach ($r in (Import-Csv $dmsAbund)) { if ($r.hgvs_pro -and $r.score -ne 'NA') { $ab[(ToOne $r.hgvs_pro)] = [double]$r.score } }
"DMS signalling: $($sig.Count); DMS abundance: $($ab.Count)"
$rows = foreach ($k in $D.Keys) {
  if (-not $sig.ContainsKey($k) -and -not $ab.ContainsKey($k)) { continue }
  if ($k -match '\*') { continue }
  [pscustomobject]@{ Variant = $k; pos = [int]$D[$k].pos; ddg_closed = [double]$D[$k].ddg_closed; ddg_open = [double]$D[$k].ddg_open
    delta = [double]$D[$k].delta; signal = $(if ($sig.ContainsKey($k)) { $sig[$k] }); abundance = $(if ($ab.ContainsKey($k)) { $ab[$k] }) }
}
$rows = @($rows)
"joined substitutions: $($rows.Count)"
$rows | Export-Csv -NoTypeInformation -Encoding UTF8 $out
function Pearson($x, $y) {
  $n = $x.Count; if ($n -lt 3) { return 'n/a' }
  $mx = ($x | Measure-Object -Average).Average; $my = ($y | Measure-Object -Average).Average
  $sxy = 0.0; $sxx = 0.0; $syy = 0.0
  for ($i = 0; $i -lt $n; $i++) { $dx = $x[$i] - $mx; $dy = $y[$i] - $my; $sxy += $dx * $dy; $sxx += $dx * $dx; $syy += $dy * $dy }
  if ($sxx -le 0 -or $syy -le 0) { return 'n/a' }
  [math]::Round($sxy / [math]::Sqrt($sxx * $syy), 3)
}
function Spearman($x, $y) {
  $rank = { param($v) $idx = 0..($v.Count - 1) | Sort-Object { $v[$_] }; $r = New-Object double[] $v.Count; $i = 0
            while ($i -lt $idx.Count) { $j = $i; while ($j + 1 -lt $idx.Count -and $v[$idx[$j + 1]] -eq $v[$idx[$i]]) { $j++ }
              $avg = ($i + $j) / 2.0 + 1; for ($k = $i; $k -le $j; $k++) { $r[$idx[$k]] = $avg }; $i = $j + 1 }; $r }
  Pearson (& $rank $x) (& $rank $y)
}
foreach ($pair in @(@('signal', 'ddg_closed'), @('signal', 'ddg_open'), @('signal', 'delta'), @('abundance', 'ddg_closed'), @('abundance', 'ddg_open'), @('abundance', 'delta'))) {
  $sel = @($rows | Where-Object { $_.($pair[0]) -ne $null })
  $x = @($sel | ForEach-Object { [double]$_.($pair[1]) }); $y = @($sel | ForEach-Object { [double]$_.($pair[0]) })
  "{0,-10} vs {1,-11} n={2,5}  Pearson r = {3,7}  Spearman rho = {4,7}" -f $pair[0], $pair[1], $sel.Count, (Pearson $x $y), (Spearman $x $y)
}
# same, restricted to the plausible ddG range (|ddg| <= 10 kcal/mol)
"`nrestricted to |ddg_closed| <= 10 and |ddg_open| <= 10:"
$sane = @($rows | Where-Object { [math]::Abs($_.ddg_closed) -le 10 -and [math]::Abs($_.ddg_open) -le 10 })
"n = $($sane.Count) of $($rows.Count)"
foreach ($pair in @(@('signal', 'ddg_closed'), @('signal', 'delta'), @('abundance', 'ddg_closed'), @('abundance', 'delta'))) {
  $sel = @($sane | Where-Object { $_.($pair[0]) -ne $null })
  if ($sel.Count -lt 3) { continue }
  $x = @($sel | ForEach-Object { [double]$_.($pair[1]) }); $y = @($sel | ForEach-Object { [double]$_.($pair[0]) })
  "{0,-10} vs {1,-11} n={2,5}  Pearson r = {3,7}  Spearman rho = {4,7}" -f $pair[0], $pair[1], $sel.Count, (Pearson $x $y), (Spearman $x $y)
}
