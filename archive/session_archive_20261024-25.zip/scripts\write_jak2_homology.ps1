# Assemble external_data/JAK2/jak2_homology_inf.md from the alignment blocks, score tables and curated notes.
$blocks = Get-Content -Raw "$PWD\sources\alignment\blocks.json" | ConvertFrom-Json
# Score tables: plain lines grouped under "@@<variant> EQ|OBS" markers
$tabs = @{}; $cur = $null
foreach ($line in [IO.File]::ReadAllLines("$PWD\sources\alignment\jak2_scores_tables.txt")) {
  if ($line.StartsWith('@@')) { $cur = $line.Substring(2); $tabs[$cur] = New-Object System.Collections.Generic.List[string] }
  elseif ($line.Trim()) { $tabs[$cur].Add($line) }
}
$notes = [ordered]@{
  'G571R' = @{
    context = 'JH2 N-lobe, variable loop immediately after **Y570**, the inhibitory JAK2 autophosphorylation site (phospho-Y570 down-regulates JAK2 activity). The loop is not conserved: Y570 has no counterpart in JAK1 (T611), JAK3 (gap) or TYK2 (R633), and the JAK1 match for G571 (S612) is uncertain because of an insertion. Gly is kept in JAK3 (G546) and TYK2 (G634).'
    lit = '**G571S** (same residue) is the best-studied variant here: proposed to disturb Y570 phosphorylation, but classical assays did not show STAT5 activation; found in 3 of ~20,000 suspected-MPN samples; in a family it was carried by relatives with normal blood counts and judged a likely non-functional polymorphism (ClinVar: conflicting; gnomAD 571 alleles). Nothing published on G571R.'
    reading = 'Most tools call G571R damaging (REVEL 0.87, CADD 33), but AlphaMissense (0.27) and EVE (0.38) do not, the equivalent Gly->Arg is benign by every tool in JAK3 and TYK2, and in TYK2 it has **no measured effect (-0.05 +- 0.25)**. The well-studied neighbour G571S looks neutral. The only mechanism worth testing is an effect on Y570 phosphorylation, which is JAK2-specific.' }
  'V578I' = @{
    context = 'JH2 N-lobe **beta3 strand** (`EVLLKVLD`), three residues before **K581**, the JH2 lysine that coordinates ATP. V578 is conserved in all four JAKs (JAK1 V619, JAK3 V553, TYK2 V639); the equivalent K581 is JAK1 K622, JAK3 K556 and TYK2 K642. JH2 ATP binding stabilises JH2 (especially alphaC) and is required for V617F hyperactivation (Hammaren et al., PNAS 2015).'
    lit = 'No publication on V578I or the equivalent residues. JAK2 V578F is in ClinVar (uncertain significance).'
    reading = 'The position is highly constrained (position mean AlphaMissense 0.83-0.93 across the family) and bulky changes score strongly damaging (JAK2 V578F, JAK3 V553M), but **Val->Ile is mild everywhere** (AlphaMissense 0.20-0.36) and has **no measured effect in TYK2 (V639I -0.09 +- 0.27)**. Older tools (SIFT, PolyPhen-2, MetaRNN) call JAK2 V578I damaging mainly because of the conservation. A subtle effect on JH2 ATP binding cannot be excluded, but a strong effect is unlikely.' }
  'L805I' = @{
    context = 'Last helix at the C-terminal edge of JH2 (`RAIIRDLNSL`), just before the JH2-JH1 linker. Conserved Leu in JAK3 (L777) and TYK2 (L866); **JAK1 naturally has Ile (I845)**.'
    lit = 'No publication on L805I or the equivalent residues.'
    reading = 'Ile is tolerated structurally (it is JAK1''s wild-type residue) and predictors call L805I benign-to-uncertain, **but the TYK2 deep mutational scan gives the same change L866I +0.57 +- 0.33** - the highest of all 19 substitutions at that position and about the top 5% of the scan, i.e. *more* signalling. This is the only hint of gain of function among the four (weak, ~1.7 SE).' }
  'V1110E' = @{
    context = 'C-terminal end of the JH1 kinase domain (JH1 ends at 1124). The position is not conserved: Pro in JAK1 (P1136) and JAK3 (P1082), Ala in TYK2 (A1156).'
    lit = 'No publication on V1110E or the equivalent residues.'
    reading = 'Variable position (position mean AlphaMissense 0.23 in JAK2); V1110E is benign-to-uncertain by most tools (AlphaMissense 0.29, PolyPhen-2 0.19, ESM1b -1.2), and the equivalent change in TYK2 (A1156E) has **no measured effect (-0.08 +- 0.35)**. Probably tolerated.' }
}
$md = New-Object System.Text.StringBuilder
function L([string]$s) { [void]$md.AppendLine($s) }
L '# JAK2 priority variants: homology analysis with JAK1, JAK3 and TYK2'
L ''
L 'Variants: **G571R, V578I, L805I, V1110E** (JAK2, O60674 / NM_004972). Data retrieved 24-25 Oct 2026.'
L ''
L 'Alignment: pairwise global alignment of UniProt canonical sequences (Gotoh, BLOSUM62, gap open 11 / extend 1); identity to JAK2: JAK1 46.6%, JAK3 50.4%, TYK2 42.4%. Known equivalents align correctly (JAK2 V617 = JAK1 V658 = JAK3 M592 = TYK2 V678; R683 = JAK1 R724; catalytic K882 = JAK1 K908). Full map: [`jak_alignment_position_map.csv`](../jak_alignment_position_map.csv); score thresholds: [`scores_interpretation.md`](../scores_interpretation.md).'
L ''
L '## Summary'
L ''
L '| JAK2 | JAK1 | JAK3 | TYK2 | Location | Key evidence | Reading |'
L '|---|---|---|---|---|---|---|'
L '| **G571R** | S612 (uncertain) | G546 | G634 | JH2 loop next to inhibitory pY570 | Gly->Arg benign in JAK3/TYK2; TYK2 G634R no effect (-0.05); G571S at same residue likely neutral | Probably tolerated; only a JAK2-specific Y570 effect is plausible |'
L '| **V578I** | V619 | V553 | V639 | JH2 beta3 strand, 3 residues before ATP-binding K581 | Constrained position, but Val->Ile mild everywhere; TYK2 V639I no effect (-0.09) | Probably tolerated |'
L '| **L805I** | **I845** | L777 | L866 | Last JH2 helix, before JH2-JH1 linker | JAK1 has Ile natively; **TYK2 L866I +0.57 +- 0.33 (more signalling)** | Weak hint of gain of function - test first |'
L '| **V1110E** | P1136 | P1082 | A1156 | C-terminal end of JH1 | Variable position; TYK2 A1156E no effect (-0.08) | Probably tolerated |'
L ''
L '**Suggested testing order:** L805I > G571R > V578I > V1110E, in a JAK2 assay that detects activation (STAT5 reporter or cytokine-independent Ba/F3-EPOR growth, without and with EPO), with WT and V617F as controls and K581A (JH2 ATP-binding dead) as a mechanistic control for V578I.'
L ''
L '> Caveat: all predictors score damaging-versus-tolerated and cannot detect gain of function, the mechanism of JAK2 disease. The TYK2 scan measures IFN-alpha-stimulated minus baseline signalling and may also under-detect constitutive activation (TYK2 V678F, the V617F equivalent, scores -0.12).'
L ''
foreach ($v in $notes.Keys) {
  $n = $notes[$v]
  L "## JAK2 $v"
  L ''
  L "**Location.** $($n.context)"
  L ''
  L "**Literature.** $($n.lit)"
  L ''
  L '### Alignment and variants reported at the equivalent positions'
  L ''
  L ($blocks.$v)
  L ''
  L '### Predictor scores - same substitution at each equivalent residue'
  L ''
  foreach ($l in $tabs["$v EQ"]) { L $l }
  L ''
  L '### Predictor scores - variants reported at these positions'
  L ''
  foreach ($l in $tabs["$v OBS"]) { L $l }
  L ''
  L "**Reading.** $($n.reading)"
  L ''
}
L '## Notes'
L ''
L '- dbNSFP scores (REVEL, CADD, SIFT, PolyPhen-2, MetaRNN, ESM1b, EVE) exist only for substitutions reachable by one DNA change; "-" means not reachable or not scored. AlphaMissense covers all 19 substitutions. AlphaMissense classes: LP > 0.564, amb 0.34-0.564, LB < 0.34.'
L '- "Position mean AlphaMissense" = average over all 19 substitutions at that residue (high = constrained). TYK2 DMS: MaveDB urn:mavedb:00001270-a-6, log2 fold change vs WT, negative = loss of signalling.'
L '- Variant counts come from ClinVar, gnomAD v4 (AC = allele count) and cBioPortal; licensed tumour-database counts are not shown.'
L ''
L 'Sources: [Hammaren et al. 2015, ATP binding to the JAK2 pseudokinase domain (PNAS)](https://pmc.ncbi.nlm.nih.gov/articles/PMC4403165); [Exon 13 G571S in MPN (Leukemia Research Reports 2016)](https://doaj.org/article/d6ee03ab66df44e5b4d23408576c5020); [Role of exon 13 G571S in MPN](https://agris.fao.org/search/en/records/65deba4e7c7033e84beb9c59); [Familial G571S not linked with ET](https://repository.ukim.mk/entities/publication/f8297d64-4f10-4f9b-a09b-a3a141b24616); [JAK2 G571S review (PMC5128013)](https://pmc.ncbi.nlm.nih.gov/articles/PMC5128013); [Structural effects of JAK2 exon 13-15 mutations (BMC Struct Biol 2009)](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2749040/); [JAK2 domain table (PMC4943318)](https://pmc.ncbi.nlm.nih.gov/articles/PMC4943318/table/T1); MaveDB TYK2 DMS; AlphaFold DB (AlphaMissense); dbNSFP via myvariant.info; ClinVar; gnomAD v4; cBioPortal; UniProt.'
[IO.File]::WriteAllText("$PWD\upload\JAK2\jak2_homology_inf.md", $md.ToString(), (New-Object Text.UTF8Encoding($false)))
"written: $([math]::Round((Get-Item "$PWD\upload\JAK2\jak2_homology_inf.md").Length/1KB)) KB"
