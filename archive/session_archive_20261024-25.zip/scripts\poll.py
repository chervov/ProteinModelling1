import os, subprocess
for f in ("/tmp/pyro/install.log", "/tmp/pyro/exp.log"):
    if os.path.exists(f):
        txt = open(f, errors="replace").read()
        print(f"=== {f}  ({len(txt)} bytes)")
        print(txt[-1500:] if txt else "(empty)")
print("=== processes")
print(subprocess.run(["bash", "-lc", "ps -eo pid,etime,cmd | grep -E 'pyrosetta|install.sh|experiment' | grep -v grep | head"],
                     capture_output=True, text=True).stdout or "(none)")
