### JAK2 H606C

```
JAK2  MMSKLSHKHLVLN  (centre = 606)
JAK1  MMRQVSHKHIVYL  (centre = 647)
JAK3  LMSQVSYRHLVLL  (centre = 581)
TYK2  LMSQVSHTHLAFV  (centre = 667)
```

| Gene | Residue | Same substitution | AlphaMissense (same subst.) | Position mean AlphaMissense | Variants reported at this position |
|---|---|---|---|---|---|
| JAK2 | H606 | H606C | 0.16 | 0.47 | **H606Q** (ClinVar Uncertain significance; gnomAD AC 112; cBio 2; COSMIC 3)<br>**H606D** (gnomAD AC 1)<br>**H606L** (cBio 1)<br>**H606Y** (gnomAD AC 1) |
| JAK1 | H647 | H647C | 0.62 | 0.89 | **H647N** (cBio 1)<br>**H647P** (gnomAD AC 1) |
| JAK3 | Y581 | Y581C | 0.10 | 0.47 | **Y581C** (gnomAD AC 0)<br>**Y581*** (gnomAD AC 0)<br>**Y581H** (gnomAD AC 1)<br>**Y581S** (gnomAD AC 1) |
| TYK2 | H667 | H667C | 0.40 | 0.75 | **H667N** (gnomAD AC 0)<br>**H667Q** (gnomAD AC 2) DMS signalling: same substitution -0.13 +- 0.28; range at position -1.74 to -0.13. |

