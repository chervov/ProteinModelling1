param($orig, $section, $out)
# Insert section 10 before the data footer. Pure ASCII file; see note in append_section9.ps1.
$t = [IO.File]::ReadAllText($orig, [Text.Encoding]::UTF8)
$sec = [IO.File]::ReadAllText($section, [Text.Encoding]::UTF8)
if ($t -match '## 10\. Cross-check') { 'already present'; return }
$marker = '*Data: `data/ddg/ddg_TYK2_all.json`'
$i = $t.IndexOf($marker)
if ($i -lt 0) { throw 'footer marker not found' }
$res = $t.Substring(0, $i).TrimEnd() + "`r`n`r`n" + $sec.Trim() + "`r`n`r`n" + $t.Substring($i)
[IO.File]::WriteAllText($out, $res, (New-Object Text.UTF8Encoding($false)))
$chk = [IO.File]::ReadAllText($out, [Text.Encoding]::UTF8)
"written $([math]::Round((Get-Item $out).Length/1KB,1)) KB; Delta $(([regex]::Matches($chk,[string][char]0x0394)).Count); mojibake $(([regex]::Matches($chk,[string][char]0x00CE+[string][char]0x201D)).Count)"
