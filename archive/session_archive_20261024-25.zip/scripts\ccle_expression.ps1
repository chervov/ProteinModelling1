param($out)
# Pull CCLE (Broad 2019) RNA-seq expression for JAK/STAT pathway genes in all cell lines.
$api = 'https://www.cbioportal.org/api'
$genes = 'CISH','SOCS1','SOCS2','SOCS3','PIM1','BCL2L1','MYC','CCND1','ID1','OSM','MCL1','BCL2',
         'JAK1','JAK2','JAK3','TYK2','STAT1','STAT3','STAT5A','STAT5B',
         'GBP1','CXCL9','CXCL10','IRF1','B2M','TAP1','HLA-DRA','HLA-A',
         'EPOR','MPL','CSF2RB','IL3RA','IFNGR1','IL6ST','IFNAR1','PTPN1','PTPN2','PTPN6','PTPN11','LNK','SH2B3'
$ids = @{}
foreach ($g in $genes) {
  try { $r = Invoke-RestMethod "$api/genes/$g"; $ids[$g] = $r.entrezGeneId } catch { Write-Warning "no entrez id for $g" }
}
"genes resolved: $($ids.Count)"
$body = @{ entrezGeneIds = @($ids.Values); sampleListId = 'ccle_broad_2019_all' } | ConvertTo-Json -Compress
$d = Invoke-RestMethod -Method Post -Uri "$api/molecular-profiles/ccle_broad_2019_rna_seq_mrna/molecular-data/fetch?projection=SUMMARY" -ContentType 'application/json' -Body $body
$name = @{}; foreach ($k in $ids.Keys) { $name[[string]$ids[$k]] = $k }
$rows = $d | ForEach-Object { [pscustomobject]@{ sampleId = $_.sampleId; gene = $name[[string]$_.entrezGeneId]; value = $_.value } }
$rows | Export-Csv -NoTypeInformation -Encoding UTF8 $out
"rows: $($rows.Count); samples: $(@($rows | Select-Object -Unique sampleId).Count)"
