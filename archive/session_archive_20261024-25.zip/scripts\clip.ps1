param($in)
Add-Type -AssemblyName System.Windows.Forms, System.Web
$rows = Import-Csv $in -Encoding UTF8
$cols = $rows[0].PSObject.Properties.Name
$enc = { param($s) [System.Web.HttpUtility]::HtmlEncode([string]$s) }
$sb = New-Object System.Text.StringBuilder
[void]$sb.Append('<table border="1" style="border-collapse:collapse"><tr>')
foreach ($c in $cols) { [void]$sb.Append('<th>' + (& $enc $c) + '</th>') }
[void]$sb.Append('</tr>')
$tsv = New-Object System.Text.StringBuilder
[void]$tsv.AppendLine(($cols -join "`t"))
foreach ($r in $rows) {
  $vals = foreach ($c in $cols) { $r.$c }
  if ($r.Variant -like 'SECTION:*') {
    [void]$sb.Append('<tr><td colspan="' + $cols.Count + '"><b>' + (& $enc $r.Variant) + '</b></td></tr>')
  } else {
    [void]$sb.Append('<tr>'); foreach ($v in $vals) { [void]$sb.Append('<td>' + (& $enc $v) + '</td>') }; [void]$sb.Append('</tr>')
  }
  [void]$tsv.AppendLine((($vals | ForEach-Object { ([string]$_) -replace "[`t`r`n]", ' ' }) -join "`t"))
}
[void]$sb.Append('</table>')
$frag = $sb.ToString()
$pre = "<html><body><!--StartFragment-->"; $post = "<!--EndFragment--></body></html>"
$hdr = "Version:0.9`r`nStartHTML:{0:D10}`r`nEndHTML:{1:D10}`r`nStartFragment:{2:D10}`r`nEndFragment:{3:D10}`r`n"
$u = [System.Text.Encoding]::UTF8
$hlen = ($hdr -f 0,0,0,0).Length
$sh = $hlen; $sf = $sh + $u.GetByteCount($pre); $ef = $sf + $u.GetByteCount($frag); $eh = $ef + $u.GetByteCount($post)
$html = ($hdr -f $sh,$eh,$sf,$ef) + $pre + $frag + $post
$data = New-Object System.Windows.Forms.DataObject
$data.SetData([System.Windows.Forms.DataFormats]::Html, (New-Object System.IO.MemoryStream(,$u.GetBytes($html))))
$data.SetData([System.Windows.Forms.DataFormats]::UnicodeText, $tsv.ToString())
[System.Windows.Forms.Clipboard]::SetDataObject($data, $true)
"Copied $($rows.Count) rows"
