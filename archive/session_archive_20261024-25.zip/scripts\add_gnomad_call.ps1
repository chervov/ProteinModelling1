param($table)
# Add a "gnomAD" column: 1 = probably benign (AF >= 1e-4 or any homozygotes), 2 = rare/absent (pathogenic not excluded).
$utf8 = New-Object System.Text.UTF8Encoding($false)
$lines = [IO.File]::ReadAllLines($table, $utf8)
$rows = Import-Csv $table -Encoding UTF8
$out = New-Object System.Collections.Generic.List[string]
$out.Add($lines[0] + ',gnomAD')
$n = @{ '1' = 0; '2' = 0 }
for ($i = 0; $i -lt $rows.Count; $i++) {
  $r = $rows[$i]; $call = ''
  if ($r.Variant -match '^(?:Known GOF: )?[A-Z*]\d+(?:[A-Z]|\*|fs|del|_\w+)\S*$') {
    $af = 0.0; [void][double]::TryParse($r.'gnomAD AF', [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$af)
    $call = if ($af -ge 1e-4 -or [int]("0" + $r.'gnomAD homozygotes') -ge 1) { '1' } else { '2' }
    $n[$call]++
  }
  $out.Add($lines[$i + 1] + ',' + $call)
}
[IO.File]::WriteAllLines($table, $out, $utf8)
"1 (benign): $($n['1']); 2 (rare/absent): $($n['2'])"
