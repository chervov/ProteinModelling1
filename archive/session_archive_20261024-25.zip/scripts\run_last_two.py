import marimo._code_mode as cm

async def main():
    async with cm.get_context() as ctx:
        ctx.run_cell("kellogg")
        ctx.run_cell("conclusion")
    print("ran kellogg + conclusion")

await main()
