param($orig, $section, $out)
# Insert section 9 before the data footer, reading both sides as UTF-8 so Greek letters survive.
# Keep this file pure ASCII: PowerShell 5.1 reads a BOM-less .ps1 as ANSI and would corrupt literals.
$t = [IO.File]::ReadAllText($orig, [Text.Encoding]::UTF8)
$sec = [IO.File]::ReadAllText($section, [Text.Encoding]::UTF8)
if ($t -match '## 9\. Measured') { 'already present'; return }
$marker = '*Data: `data/ddg/ddg_TYK2_all.json`'
$i = $t.IndexOf($marker)
if ($i -lt 0) { throw 'footer marker not found' }
$res = $t.Substring(0, $i).TrimEnd() + "`r`n`r`n" + $sec.Trim() + "`r`n`r`n" + $t.Substring($i)
[IO.File]::WriteAllText($out, $res, (New-Object Text.UTF8Encoding($false)))
$chk = [IO.File]::ReadAllText($out, [Text.Encoding]::UTF8)
$delta = ([regex]::Matches($chk, [string][char]0x0394)).Count
$moji = ([regex]::Matches($chk, [string][char]0x00CE + [string][char]0x201D)).Count
"written $([math]::Round((Get-Item $out).Length/1KB,1)) KB; Delta chars $delta; mojibake $moji"
