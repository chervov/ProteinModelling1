import marimo._code_mode as cm

async def main():
    async with cm.get_context() as ctx:
        for c in ctx.cells:
            errs = c.errors or []
            print(f"{(c.name or '?'):14s} {c.status:12s} errors={len(errs)}")
            for e in errs[:2]:
                print("   ", str(e)[:200])
        print("total cells:", len(list(ctx.cells.keys())))

await main()
