param($joined, $am)
# Sanity checks on the ddG values: behaviour per substituted amino acid, and agreement with AlphaMissense.
$rows = @(Import-Csv $joined)
"n = $($rows.Count)"
"`nMean ddg_closed and DMS abundance by substituted residue (destabilising residues should stand out):"
"{0,-4} {1,10} {2,10} {3,10}" -f 'alt', 'ddg_closed', 'abundance', 'n'
foreach ($g in ($rows | Group-Object { $_.Variant[-1] } | Sort-Object { ($_.Group | ForEach-Object { [double]$_.ddg_closed } | Measure-Object -Average).Average })) {
  $ab = @($g.Group | Where-Object { $_.abundance } | ForEach-Object { [double]$_.abundance })
  "{0,-4} {1,10} {2,10} {3,10}" -f $g.Name,
    [math]::Round((($g.Group | ForEach-Object { [double]$_.ddg_closed } | Measure-Object -Average).Average), 1),
    $(if ($ab.Count) { [math]::Round((($ab | Measure-Object -Average).Average), 2) } else { '-' }), $g.Count
}
# agreement with AlphaMissense
$amH = @{}; Import-Csv $am | ForEach-Object { $amH[$_.protein_variant] = [double]$_.am_pathogenicity }
$sel = @($rows | Where-Object { $amH.ContainsKey($_.Variant) })
function Pearson($x, $y) {
  $n = $x.Count; $mx = ($x | Measure-Object -Average).Average; $my = ($y | Measure-Object -Average).Average
  $sxy = 0.0; $sxx = 0.0; $syy = 0.0
  for ($i = 0; $i -lt $n; $i++) { $dx = $x[$i] - $mx; $dy = $y[$i] - $my; $sxy += $dx * $dy; $sxx += $dx * $dx; $syy += $dy * $dy }
  if ($sxx -le 0 -or $syy -le 0) { return 'n/a' }
  [math]::Round($sxy / [math]::Sqrt($sxx * $syy), 3)
}
"`nAlphaMissense (high = damaging) vs ddG, n = $($sel.Count):"
foreach ($f in 'ddg_closed', 'ddg_open', 'delta') {
  "  AlphaMissense vs {0,-11} Pearson r = {1}" -f $f, (Pearson @($sel | ForEach-Object { [double]$_.$f }) @($sel | ForEach-Object { $amH[$_.Variant] }))
}
"  AlphaMissense vs |delta|    Pearson r = $(Pearson @($sel | ForEach-Object { [math]::Abs([double]$_.delta) }) @($sel | ForEach-Object { $amH[$_.Variant] }))"
"`nextreme ddG values (|ddg_closed| > 500): $(@($rows | Where-Object { [math]::Abs([double]$_.ddg_closed) -gt 500 }).Count) of $($rows.Count)"
"positions worst affected:"
$rows | Group-Object pos | Sort-Object { ($_.Group | ForEach-Object { [double]$_.ddg_closed } | Measure-Object -Average).Average } | Select-Object -First 5 | ForEach-Object {
  "  pos {0,5}  mean ddg_closed {1,9}  mean abundance {2}" -f $_.Name,
    [math]::Round((($_.Group | ForEach-Object { [double]$_.ddg_closed } | Measure-Object -Average).Average), 0),
    $(($ab = @($_.Group | Where-Object { $_.abundance } | ForEach-Object { [double]$_.abundance })); if ($ab.Count) { [math]::Round((($ab | Measure-Object -Average).Average), 2) } else { '-' })
}
