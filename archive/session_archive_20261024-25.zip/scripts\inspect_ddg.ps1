param($dir)
# Summarise the repo's ddG result files (two-state ddG per substitution).
foreach ($p in @(@('JAK1', 'ddg_JAK1_all.json'), @('TYK2', 'ddg_TYK2_all.json'))) {
  $j = Get-Content -Raw (Join-Path $dir $p[1]) | ConvertFrom-Json
  $a = @($j)
  $pos = @($a | ForEach-Object { [int]$_.pos })
  $uniq = @($pos | Select-Object -Unique).Count
  $d = @($a | ForEach-Object { [double]$_.delta })
  $c = @($a | ForEach-Object { [double]$_.ddg_closed })
  $o = @($a | ForEach-Object { [double]$_.ddg_open })
  function St($v) {
    $mu = ($v | Measure-Object -Average).Average
    $sd = [math]::Sqrt((($v | ForEach-Object { ($_ - $mu) * ($_ - $mu) } | Measure-Object -Sum).Sum) / $v.Count)
    "mean {0,6} sd {1,5} range {2} to {3}" -f [math]::Round($mu, 2), [math]::Round($sd, 2), [math]::Round(($v | Measure-Object -Minimum).Minimum, 1), [math]::Round(($v | Measure-Object -Maximum).Maximum, 1)
  }
  "== $($p[0]): $($a.Count) substitutions over $uniq positions ($([math]::Round($a.Count / $uniq, 1)) per position), residues $(($pos | Measure-Object -Minimum).Minimum)-$(($pos | Measure-Object -Maximum).Maximum)"
  "   ddg_closed : $(St $c)"
  "   ddg_open   : $(St $o)"
  "   delta      : $(St $d)"
}
