param($neighbours, $out)
# Annotate JAK3 residues near Y581 with JAK3 variant data and the aligned residue (plus known hotspots) in JAK1/JAK2/TYK2.
$nb = Import-Csv $neighbours
$map = Import-Csv "$PWD\sources\alignment\jak2_position_map.csv"
$j3 = @{}; foreach ($r in $map) { if ($r.JAK3_pos) { $j3[[int]$r.JAK3_pos] = $r } }
$t = Import-Csv "$PWD\upload\JAK3\jak3_variants_full_local.csv" | Where-Object { $_.Variant -notlike 'SECTION:*' }
function Pos($v) { $m = [regex]::Match($v, '^[A-Z*](\d+)'); if ($m.Success) { [int]$m.Groups[1].Value } else { -1 } }
$byPos = @{}; foreach ($r in $t) { $p = Pos $r.Variant; if ($p -gt 0) { if (-not $byPos[$p]) { $byPos[$p] = @() }; $byPos[$p] += $r } }
# Known hotspots in paralogs: OncoKB gain-of-function/oncogenic, ClinVar P/LP, curated JAK1 table
$hot = @{ JAK1 = @{}; JAK2 = @{}; TYK2 = @{} }
foreach ($o in Import-Csv "$PWD\sources\oncokb_jak1.csv") { $p = Pos $o.Variant; if ($p -gt 0) { $hot.JAK1[$p] += @("$($o.Variant) (OncoKB $($o.Oncogenic))") } }
foreach ($g in 'JAK2', 'TYK2') { foreach ($o in Import-Csv "$PWD\sources\$g\oncokb.csv") { $p = Pos $o.Variant; if ($p -gt 0 -and $o.Oncogenic -match 'Oncogenic|Resistance') { $hot[$g][$p] += @("$($o.Variant) (OncoKB $($o.Oncogenic))") } } }
foreach ($r in Import-Csv "$PWD\TYK_JAK_mutations - Sheet3 (with ClinVar).csv" -Encoding UTF8 | Select-Object -First 79) { $p = Pos ($r.Variant -replace '^Known GOF: ', ''); if ($p -gt 0 -and $r.Conclusions -match 'GOF|LOF|Activating|Transforming') { $hot.JAK1[$p] += @("$($r.Variant -replace '^Known GOF: ', '') ($($r.Conclusions))") } }
foreach ($g in 'JAK2', 'TYK2') { foreach ($r in Import-Csv "$PWD\upload\$g\$($g.ToLower())_variants_full_local.csv") { $p = Pos $r.Variant; if ($p -gt 0 -and $r.ClinVar -match '^(Pathogenic|Likely pathogenic)') { $hot[$g][$p] += @("$($r.Variant) (ClinVar $($r.ClinVar))") } } }
$rows = foreach ($n in $nb) {
  $p = [int]$n.res; $vs = @($byPos[$p])
  $plp = @($vs | Where-Object { $_.ClinVar -match 'athogenic' -and $_.ClinVar -notmatch 'onflict' } | ForEach-Object { "$($_.Variant) $($_.ClinVar) ($($_.Condition))" })
  $okb = @($vs | Where-Object { $_.'OncoKB oncogenic' } | ForEach-Object { "$($_.Variant) $($_.'OncoKB oncogenic')/$($_.'OncoKB mutation effect')" })
  $cos = ($vs | ForEach-Object { [int]("0" + $_.'COSMIC samples') } | Measure-Object -Sum).Sum
  $gn = @($vs | Where-Object { $_.gnomAD -eq '1' } | ForEach-Object { "$($_.Variant) ($($_.'gnomAD AF'))" })
  $r = $j3[$p]
  $para = foreach ($g in 'JAK1', 'JAK2', 'TYK2') {
    $q = if ($g -eq 'JAK2') { [int]$r.JAK2_pos } elseif ($r -and $r."${g}_pos") { [int]$r."${g}_pos" } else { 0 }
    $aa = if ($g -eq 'JAK2') { $r.JAK2_aa } else { $r."${g}_aa" }
    if ($q) { $h = @($hot[$g][$q] | Select-Object -Unique); "$g $aa$q$(if ($h) { ': ' + ($h -join ', ') })" } else { "$g -" }
  }
  [pscustomobject]@{
    Residue = "$($n.aa)$p"; 'Min dist (A)' = $n.dmin; Region = $(if ($p -le 356) { 'FERM' } elseif ($p -le 475) { 'SH2-like' } elseif ($p -ge 521 -and $p -le 781) { 'JH2' } elseif ($p -ge 822) { 'JH1' } else { 'linker' })
    'JAK3 P/LP (ClinVar)' = $plp -join '; '; 'JAK3 OncoKB' = $okb -join '; '; 'JAK3 COSMIC samples' = $cos; 'gnomAD common' = $gn -join '; '
    'Variants at residue' = $vs.Count; 'JAK1 / JAK2 / TYK2 equivalent (known hotspots)' = $para -join ' | '
  }
}
$rows | Export-Csv -NoTypeInformation -Encoding UTF8 $out
$rows | Format-List | Out-String -Width 300
