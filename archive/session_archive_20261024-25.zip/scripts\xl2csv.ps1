param($dir, $sheet, $out)
$ns = @{m='http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
[xml]$ss = Get-Content -Raw -Encoding UTF8 "$dir\xl\sharedStrings.xml"
$strings = @($ss.sst.si | ForEach-Object { if ($_.t -ne $null) { if ($_.t -is [string]) { $_.t } else { $_.t.'#text' } } else { ($_.r | ForEach-Object { if ($_.t -is [string]) { $_.t } else { $_.t.'#text' } }) -join '' } })
[xml]$sh = Get-Content -Raw -Encoding UTF8 "$dir\xl\worksheets\$sheet.xml"
function ColIdx($ref) { $l = ($ref -replace '\d',''); $n=0; foreach ($ch in $l.ToCharArray()) { $n = $n*26 + ([int]$ch - 64) }; $n-1 }
$lines = New-Object System.Collections.Generic.List[string]
foreach ($row in $sh.worksheet.sheetData.row) {
  $vals = @{}; $max = -1
  foreach ($c in $row.c) {
    $i = ColIdx $c.r; if ($i -gt $max) { $max = $i }
    $v = $c.v
    if ($c.t -eq 's') { $v = $strings[[int]$v] } elseif ($c.t -eq 'inlineStr') { $v = $c.is.t }
    $vals[$i] = $v
  }
  $cells = for ($k=0; $k -le $max; $k++) { $x = [string]$vals[$k]; '"' + ($x -replace '"','""') + '"' }
  $lines.Add(($cells -join ','))
}
[IO.File]::WriteAllLines($out, $lines)
