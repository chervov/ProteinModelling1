param($out, $gene = 'JAK1')
# Fetch all CIViC evidence items whose molecular profile involves the gene's variants.
$api = 'https://civicdb.org/api/graphql'
function Gql($q) {
  $w = Invoke-WebRequest -Method Post -Uri $api -ContentType 'application/json' -Body (@{ query = $q } | ConvertTo-Json -Compress) -UseBasicParsing
  $w.Content | ConvertFrom-Json
}
$g = (Gql "{ gene(entrezSymbol: `"$gene`") { id name } }").data.gene
$vars = (Gql "{ variants(geneId: $($g.id), first: 500) { totalCount nodes { id name } } }").data.variants
$rows = New-Object System.Collections.Generic.List[object]
foreach ($v in $vars.nodes) {
  $q = "{ evidenceItems(variantId: $($v.id), first: 200, status: ALL) { nodes { id name status evidenceType evidenceLevel evidenceDirection significance variantOrigin evidenceRating molecularProfile { name } disease { name } therapies { name } source { citation sourceType citationId } } } }"
  $e = (Gql $q).data.evidenceItems.nodes
  foreach ($x in @($e)) {
    $rows.Add([pscustomobject]@{
      Variant = $v.name; MolecularProfile = $x.molecularProfile.name; EID = $x.name; Status = $x.status
      Type = $x.evidenceType; Level = $x.evidenceLevel; Direction = $x.evidenceDirection; Significance = $x.significance
      Origin = $x.variantOrigin; Rating = $x.evidenceRating; Disease = $x.disease.name
      Therapies = (@($x.therapies) | ForEach-Object { $_.name }) -join ' + '
      Source = "$($x.source.citation) ($($x.source.sourceType) $($x.source.citationId))"
    })
  }
}
$rows | Sort-Object EID -Unique | Export-Csv -NoTypeInformation -Encoding UTF8 $out
"CIViC $gene variants: $($vars.totalCount) ($((@($vars.nodes) | ForEach-Object { $_.name }) -join ', '))"
"evidence items: $(@($rows | Sort-Object EID -Unique).Count)"
