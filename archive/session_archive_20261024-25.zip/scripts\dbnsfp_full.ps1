param($rawOut, $out, $gene = 'JAK1', $canon = 'ENST00000342505', $acc = 'P23458')
# Fetch full dbNSFP records for a gene from myvariant.info and flatten every predictor/conservation score and call
# for the canonical transcript and UniProt entry, one row per protein change.
$skipTop = 'aa','alt','ref','chrom','hg18','hg19','hg38','ensembl','genename','hgvsc','hgvsp','uniprot','refseq','rsid','interpro_domain','clinvar','gtex','1000gp3','alfa','esp6500','exac','gnomad_exomes','gnomad_genomes','uk10k','twinsuk','alspac','altai_neandertal','denisova','vindija_neandertal','chagyrskaya_neandertal','ancestral_allele','appris','tsl','vep_canonical','mane','gencode_basic','aloft','geuvadis_eqtl_target_gene','_license','cds_strand','codon_degeneracy','bstatistic','fitcons'
if (-not (Test-Path $rawOut)) {
  $docs = New-Object System.Collections.Generic.List[object]
  $r = Invoke-RestMethod "https://myvariant.info/v1/query?q=dbnsfp.genename:$gene&fields=dbnsfp,cadd.phred&fetch_all=true"
  while ($r.hits -and @($r.hits).Count) { foreach ($h in $r.hits) { $docs.Add($h) }; $r = Invoke-RestMethod "https://myvariant.info/v1/query?scroll_id=$($r._scroll_id)" }
  $docs | ConvertTo-Json -Depth 12 -Compress | Out-File -Encoding utf8 $rawOut
}
$docs = Get-Content -Raw $rawOut | ConvertFrom-Json

function Leaves($obj, $prefix, $acc) {
  foreach ($p in $obj.PSObject.Properties) {
    $path = if ($prefix) { "$prefix.$($p.Name)" } else { $p.Name }
    $v = $p.Value
    if ($v -is [System.Management.Automation.PSCustomObject]) { Leaves $v $path $acc }
    else { $acc[$path] = $v }
  }
}
$byP = @{}; $colSet = [ordered]@{}
foreach ($d in $docs) {
  $n = $d.dbnsfp; if (-not $n) { continue }
  $tx = @($n.ensembl.transcriptid); $ti = [array]::IndexOf($tx, $canon); if ($ti -lt 0) { continue }
  $ua = @($n.uniprot | ForEach-Object { $_.acc }); $ui = [array]::IndexOf($ua, $acc)
  $pick = {
    param($v)
    $a = @($v | Where-Object { $_ -ne $null -and "$_" -ne '.' })
    if (@($v).Count -eq $tx.Count -and $tx.Count -gt 1) { $x = @($v)[$ti] }
    elseif ($ui -ge 0 -and @($v).Count -eq $ua.Count -and $ua.Count -gt 1) { $x = @($v)[$ui] }
    elseif ($a.Count -le 1) { $x = $a | Select-Object -First 1 }
    else { $x = ($a | Select-Object -Unique) -join '/' }
    if ("$x" -eq '.') { $null } else { $x }
  }
  $pos = & $pick $n.aa.pos; $ref = & $pick $n.aa.ref; $alt = & $pick $n.aa.alt
  if (-not $pos -or $alt -eq $ref) { continue }
  $alt = if ($alt -eq 'X') { '*' } else { $alt }
  $key = "$ref$pos$alt"
  $leaf = [ordered]@{}; Leaves $n '' $leaf
  $row = [ordered]@{ 'DNA change (hg19)' = $d._id; 'CADD phred' = $d.cadd.phred }
  foreach ($k in $leaf.Keys) {
    $top = $k.Split('.')[0]
    if ($skipTop -contains $top) { continue }
    if ($k -notmatch '(^|\.)(score|pred|phred|coding_score|coding_pred|raw_coding|phred_coding|converted_score)$' -or $k -match 'rankscore') { continue }
    $val = & $pick $leaf[$k]
    if ($val -ne $null -and "$val" -ne '') { $row[$k] = $val; $colSet[$k] = 1 }
  }
  if (-not $byP.ContainsKey($key)) { $byP[$key] = New-Object System.Collections.Generic.List[object] }
  $byP[$key].Add($row)
}
$cols = @('DNA change (hg19)', 'CADD phred') + @($colSet.Keys | Sort-Object)
$rows = foreach ($key in $byP.Keys) {
  $o = [ordered]@{ Variant = $key }
  foreach ($c in $cols) { $o[$c] = (@($byP[$key] | ForEach-Object { $_[$c] } | Where-Object { $_ -ne $null -and "$_" -ne '' } | ForEach-Object { "$_" } | Select-Object -Unique)) -join ' | ' }
  [pscustomobject]$o
}
$rows | Export-Csv -NoTypeInformation -Encoding UTF8 $out
"documents: $(@($docs).Count); protein changes: $($byP.Count); score columns: $($cols.Count)"
($cols | Select-Object -Skip 1) -join ', '
