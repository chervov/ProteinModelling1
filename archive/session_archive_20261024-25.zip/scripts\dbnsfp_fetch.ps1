param($out, $gene = 'JAK1', $canon = 'ENST00000342505')
# Fetch dbNSFP predictor scores for all missense SNVs of a gene from myvariant.info and reduce them to the canonical transcript.
$fields = 'dbnsfp.aa.ref,dbnsfp.aa.alt,dbnsfp.aa.pos,dbnsfp.ensembl.transcriptid,dbnsfp.revel.score,dbnsfp.sift.score,dbnsfp.sift.pred,dbnsfp.polyphen2.hvar.score,dbnsfp.polyphen2.hvar.pred,dbnsfp.cadd.phred,cadd.phred,dbnsfp.metarnn.score,dbnsfp.esm1b.score,dbnsfp.primateai.score,dbnsfp.hgvsp'
$url = "https://myvariant.info/v1/query?q=dbnsfp.genename:$gene&fields=$fields&fetch_all=true"
$docs = New-Object System.Collections.Generic.List[object]
$r = Invoke-RestMethod $url
while ($r.hits -and @($r.hits).Count) {
  foreach ($h in $r.hits) { $docs.Add($h) }
  $r = Invoke-RestMethod "https://myvariant.info/v1/query?scroll_id=$($r._scroll_id)"
}
function Pick($val, $idx) { $a = @($val); if ($a.Count -eq 0) { return $null }; if ($idx -ge 0 -and $idx -lt $a.Count) { $a[$idx] } else { $a[0] } }
$rows = foreach ($d in $docs) {
  $n = $d.dbnsfp; if (-not $n) { continue }
  $tx = @($n.ensembl.transcriptid); $i = [array]::IndexOf($tx, $canon)
  if ($i -lt 0) { continue }   # variant not on the canonical transcript
  $pos = Pick $n.aa.pos $i; $ref = Pick $n.aa.ref $i; $alt = Pick $n.aa.alt $i
  if (-not $pos -or $alt -eq $ref) { continue }
  $alt = if ($alt -eq 'X') { '*' } else { $alt }
  $cadd = if ($d.cadd.phred) { $d.cadd.phred } else { $n.cadd.phred }
  [pscustomobject]@{
    Variant = "$ref$pos$alt"; genomic = $d._id
    REVEL = Pick $n.revel.score $i; CADD_phred = Pick $cadd 0
    SIFT = Pick $n.sift.score $i; SIFT_pred = Pick $n.sift.pred $i
    PolyPhen2_HVAR = ((@($n.polyphen2.hvar.score) | Where-Object { $_ -ne $null } | Measure-Object -Maximum).Maximum)
    PolyPhen2_pred = ((@($n.polyphen2.hvar.pred) | Where-Object { $_ }) | Sort-Object { 'DPB'.IndexOf($_) } | Select-Object -First 1)
    MetaRNN = Pick $n.metarnn.score $i; ESM1b = Pick $n.esm1b.score $i; PrimateAI = Pick $n.primateai.score 0
  }
}
$rows | Export-Csv -NoTypeInformation -Encoding UTF8 $out
"documents: $($docs.Count); canonical-transcript amino-acid changes: $(@($rows).Count); unique protein changes: $(@($rows | Select-Object -Unique Variant).Count)"
