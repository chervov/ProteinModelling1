param($gene, $nm, [string[]]$priority, $domains, $outDir, $cosmic = '', $classGz = '', $decipher = @{})
# Build the full local variant table for one gene (priority variants first, then ClinVar, then CIViC),
# with ClinVar, gnomAD, cBioPortal, CIViC, LOVD, OncoKB, COSMIC, AlphaMissense, dbNSFP and (TYK2) MaveDB DMS columns.
$d = Join-Path $PWD "sources\$gene"
$inv = [Globalization.CultureInfo]::InvariantCulture
$three = @{Ala='A';Arg='R';Asn='N';Asp='D';Cys='C';Gln='Q';Glu='E';Gly='G';His='H';Ile='I';Leu='L';Lys='K';Met='M';Phe='F';Pro='P';Ser='S';Thr='T';Trp='W';Tyr='Y';Val='V';Ter='*'}
function ToOne($p) { $p = $p -replace '^p\.\(?', '' -replace '\)$', ''; ([regex]::Replace($p, 'Ala|Arg|Asn|Asp|Cys|Gln|Glu|Gly|His|Ile|Leu|Lys|Met|Phe|Pro|Ser|Thr|Trp|Tyr|Val|Ter', { param($m) $three[$m.Value] })) -replace '^(\*\d+[A-Z])ext\*\d+$', '$1' }
function Num($s) { $x = 0.0; if ([double]::TryParse([string]$s, [Globalization.NumberStyles]::Float, $inv, [ref]$x)) { $x } else { $null } }
function Join($vals) { (@($vals) | Where-Object { $_ } | Select-Object -Unique) -join ' | ' }
function Pos($v) { $m = [regex]::Match($v, '\d+'); if ($m.Success) { [int]$m.Value } else { 99999 } }
function Domain($v) {
  $p = Pos $v; if ($p -eq 99999) { return '' }
  foreach ($k in $domains.Keys) { $r = $domains[$k]; if ($p -ge $r[0] -and $p -le $r[1]) { return $k } }
  $starts = @($domains.Values | ForEach-Object { $_[0] }); $ends = @($domains.Values | ForEach-Object { $_[1] })
  if ($p -lt ($starts | Measure-Object -Minimum).Minimum) { 'N-terminal' } elseif ($p -gt ($ends | Measure-Object -Maximum).Maximum) { 'C-terminal' } else { 'linker' }
}
function CivicName($n) {
  if ($n -match '^[A-Z][a-z]{2}\d+[A-Z][a-z]{2}$') { return (ToOne $n) }
  $label = @{ 'Mutation' = "$gene mutation (any; gene-level CIViC entry)"; 'Overexpression' = "$gene overexpression (gene-level CIViC entry)" }   # keys are case-insensitive
  if ($label.ContainsKey($n)) { $label[$n] } else { $n }
}

# ---- ClinVar ----
$cv = @{}
foreach ($r in (Get-Content -Raw -Encoding UTF8 "$d\clinvar.json" | ConvertFrom-Json)) {
  $m = [regex]::Match($r.title, "^$nm\.\d+\($gene\):(c\.\S+) \(p\.([^)]+)\)$")
  if (-not $m.Success -or $m.Groups[2].Value -match '=$') { continue }
  $p = ToOne $m.Groups[2].Value
  if (-not $cv.ContainsKey($p)) { $cv[$p] = New-Object System.Collections.Generic.List[object] }
  $r | Add-Member -NotePropertyName cdna -NotePropertyValue $m.Groups[1].Value -Force
  $cv[$p].Add($r)
}
# ---- gnomAD ----
$g = Get-Content -Raw "$d\gnomad.json" | ConvertFrom-Json
$gn = @{}
foreach ($x in $g.variants) {
  if ($x.transcript_id -ne $g.canonical_transcript_id -or -not $x.hgvsp) { continue }
  $p = ToOne $x.hgvsp; if ($p -match '^[A-Z]\d+[A-Z]$' -and $p[0] -eq $p[-1]) { continue }
  if (-not $gn.ContainsKey($p)) { $gn[$p] = @{ ac = 0; an = 0; hom = 0 } }
  $gn[$p].ac += [int]$x.exome.ac + [int]$x.genome.ac
  $gn[$p].an = [Math]::Max($gn[$p].an, [int]$x.exome.an + [int]$x.genome.an)
  $gn[$p].hom += [int]$x.exome.homozygote_count + [int]$x.genome.homozygote_count
}
# ---- cBioPortal ----
$cb = @{}
foreach ($grp in (Import-Csv "$d\cbioportal_raw.csv" | Where-Object { $_.proteinChange -and $_.mutationType -notmatch 'Splice' } | Group-Object proteinChange)) {
  $cb[$grp.Name -replace '^p\.', ''] = [pscustomobject]@{
    pts = @($grp.Group | Select-Object -Unique patientId).Count
    studies = @($grp.Group | Select-Object -Unique studyId).Count
    top = (($grp.Group | Sort-Object patientId -Unique | Group-Object cancerType | Sort-Object Count -Descending | Select-Object -First 3) | ForEach-Object { "$($_.Name) ($($_.Count))" }) -join '; '
  }
}
# ---- CIViC ----
$lvl = @{ A = 'validated'; B = 'clinical'; C = 'case study'; D = 'preclinical'; E = 'inferential' }
$civ = @{}
if (Test-Path "$d\civic.csv") {
  foreach ($grp in (Import-Csv "$d\civic.csv" | Group-Object { CivicName $_.Variant })) {
    $civ[$grp.Name] = ($grp.Group | Sort-Object Type -Descending | ForEach-Object {
      $sig = ($_.Significance -replace 'SENSITIVITYRESPONSE', 'sensitivity' -replace '_', ' ').ToLower()
      $dir = if ($_.Direction -eq 'DOES_NOT_SUPPORT') { 'NOT ' } else { '' }
      $what = if ($_.Type -eq 'PREDICTIVE') { "$($_.Therapies): $dir$sig" } else { "$((Get-Culture).TextInfo.ToTitleCase($_.Type.ToLower())): $dir$sig" }
      $dis = if ($_.Disease) { ", $($_.Disease)" } else { '' }
      "$what$dis (level $($_.Level) $($lvl[$_.Level]), $($_.Status.ToLower()), $($_.EID))"
    }) -join '; '
  }
}
# ---- LOVD ----
$lv = @{}
$lovd = Get-Content -Raw "$d\lovd.json" | ConvertFrom-Json   # assign first: PS 5.1 pipes a JSON array as one object
foreach ($grp in ($lovd | ForEach-Object { $t = ($_.variants_on_transcripts.PSObject.Properties | Select-Object -First 1).Value; [pscustomobject]@{ p = (ToOne $t.protein); eff = ($_.effect_reported -join '/') } } | Where-Object { $_.p -and $_.p -notmatch '=' -and $_.p -ne '?' } | Group-Object p)) {
  $lv[$grp.Name] = @($grp.Count, ((@($grp.Group.eff | Select-Object -Unique)) -join '; '))
}
# ---- OncoKB ----
$ok = @{}; Import-Csv "$d\oncokb.csv" | ForEach-Object { $ok[$_.Variant] = $_ }
# ---- COSMIC (local only) ----
$cs = @{}
if ($cosmic -and (Test-Path $cosmic)) {
  $fs = [IO.File]::OpenRead($classGz); $gz = New-Object IO.Compression.GZipStream($fs, [IO.Compression.CompressionMode]::Decompress); $sr = New-Object IO.StreamReader($gz)
  $site = @{}; foreach ($c in ($sr.ReadToEnd() | ConvertFrom-Csv -Delimiter "`t")) { $site[$c.COSMIC_PHENOTYPE_ID] = $c.PRIMARY_SITE }; $sr.Close()
  foreach ($grp in (Import-Csv $cosmic -Delimiter "`t" | Where-Object { $_.TRANSCRIPT_ACCESSION -like "$($g.canonical_transcript_id)*" -and $_.MUTATION_AA -and $_.MUTATION_AA -ne 'p.?' -and $_.MUTATION_AA -notmatch '=$' } | Group-Object { $_.MUTATION_AA -replace '^p\.', '' })) {
    $s = @($grp.Group | Sort-Object COSMIC_SAMPLE_ID -Unique)
    $cs[$grp.Name] = @($s.Count, (($s | Group-Object { $z = $site[$_.COSMIC_PHENOTYPE_ID]; if ($z) { $z } else { 'NS' } } | Sort-Object Count -Descending | Select-Object -First 3 | ForEach-Object { "$($_.Name -replace '_', ' ') ($($_.Count))" }) -join '; '), ((@($grp.Group.LEGACY_MUTATION_ID | Where-Object { $_ -and $_ -ne 'None' } | Select-Object -Unique) | Select-Object -First 3) -join ' | '))
  }
}
# ---- AlphaMissense / dbNSFP core / dbNSFP all ----
$amClass = @{ LPath = 'likely pathogenic'; Amb = 'ambiguous'; LBen = 'likely benign' }
$am = @{}; Import-Csv "$d\predictors\alphamissense.csv" | ForEach-Object { $am[$_.protein_variant] = $_ }
$core = @{}
foreach ($grp in (Import-Csv "$d\predictors\dbnsfp_core.csv" | Group-Object Variant)) {
  $x = $grp.Group
  $mx = { param($f) ($x | ForEach-Object { Num $_.$f } | Where-Object { $_ -ne $null } | Measure-Object -Maximum).Maximum }
  $mn = { param($f) ($x | ForEach-Object { Num $_.$f } | Where-Object { $_ -ne $null } | Measure-Object -Minimum).Minimum }
  $core[$grp.Name] = [ordered]@{ 'REVEL' = & $mx 'REVEL'; 'CADD phred' = & $mx 'CADD_phred'; 'SIFT' = & $mn 'SIFT'; 'PolyPhen-2 HVAR' = & $mx 'PolyPhen2_HVAR'; 'MetaRNN' = & $mx 'MetaRNN'; 'ESM1b' = & $mn 'ESM1b' }
}
$all = @{}; $allCols = @()
if (Test-Path "$d\predictors\dbnsfp_all_scores.csv") {
  $dup = 'CADD phred','revel.score','sift.score','polyphen2.hvar.score','metarnn.score','esm1b.score','DNA change (hg19)'
  $tmp = Import-Csv "$d\predictors\dbnsfp_all_scores.csv"
  $allCols = @($tmp[0].PSObject.Properties.Name | Where-Object { $_ -ne 'Variant' -and $dup -notcontains $_ })
  foreach ($r in $tmp) { $all[$r.Variant] = $r }
}
# ---- MaveDB DMS (TYK2) ----
$dms = @{}
foreach ($f in @(Get-ChildItem "$d\mavedb\*.csv" -ErrorAction SilentlyContinue)) {
  $label = if ($f.Name -like '*00001271*') { 'DMS abundance (VAMP-seq)' } else { 'DMS signalling (IFN-a 100U/mL)' }
  foreach ($r in (Import-Csv $f.FullName)) { if ($r.hgvs_pro -and $r.hgvs_pro -ne 'NA') { $k = ToOne $r.hgvs_pro; if (-not $dms.ContainsKey($k)) { $dms[$k] = @{} }; $dms[$k][$label] = ([double]$r.score).ToString('0.###', $inv) } }
}
$dmsCols = @($dms.Values | ForEach-Object { $_.Keys } | Select-Object -Unique | Sort-Object -Descending)

# ---- Row list: priority, ClinVar, CIViC ----
$aaSeq = @{}; foreach ($k in $am.Keys) { $aaSeq[[int]($k -replace '\D', '')] = $k[0] }
$rows = New-Object System.Collections.Generic.List[object]
$seen = @{}; $warn = @()
function NewRow($v, $section) { [ordered]@{ Variant = $v; Domain = (Domain $v); Cluster = '' } }
$rows.Add(@{ Variant = "SECTION: PRIORITY VARIANTS (requested)" })
foreach ($v in $priority) {
  $p = Pos $v; if ($aaSeq.ContainsKey($p) -and "$($aaSeq[$p])" -ne "$($v[0])") { $warn += "$v (reference residue at $p is $($aaSeq[$p]))" }
  $rows.Add((NewRow $v)); $seen[$v] = 1
}
$rows.Add(@{ Variant = "SECTION: CLINVAR - PROTEIN-LEVEL VARIANTS ($nm)" })
foreach ($v in ($cv.Keys | Where-Object { -not $seen[$_] } | Sort-Object { Pos $_ }, { $_ })) { $rows.Add((NewRow $v)); $seen[$v] = 1 }
$extraCivic = @($civ.Keys | Where-Object { -not $seen[$_] })
# Every other protein change observed in any source gets its own row (gene-level OncoKB/CIViC labels included)
$okVar = @($ok.Keys | Where-Object { $_ -match '^[A-Z*]\d+' })
$other = @(@($gn.Keys) + @($cb.Keys) + @($cs.Keys) + @($lv.Keys) + $okVar + $extraCivic + @($decipher.Keys) | Where-Object { $_ -and -not $seen[$_] } | Select-Object -Unique | Sort-Object { Pos $_ }, { $_ })
if ($other.Count) {
  $rows.Add(@{ Variant = "SECTION: OTHER OBSERVED VARIANTS (not in ClinVar; seen in gnomAD, cBioPortal, COSMIC, LOVD, OncoKB, CIViC or DECIPHER)" })
  foreach ($v in $other) { $rows.Add((NewRow $v)); $seen[$v] = 1 }
}
function SeenIn($v) {
  $s = @()
  if ($cv.ContainsKey($v)) { $s += 'ClinVar' }; if ($gn.ContainsKey($v)) { $s += 'gnomAD' }; if ($cb.ContainsKey($v)) { $s += 'cBioPortal' }
  if ($cs.ContainsKey($v)) { $s += 'COSMIC' }; if ($lv.ContainsKey($v)) { $s += 'LOVD' }; if ($civ.ContainsKey($v)) { $s += 'CIViC' }
  if ($ok.ContainsKey($v)) { $s += 'OncoKB' }; if ($decipher.ContainsKey($v)) { $s += 'DECIPHER' }
  $s -join ', '
}

# ---- Fill columns ----
$predCols = @('AlphaMissense', 'AlphaMissense class', 'REVEL', 'CADD phred', 'SIFT', 'PolyPhen-2 HVAR', 'MetaRNN', 'ESM1b')
$extCols = @($allCols | ForEach-Object { "dbNSFP $_" }) + 'dbNSFP DNA change (hg19)'
$tail = 'Conclusions','Brief evidence','Reference','DRUG','CIViC evidence','ClinVar','Review status','Condition','Last evaluated','Somatic clinical impact',"ClinVar DNA change ($nm)",'ClinVar variation ID','gnomAD allele count','gnomAD AF','gnomAD homozygotes','gnomAD','cBioPortal patients','cBioPortal studies','cBioPortal top cancer types','COSMIC samples','COSMIC top primary sites','COSMIC mutation ID','OncoKB oncogenic','OncoKB mutation effect','LOVD entries','LOVD reported effect','DECIPHER','Seen in'
$cols =@('Variant', 'Domain', 'Cluster') + $dmsCols + $predCols + $extCols + $tail
$out = foreach ($r in $rows) {
  $o = [ordered]@{}; foreach ($c in $cols) { $o[$c] = '' }
  $v = $r.Variant; $o.Variant = $v
  if ($v -like 'SECTION:*') { [pscustomobject]$o; continue }
  $o.Domain = $r.Domain
  if ($dms.ContainsKey($v)) { foreach ($c in $dmsCols) { $o[$c] = $dms[$v][$c] } }
  if ($am.ContainsKey($v)) { $o['AlphaMissense'] = $am[$v].am_pathogenicity; $o['AlphaMissense class'] = $amClass[$am[$v].am_class] }
  if ($core.ContainsKey($v)) { foreach ($c in $core[$v].Keys) { if ($core[$v][$c] -ne $null) { $o[$c] = ([double]$core[$v][$c]).ToString('0.###', $inv) } } }
  if ($all.ContainsKey($v)) { foreach ($c in $allCols) { $o["dbNSFP $c"] = $all[$v].$c }; $o['dbNSFP DNA change (hg19)'] = $all[$v].'DNA change (hg19)' }
  if ($civ.ContainsKey($v)) { $o['CIViC evidence'] = $civ[$v] }
  if ($cv.ContainsKey($v)) {
    $x = $cv[$v]
    $o['ClinVar'] = Join ($x | ForEach-Object { if ($_.cls) { $_.cls } else { 'no germline classification' } })
    $o['Review status'] = Join ($x | ForEach-Object { $_.review }); $o['Condition'] = Join ($x | ForEach-Object { $_.traits })
    $o['Last evaluated'] = Join ($x | ForEach-Object { if ($_.evaluated -and $_.evaluated -notlike '1/01/01*') { ($_.evaluated -split ' ')[0] } })
    $o['Somatic clinical impact'] = Join ($x | Where-Object { $_.somatic } | ForEach-Object { "$($_.somatic) ($($_.somaticTr))" })
    $o["ClinVar DNA change ($nm)"] = Join ($x | ForEach-Object { $_.cdna }); $o['ClinVar variation ID'] = Join ($x | ForEach-Object { $_.accession })
  }
  if ($gn.ContainsKey($v)) { $o['gnomAD allele count'] = $gn[$v].ac; $o['gnomAD homozygotes'] = $gn[$v].hom; if ($gn[$v].an) { $o['gnomAD AF'] = '{0:E2}' -f ($gn[$v].ac / $gn[$v].an) } }
  $af = Num $o['gnomAD AF']
  $o['gnomAD'] = if (($af -ne $null -and $af -ge 1e-4) -or [int]("0" + $o['gnomAD homozygotes']) -ge 1) { '1' } else { '2' }
  if ($cb.ContainsKey($v)) { $o['cBioPortal patients'] = $cb[$v].pts; $o['cBioPortal studies'] = $cb[$v].studies; $o['cBioPortal top cancer types'] = $cb[$v].top }
  if ($cs.ContainsKey($v)) { $o['COSMIC samples'] = $cs[$v][0]; $o['COSMIC top primary sites'] = $cs[$v][1]; $o['COSMIC mutation ID'] = $cs[$v][2] }
  if ($ok.ContainsKey($v)) { $o['OncoKB oncogenic'] = $ok[$v].Oncogenic; $o['OncoKB mutation effect'] = $ok[$v].'Mutation effect' }
  if ($lv.ContainsKey($v)) { $o['LOVD entries'] = $lv[$v][0]; $o['LOVD reported effect'] = $lv[$v][1] }
  if ($decipher.ContainsKey($v)) { $o['DECIPHER'] = $decipher[$v] }
  $o['Seen in'] = SeenIn $v
  [pscustomobject]$o
}
New-Item -ItemType Directory -Force $outDir | Out-Null
$lc = $gene.ToLower()
$out | Export-Csv -NoTypeInformation -Encoding UTF8 "$outDir\${lc}_variants_full_local.csv"
$public = @($cols | Where-Object { $_ -notmatch '^(COSMIC|OncoKB)' })
# Public files: drop rows known only from COSMIC/OncoKB (licensed) and remove those names from "Seen in"
$pubRows = foreach ($r in $out) {
  if ($r.Variant -like 'SECTION:*' -or $priority -contains $r.Variant) { $r; continue }
  $s = @($r.'Seen in' -split ', ' | Where-Object { $_ -and $_ -notin 'COSMIC', 'OncoKB' })
  if (-not $s.Count) { continue }
  $c = $r.PSObject.Copy(); $c.'Seen in' = $s -join ', '; $c
}
$pubRows | Select-Object @($public | Where-Object { $predCols -notcontains $_ -and $extCols -notcontains $_ }) | Export-Csv -NoTypeInformation -Encoding UTF8 "$outDir\${lc}_variants_inf.csv"
$pubRows | Select-Object @($public | Where-Object { $extCols -notcontains $_ }) | Export-Csv -NoTypeInformation -Encoding UTF8 "$outDir\${lc}_variants_inf_predict.csv"
$pubRows | Select-Object $public | Export-Csv -NoTypeInformation -Encoding UTF8 "$outDir\${lc}_variants_inf_predict_ext.csv"
$n = @($out | Where-Object { $_.Variant -notlike 'SECTION:*' })
"$gene rows: local $(@($out).Count), public $(@($pubRows).Count) ($($n.Count) variants: $($priority.Count) priority, $(@($cv.Keys).Count) ClinVar protein changes, $($other.Count) other observed)"
"filled: ClinVar $(@($n | ? ClinVar).Count), gnomAD $(@($n | ? 'gnomAD allele count').Count), cBioPortal $(@($n | ? 'cBioPortal patients').Count), COSMIC $(@($n | ? 'COSMIC samples').Count), OncoKB $(@($n | ? 'OncoKB oncogenic').Count), CIViC $(@($n | ? 'CIViC evidence').Count), LOVD $(@($n | ? 'LOVD entries').Count), AlphaMissense $(@($n | ? AlphaMissense).Count), dbNSFP $(@($n | ? REVEL).Count), dbNSFP-all $(@($n | ? 'dbNSFP DNA change (hg19)').Count), DMS $(if ($dmsCols) { @($n | ? $dmsCols[0]).Count } else { 0 }); gnomAD=1: $(@($n | ? gnomAD -eq '1').Count)"
"columns: inf $(@($public | Where-Object { $predCols -notcontains $_ -and $extCols -notcontains $_ }).Count), predict $(@($public | Where-Object { $extCols -notcontains $_ }).Count), ext $($public.Count), local $($cols.Count)"
if ($warn) { "WARNING reference residue mismatch: $($warn -join '; ')" }
