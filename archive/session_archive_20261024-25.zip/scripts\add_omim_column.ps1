param($gene, $files)
# Add an "OMIM allelic variant" column (number + phenotype) right after "Seen in" / at the end, to the given CSVs.
$om = @{}
foreach ($r in (Import-Csv "$PWD\sources\omim\omim_allelic_variants.csv" | Where-Object { $_.Gene -eq $gene -and $_.Variant })) {
  $om[$r.Variant] = "$($r.AV): $($r.Phenotype)"
}
"OMIM entries with a protein change for ${gene}: $($om.Count)"
foreach ($f in $files) {
  if (-not (Test-Path $f)) { Write-Warning "missing $f"; continue }
  $rows = @(Import-Csv $f -Encoding UTF8)
  $cols = @($rows[0].PSObject.Properties.Name) | Where-Object { $_ -ne 'OMIM allelic variant' }
  $hit = 0
  foreach ($r in $rows) {
    $m = [regex]::Match($r.Variant, '^(?:Known GOF: )?([A-Z*]\d+\S*)$')
    $v = if ($m.Success -and $om.ContainsKey($m.Groups[1].Value)) { $hit++; $om[$m.Groups[1].Value] } else { '' }
    $r | Add-Member -NotePropertyName 'OMIM allelic variant' -NotePropertyValue $v -Force
  }
  $i = [array]::IndexOf($cols, 'Seen in')
  $new = if ($i -lt 0 -or $i -eq $cols.Count - 1) { @($cols) + 'OMIM allelic variant' }
         else { @($cols[0..$i]) + 'OMIM allelic variant' + @($cols[($i + 1)..($cols.Count - 1)]) }   # PS ranges run backwards when start > end
  $rows | Select-Object $new | Export-Csv -NoTypeInformation -Encoding UTF8 $f
  "  $(Split-Path $f -Leaf): $hit rows annotated"
}
