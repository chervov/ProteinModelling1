import subprocess, sys, os, textwrap

# Detached install, following the project's own recipe (colab/tyk2_ddg.py) and the RUNBOOK rule
# that a long job must not run inside the kernel (probing a busy kernel kills the running cell).
os.makedirs("/tmp/pyro", exist_ok=True)
script = textwrap.dedent(f"""
    set -e
    {sys.executable} -m pip install -q pyrosetta-installer
    {sys.executable} -c 'import pyrosetta_installer; pyrosetta_installer.install_pyrosetta()'
    {sys.executable} -c 'import pyrosetta; print("PYROSETTA_OK", pyrosetta.__file__)'
    echo INSTALL_DONE
""")
open("/tmp/pyro/install.sh", "w").write(script)
p = subprocess.Popen(
    ["bash", "/tmp/pyro/install.sh"],
    stdout=open("/tmp/pyro/install.log", "w"), stderr=subprocess.STDOUT,
    start_new_session=True,
)
print("launched pid", p.pid, "-> /tmp/pyro/install.log")
