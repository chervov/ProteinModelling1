param($gene, $ddgFile, $files)
# Add ddG columns (closed / open / difference) from the repo's own ddG runs, placed after the predictor block.
$inv = [Globalization.CultureInfo]::InvariantCulture
$j = Get-Content -Raw $ddgFile | ConvertFrom-Json
$lookup = @{}   # not $D: PowerShell variable names are case-insensitive, so $d in the loop below would clobber it
foreach ($r in @($j)) { $lookup["$($r.wt)$($r.pos)$($r.alt)"] = $r }
"$gene ddG substitutions loaded: $($lookup.Count)"
$new = 'ddG closed', 'ddG open', 'ddG open-closed'
foreach ($f in $files) {
  if (-not (Test-Path $f)) { Write-Warning "missing $f"; continue }
  $rows = @(Import-Csv $f -Encoding UTF8)
  $cols = @($rows[0].PSObject.Properties.Name) | Where-Object { $new -notcontains $_ }
  $hit = 0
  foreach ($r in $rows) {
    $m = [regex]::Match($r.Variant, '^(?:Known GOF: )?([A-Z]\d+[A-Z])$')
    $rec = if ($m.Success) { $lookup[$m.Groups[1].Value] } else { $null }
    if ($rec) { $hit++ }
    $r | Add-Member -NotePropertyName 'ddG closed' -NotePropertyValue $(if ($rec) { ([double]$rec.ddg_closed).ToString('0.##', $inv) } else { '' }) -Force
    $r | Add-Member -NotePropertyName 'ddG open' -NotePropertyValue $(if ($rec) { ([double]$rec.ddg_open).ToString('0.##', $inv) } else { '' }) -Force
    $r | Add-Member -NotePropertyName 'ddG open-closed' -NotePropertyValue $(if ($rec) { ([double]$rec.delta).ToString('0.##', $inv) } else { '' }) -Force
  }
  $i = [array]::IndexOf($cols, 'ESM1b')
  $order = if ($i -lt 0 -or $i -eq $cols.Count - 1) { @($cols) + $new } else { @($cols[0..$i]) + $new + @($cols[($i + 1)..($cols.Count - 1)]) }
  $rows | Select-Object $order | Export-Csv -NoTypeInformation -Encoding UTF8 $f
  "  $(Split-Path $f -Leaf): $hit rows with ddG"
}
