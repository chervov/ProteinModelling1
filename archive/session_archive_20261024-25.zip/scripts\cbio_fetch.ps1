param($out, $entrez = 3716)
# Fetch all mutations of one gene (Entrez ID; JAK1 = 3716) from every public cBioPortal mutation profile.
$api = 'https://www.cbioportal.org/api'
$studies = Invoke-RestMethod "$api/studies?projection=SUMMARY&pageSize=100000"
$cancer = @{}; foreach ($s in $studies) { $cancer[$s.studyId] = $s.cancerTypeId }
$profiles = @(Invoke-RestMethod "$api/molecular-profiles?projection=SUMMARY&pageSize=100000" | Where-Object { $_.molecularAlterationType -eq 'MUTATION_EXTENDED' })
$rows = New-Object System.Collections.Generic.List[object]
for ($i = 0; $i -lt $profiles.Count; $i += 40) {
  $ids = @($profiles[$i..([Math]::Min($i + 39, $profiles.Count - 1))] | ForEach-Object { $_.molecularProfileId })
  $body = @{ entrezGeneIds = @([int]$entrez); molecularProfileIds = $ids } | ConvertTo-Json -Compress
  try {
    $m = Invoke-RestMethod -Method Post -Uri "$api/mutations/fetch?projection=SUMMARY&pageSize=10000000" -ContentType 'application/json' -Body $body
  } catch { Write-Warning "batch $i failed: $($_.Exception.Message)"; continue }
  foreach ($x in @($m)) {
    $rows.Add([pscustomobject]@{
      studyId = $x.studyId; cancerType = $cancer[$x.studyId]; sampleId = $x.sampleId; patientId = $x.patientId
      proteinChange = $x.proteinChange; mutationType = $x.mutationType; mutationStatus = $x.mutationStatus
      chr = $x.chr; start = $x.startPosition; ref = $x.referenceAllele; alt = $x.variantAllele
    })
  }
}
$rows | Export-Csv -NoTypeInformation -Encoding UTF8 $out
"profiles: $($profiles.Count); mutation calls: $($rows.Count); studies with hits: $(@($rows | Select-Object -Unique studyId).Count)"
