param($out, $gene = 'JAK1')
# Fetch a gene's variants (gnomAD v4) and gene constraint from the gnomAD GraphQL API.
$q = @'
{
  gene(gene_symbol: "GENE_SYMBOL", reference_genome: GRCh38) {
    gene_id
    canonical_transcript_id
    gnomad_constraint { pli oe_lof oe_lof_lower oe_lof_upper oe_mis mis_z lof_z exp_mis obs_mis exp_lof obs_lof }
    variants(dataset: gnomad_r4) {
      variant_id
      transcript_id
      hgvsc
      hgvsp
      consequence
      flags
      exome { ac an af homozygote_count }
      genome { ac an af homozygote_count }
    }
  }
}
'@
$body = @{ query = $q.Replace('GENE_SYMBOL', $gene) } | ConvertTo-Json -Compress
$r = Invoke-RestMethod -Method Post -Uri 'https://gnomad.broadinstitute.org/api' -ContentType 'application/json' -Body $body
if ($r.errors) { $r.errors | ConvertTo-Json -Depth 5; return }
$r.data.gene | ConvertTo-Json -Depth 6 | Out-File -Encoding utf8 $out
"variants: $(@($r.data.gene.variants).Count); canonical: $($r.data.gene.canonical_transcript_id)"
$r.data.gene.gnomad_constraint | Format-List | Out-String
