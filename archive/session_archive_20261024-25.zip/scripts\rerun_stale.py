import marimo._code_mode as cm

async def main():
    async with cm.get_context() as ctx:
        for n in ("functions", "run", "table", "chart", "md_kellogg"):
            ctx.run_cell(n)
    print("re-ran stale cells")

await main()
