import subprocess, sys, os, base64, pathlib

code = pathlib.Path("/tmp/pyro/experiment.py")
code.parent.mkdir(parents=True, exist_ok=True)
code.write_bytes(base64.b64decode(SRC_B64))
p = subprocess.Popen([sys.executable, "-u", str(code)],
                     stdout=open("/tmp/pyro/exp.log", "w"), stderr=subprocess.STDOUT,
                     start_new_session=True)
print("launched experiment pid", p.pid, "ppid-detached ->", "/tmp/pyro/exp.log")
