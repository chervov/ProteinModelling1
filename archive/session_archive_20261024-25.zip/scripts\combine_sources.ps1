param($dir, $table, $lookup, $out)
# Merge JAK1 protein-level variants from gnomAD, cBioPortal, OncoKB, LOVD, DECIPHER and ClinVar into one table.
$three = @{Ala='A';Arg='R';Asn='N';Asp='D';Cys='C';Gln='Q';Glu='E';Gly='G';His='H';Ile='I';Leu='L';Lys='K';Met='M';Phe='F';Pro='P';Ser='S';Thr='T';Trp='W';Tyr='Y';Val='V';Ter='*'}
function ToOne($p) { $p = $p -replace '^p\.\(?', '' -replace '\)$', ''; ([regex]::Replace($p, 'Ala|Arg|Asn|Asp|Cys|Gln|Glu|Gly|His|Ile|Leu|Lys|Met|Phe|Pro|Ser|Thr|Trp|Tyr|Val|Ter', { param($m) $three[$m.Value] })) -replace '^(\*\d+[A-Z])ext\*\d+$', '$1' }
function Pos($v) { $m = [regex]::Match($v, '\d+'); if ($m.Success) { [int]$m.Value } else { 99999 } }
$all = @{}
function Row($v) { if (-not $all.ContainsKey($v)) { $all[$v] = [ordered]@{ Variant = $v } }; $all[$v] }

# gnomAD v4 (canonical transcript only, protein-changing)
$g = Get-Content -Raw "$dir\gnomad_jak1.json" | ConvertFrom-Json
foreach ($x in $g.variants) {
  if ($x.transcript_id -ne $g.canonical_transcript_id -or -not $x.hgvsp) { continue }
  $p = ToOne $x.hgvsp; if ($p -match '^[A-Z*]\d+[A-Z*]?$' -and $p[0] -eq $p[-1] -and $p -notmatch 'ext') { continue }   # synonymous
  $ac = [int]$x.exome.ac + [int]$x.genome.ac; $an = [int]$x.exome.an + [int]$x.genome.an
  $r = Row $p
  $r['gnomAD allele count'] = [int]$r['gnomAD allele count'] + $ac
  $r['gnomAD AN'] = [Math]::Max([int]$r['gnomAD AN'], $an)
  $r['gnomAD homozygotes'] = [int]$r['gnomAD homozygotes'] + [int]$x.exome.homozygote_count + [int]$x.genome.homozygote_count
  $r['gnomAD consequence'] = $x.consequence
}
foreach ($r in $all.Values) { if ($r['gnomAD AN']) { $r['gnomAD AF'] = '{0:E2}' -f ($r['gnomAD allele count'] / $r['gnomAD AN']) } }

# cBioPortal (deduplicate the same patient across overlapping studies)
$c = Import-Csv "$dir\cbioportal_jak1_raw.csv" | Where-Object { $_.proteinChange -and $_.proteinChange -notmatch '^(X|\*)?\d+_splice$' -and $_.mutationType -notmatch 'Splice' }
foreach ($grp in ($c | Group-Object proteinChange)) {
  $p = $grp.Name -replace '^p\.', ''; $r = Row $p
  $pts = @($grp.Group | Select-Object -Unique patientId)
  $r['cBioPortal patients'] = $pts.Count
  $r['cBioPortal studies'] = @($grp.Group | Select-Object -Unique studyId).Count
  $r['cBioPortal top cancer types'] = (($grp.Group | Sort-Object patientId -Unique | Group-Object cancerType | Sort-Object Count -Descending | Select-Object -First 3) | ForEach-Object { "$($_.Name) ($($_.Count))" }) -join '; '
  $r['cBioPortal mutation type'] = (@($grp.Group.mutationType | Select-Object -Unique)) -join '/'
}

# OncoKB curated alterations
foreach ($o in Import-Csv "$dir\oncokb_jak1.csv") {
  if ($o.Variant -eq 'Truncating Mutations') { continue }
  $r = Row $o.Variant; $r['OncoKB oncogenic'] = $o.Oncogenic; $r['OncoKB mutation effect'] = $o.'Mutation effect'
}
$trunc = Import-Csv "$dir\oncokb_jak1.csv" | Where-Object { $_.Variant -eq 'Truncating Mutations' }

# LOVD shared
$l = Get-Content -Raw "$dir\lovd_jak1.json" | ConvertFrom-Json
foreach ($grp in ($l | ForEach-Object { $t = ($_.variants_on_transcripts.PSObject.Properties | Select-Object -First 1).Value; [pscustomobject]@{ p = (ToOne $t.protein); eff = ($_.effect_reported -join '/') } } | Where-Object { $_.p -and $_.p -ne '=' -and $_.p -notmatch '=$' } | Group-Object p)) {
  $r = Row $grp.Name; $r['LOVD entries'] = $grp.Count; $r['LOVD reported effect'] = (@($grp.Group.eff | Select-Object -Unique)) -join '; '
}

# DECIPHER open-access sequence variant
(Row 'M842V')['DECIPHER'] = 'de novo, heterozygous, not classified (1 patient)'

# ClinVar and membership in your table
$t = Import-Csv $table -Encoding UTF8
$cut = [array]::FindIndex([object[]]$t, [Predicate[object]] { param($x) $x.Variant -like 'SECTION: CLINVAR*' })
for ($i = 0; $i -lt $t.Count; $i++) {
  $m = [regex]::Match($t[$i].Variant, '^(?:Known GOF: )?([A-Z*]\d+(?:[A-Z]|\*|fs|del|_\w+)\S*)$')
  if (-not $m.Success) { continue }
  $v = $m.Groups[1].Value
  if ($i -lt $cut) { (Row $v)['In your table'] = 'yes' }
  if ($t[$i].'ClinVar variation ID') {
    $r = Row $v
    $r['ClinVar'] = if ($t[$i].ClinVar) { $t[$i].ClinVar } else { 'in ClinVar, no germline classification' }
    $r['ClinVar review'] = $t[$i].'Review status'
  }
}

# Dataset EV1 cluster for every single substitution
$ev1 = @{}; Import-Csv $lookup | ForEach-Object { $ev1[$_.variant_id] = $_.cluster }
foreach ($r in $all.Values) { if ($ev1.ContainsKey($r.Variant)) { $r['EV1 cluster'] = $ev1[$r.Variant] } }

# OncoKB truncating class applies to nonsense/frameshift variants
foreach ($r in $all.Values) { if (-not $r['OncoKB oncogenic'] -and $r.Variant -match '^[A-Z]\d+(\*|[A-Z]?fs)') { $r['OncoKB oncogenic'] = "$($trunc.Oncogenic) (truncating class)"; $r['OncoKB mutation effect'] = $trunc.'Mutation effect' } }

$cols = 'Variant','In your table','EV1 cluster','ClinVar','ClinVar review','gnomAD allele count','gnomAD AF','gnomAD homozygotes','gnomAD consequence','cBioPortal patients','cBioPortal studies','cBioPortal top cancer types','cBioPortal mutation type','OncoKB oncogenic','OncoKB mutation effect','LOVD entries','LOVD reported effect','DECIPHER'
$rows = $all.Values | Sort-Object { Pos $_.Variant }, { $_.Variant } | ForEach-Object { $h = $_; $o = [ordered]@{}; foreach ($k in $cols) { $o[$k] = $h[$k] }; [pscustomobject]$o }
$rows | Export-Csv -NoTypeInformation -Encoding UTF8 $out
"total protein variants: $(@($rows).Count)"
foreach ($k in 'In your table','ClinVar','gnomAD allele count','cBioPortal patients','OncoKB oncogenic','LOVD entries','DECIPHER') { "{0}: {1}" -f $k, @($rows | Where-Object { $_.$k }).Count }
