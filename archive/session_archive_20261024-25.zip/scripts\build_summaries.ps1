# Gene-specific notes for the summaries (gene-level facts gathered from OncoKB, IntOGen, DECIPHER, MaveDB pages on 24-25 Oct 2026).
$notes = @{
  JAK2 = @{ uniprot = 'O60674'; nm = 'NM_004972'; priorityCount = 4
    intro = 'JAK2 is the main kinase downstream of EPO, TPO and GM-CSF receptors. Germline and somatic gain-of-function variants (V617F above all) drive myeloproliferative neoplasms; OMIM links JAK2 to thrombocythemia 3, familial erythrocytosis, polycythemia vera (somatic), myelofibrosis, AML and Budd-Chiari syndrome.'
    oncokbLevel = 'highest therapeutic level 4 (JAK2 fusions / PCM1-JAK2: ruxolitinib, fedratinib); 14 alterations annotated as JAK-inhibitor resistance'
    decipher = 'No open-access sequence variants (256 copy-number variants); GenCC strong/moderate, autosomal dominant; pGOF 0.63'
    intogen = 'Driver in 5 cancer types (breast, non-small-cell lung, AML, ALL, bladder)'
    mavedb = 'No JAK2 deep mutational scan'
    gnomadCaveat = '**Caution for JAK2:** somatic clonal haematopoiesis (e.g. V617F) can make tumour-type variants appear in gnomAD blood-derived samples, so gnomAD frequency is less reliable for this gene.'
    findings = @('**Gain-of-function is the key mechanism.** OncoKB annotates 26 oncogenic alterations (V617F, exon 12 changes, R683 substitutions, fusions, amplification).', '**JAK2 tolerates loss of function in the population** (pLI 0.00, LOEUF 0.74; missense Z -0.7), consistent with disease by gain rather than loss of function.') }
  JAK3 = @{ uniprot = 'P52333'; nm = 'NM_000215'; priorityCount = 1
    intro = 'JAK3 pairs with the common gamma chain (IL-2, IL-4, IL-7, IL-9, IL-15, IL-21 receptors). Biallelic loss of function causes T-B+NK- severe combined immunodeficiency (ClinGen: definitive, autosomal recessive; a ClinGen SCID expert panel specification exists). Somatic gain-of-function variants occur in T-ALL and NK/T-cell lymphoma.'
    oncokbLevel = 'diagnostic level only (early T-cell precursor ALL); no therapeutic level'
    decipher = '1 open-access patient: Q39Sfs*108, homozygous, classified pathogenic (SCID); GenCC definitive, autosomal recessive'
    decipherRow = $true
    intogen = 'Driver in 1 cancer type (acute lymphoblastic leukaemia)'
    mavedb = 'No JAK3 deep mutational scan'
    gnomadCaveat = 'For recessive SCID, heterozygous carriers are expected in gnomAD, so frequency alone argues for benign only at higher frequencies (homozygotes are the stronger signal).'
    findings = @('**Two disease mechanisms.** Germline biallelic loss of function (SCID; many pathogenic ClinVar entries) and somatic gain of function in leukaemia/lymphoma (OncoKB: M511I, A572T, A573V, R657Q/W, V674A, V678M, L857Q).', '**ProteinGym clinical set** has 28 JAK3 variants (14 pathogenic) - the best-labelled of the four JAK genes.') }
  TYK2 = @{ uniprot = 'P29597'; nm = 'NM_003331'; priorityCount = 2
    intro = 'TYK2 transduces type I interferon, IL-12 and IL-23 signalling. Biallelic loss of function causes immunodeficiency 35 (autosomal recessive). The JH2 pseudokinase is the target of the allosteric inhibitor deucravacitinib.'
    oncokbLevel = 'diagnostic level only (TYK2 fusions in BCR-ABL1-like B-ALL); no therapeutic level'
    decipher = 'No open-access sequence variants (20 copy-number variants); GenCC strong, autosomal recessive'
    intogen = 'Not detected as a cancer driver'
    mavedb = '**Deep mutational scan available** (Deep mutational scanning reveals pharmacologically relevant insights into TYK2 signaling and disease, bioRxiv 2025, doi:10.1101/2025.10.11.681520): IFN-alpha signalling (~23,700 variants; also with allosteric inhibitors BMS-986202 and NDI-034858) and VAMP-seq abundance'
    gnomadCaveat = 'For a recessive disorder, heterozygous carriers are expected in gnomAD; homozygotes are the stronger benign signal.'
    findings = @('**Experimental data exist for almost every substitution.** The DMS signalling and abundance columns give measured effects (negative = loss of function), which outrank the computational predictors.', '**TYK2 is not a cancer driver** (IntOGen) and has few curated cancer variants; the main clinical relevance is recessive immunodeficiency and common partial loss-of-function alleles in autoimmunity.') }
}
foreach ($gene in 'JAK2', 'JAK3', 'TYK2') { $n = $notes[$gene]; & "$PSScriptRoot\gen_summary.ps1" -gene $gene -uniprot $n.uniprot -nm $n.nm -notes $n }
