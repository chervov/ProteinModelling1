import marimo._code_mode as cm
import subprocess, sys

ctx = cm.get_context()
help(ctx.packages)

# What does PyRosetta publish for this interpreter? Check the installer's own index.
r = subprocess.run(
    [sys.executable, "-m", "pip", "install", "--dry-run", "--no-deps", "pyrosetta-installer"],
    capture_output=True, text=True, timeout=300,
)
print("\npip dry-run rc:", r.returncode)
print((r.stdout or "")[-800:])
print((r.stderr or "")[-400:])
