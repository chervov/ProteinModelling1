param($gene = 'JAK2', $mim = '147796', $out)
# OMIM allelic variants are cross-referenced in ClinVar records; pull them from the ClinVar VCV XML.
$base = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/'
$ids = @((Invoke-RestMethod "$($base)esearch.fcgi?db=clinvar&term=$gene%5Bgene%5D&retmax=5000&retmode=json").esearchresult.idlist)
"ClinVar records for ${gene}: $($ids.Count)"
$rows = New-Object System.Collections.Generic.List[object]
for ($i = 0; $i -lt $ids.Count; $i += 100) {
  $chunk = $ids[$i..([Math]::Min($i + 99, $ids.Count - 1))] -join ','
  $xml = (Invoke-WebRequest "$($base)efetch.fcgi?db=clinvar&rettype=vcv&is_variationid&id=$chunk&retmode=xml" -UseBasicParsing).Content
  foreach ($m in [regex]::Matches($xml, '(?s)<VariationArchive[^>]*VariationID="(\d+)"[^>]*VariationName="([^"]*)".*?(?=<VariationArchive|\z)')) {
    $body = $m.Value
    $x = [regex]::Match($body, "<XRef[^>]*DB=`"OMIM`"[^>]*ID=`"$mim\.(\d+)`"[^>]*Type=`"Allelic variant`"")
    if (-not $x.Success) { continue }
    $cls = [regex]::Match($body, '<Description>([^<]*)</Description>')
    $rows.Add([pscustomobject]@{
      'OMIM allelic variant' = "$mim.$($x.Groups[1].Value)"
      'ClinVar ID' = $m.Groups[1].Value
      Variant = $m.Groups[2].Value
      Protein = ([regex]::Match($m.Groups[2].Value, '\(p\.([^)]+)\)')).Groups[1].Value
      ClinVar = if ($cls.Success) { $cls.Groups[1].Value } else { '' }
      Conditions = (@([regex]::Matches($body, '<ElementValue Type="Preferred">([^<]+)</ElementValue>') | ForEach-Object { $_.Groups[1].Value } | Select-Object -Unique) -join '; ')
    })
  }
  Start-Sleep -Milliseconds 400
}
$rows = $rows | Sort-Object { [int](($_.'OMIM allelic variant' -split '\.')[1]) } -Unique
$rows | Export-Csv -NoTypeInformation -Encoding UTF8 $out
"OMIM allelic variants found: $($rows.Count)"
$rows | Format-Table -AutoSize -Wrap | Out-String -Width 220
