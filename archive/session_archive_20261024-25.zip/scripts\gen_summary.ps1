param($gene, $uniprot, $nm, $notes)
# Write <gene>_sources_summary.md from the downloaded source files and the built table.
$d = Join-Path $PWD "sources\$gene"; $lc = $gene.ToLower(); $out = "$PWD\upload\$gene"
$t = Import-Csv "$out\${lc}_variants_full_local.csv"
$v = @($t | Where-Object { $_.Variant -notlike 'SECTION:*' })
$cvRecs = Get-Content -Raw -Encoding UTF8 "$d\clinvar.json" | ConvertFrom-Json
$cvRows = @($v | Where-Object ClinVar)
$plpRows = @($cvRows | Where-Object { $_.ClinVar -match '(^|\| )(Pathogenic|Likely pathogenic|Pathogenic/Likely pathogenic)( \||$)' })
$plpMis = @($plpRows | Where-Object { $_.Variant -match '^[A-Z]\d+[A-Z]$' } | ForEach-Object { $_.Variant })
$plp = if ($plpRows) { "$($plpRows.Count) ($($plpRows.Count - $plpMis.Count) truncating or indel; missense: $(if ($plpMis) { $plpMis -join ', ' } else { 'none' }))" } else { $null }
$vus = @($cvRows | Where-Object { $_.ClinVar -eq 'Uncertain significance' }).Count
$g = Get-Content -Raw "$d\gnomad.json" | ConvertFrom-Json; $gc = $g.gnomad_constraint
$gProt = @($g.variants | Where-Object { $_.transcript_id -eq $g.canonical_transcript_id -and $_.hgvsp -and $_.consequence -notmatch 'synonymous' }).Count
$cb = Import-Csv "$d\cbioportal_raw.csv"
$cbPairs = @($cb | Sort-Object patientId, proteinChange -Unique).Count
$cbProt = @($cb | Select-Object -Unique proteinChange).Count
$cbStudies = @($cb | Select-Object -Unique studyId).Count
$topMis = ($v | Where-Object { $_.'cBioPortal patients' } | Sort-Object { [int]$_.'cBioPortal patients' } -Descending | Select-Object -First 6 | ForEach-Object { "$($_.Variant) ($($_.'cBioPortal patients'))" }) -join ', '
$ok = Import-Csv "$d\oncokb.csv"; $okGof = @($ok | Where-Object { $_.'Mutation effect' -match 'Gain' }).Count
$civ = if (Test-Path "$d\civic.csv") { Import-Csv "$d\civic.csv" } else { @() }
$lovd = Get-Content -Raw "$d\lovd.json" | ConvertFrom-Json
$am = @(Import-Csv "$d\predictors\alphamissense.csv").Count
$dbn = @(Import-Csv "$d\predictors\dbnsfp_core.csv" | Select-Object -Unique Variant).Count
$pg = if (Test-Path "$d\proteingym_clinical.csv") { $p = Import-Csv "$d\proteingym_clinical.csv"; "Clinical set: $($p.Count) variants ($(@($p | ? 'ProteinGym clinical label' -eq 'Pathogenic').Count) pathogenic, $(@($p | ? 'ProteinGym clinical label' -eq 'Benign').Count) benign); no deep mutational scan" } else { 'Not in the clinical set; no deep mutational scan' }
$common = ($v | Where-Object { $_.gnomAD -eq '1' } | Sort-Object { [double]("0" + $_.'gnomAD AF') } -Descending | Select-Object -First 8 | ForEach-Object { "$($_.Variant) ($($_.'gnomAD AF'))" }) -join ', '
$cosN = @($v | Where-Object 'COSMIC samples').Count
$cosTxt = 'Not retrieved'
if (Test-Path "$d\cosmic_mutantcensus.tsv") {
  $cm = @(Import-Csv "$d\cosmic_mutantcensus.tsv" -Delimiter "`t" | Where-Object { $_.TRANSCRIPT_ACCESSION -like "$($g.canonical_transcript_id)*" })
  $cmProt = @($cm | Where-Object { $_.MUTATION_AA -and $_.MUTATION_AA -ne 'p.?' -and $_.MUTATION_AA -notmatch '=$' } | Select-Object -Unique MUTATION_AA).Count
  $cmTop = (@($cm | Where-Object { $_.MUTATION_AA -match '^p\.[A-Z]\d+[A-Z]$' } | Sort-Object COSMIC_SAMPLE_ID, MUTATION_AA -Unique | Group-Object MUTATION_AA | Sort-Object Count -Descending | Select-Object -First 3) | ForEach-Object { "$($_.Name -replace '^p\.', '') ($($_.Count))" }) -join ', '
  $cosTxt = "$($cm.Count) records from $(@($cm | Select-Object -Unique COSMIC_SAMPLE_ID).Count) tumour samples, $cmProt protein changes; top missense: $cmTop; $cosN table rows matched"
}
$hasDms = $t[0].PSObject.Properties.Name -contains 'DMS signalling (IFN-a 100U/mL)'
$prio = @($t | Select-Object -Skip 1 | Where-Object { $_.Variant -notlike 'SECTION:*' } | Select-Object -First $notes.priorityCount)
$f = { param($x) if ($x) { $x } else { '-' } }

$md = New-Object System.Text.StringBuilder
function L($s) { [void]$md.AppendLine($s) }
L "# $gene variants: external data sources"
L ""
L "Data retrieved 24-25 Oct 2026. All protein positions use the canonical $gene transcript ($nm / $($g.canonical_transcript_id), UniProt $uniprot)."
L "Tables: [``${lc}_variants_inf.csv``](${lc}_variants_inf.csv) (annotations), [``${lc}_variants_inf_predict.csv``](${lc}_variants_inf_predict.csv) (+ predictor scores), [``${lc}_variants_inf_predict_ext.csv``](${lc}_variants_inf_predict_ext.csv) (+ all dbNSFP scores)."
L ""
L "$($notes.intro)"
L ""
L "## 1. Priority variants (top of each table)"
L ""
$hdr = '| Variant | Domain |' + $(if ($hasDms) { ' DMS signalling | DMS abundance |' } else { '' }) + ' AlphaMissense | REVEL | CADD | ClinVar | gnomAD AF | cBioPortal patients |'
L $hdr
L ('|' + ('---|' * (($hdr -split '\|').Count - 2)))
foreach ($r in $prio) {
  $row = "| $($r.Variant) | $($r.Domain) |" + $(if ($hasDms) { " $(& $f $r.'DMS signalling (IFN-a 100U/mL)') | $(& $f $r.'DMS abundance (VAMP-seq)') |" } else { '' })
  $row += " $(& $f $r.AlphaMissense) ($(& $f $r.'AlphaMissense class')) | $(& $f $r.REVEL) | $(& $f $r.'CADD phred') | $(& $f $r.ClinVar) | $(& $f $r.'gnomAD AF') | $(& $f $r.'cBioPortal patients') |"
  L $row
}
L ""
L "## 2. Sources and what each gave"
L ""
L "| # | Source | What it is | What we got | In the tables |"
L "|---|---|---|---|---|"
L "| 1 | ClinVar | Clinical variant classifications | $(@($cvRecs).Count) records = $(@($cvRows).Count) protein changes; $vus of uncertain significance; pathogenic or likely pathogenic: $(if ($plp) { $plp } else { 'none' }) | 7 ClinVar columns |"
L "| 2 | gnomAD v4 | Population frequencies (~800,000 people) | $(@($g.variants).Count) variants, $gProt protein-changing; pLI $('{0:0.00}' -f $gc.pli), LOEUF $('{0:0.00}' -f $gc.oe_lof_upper), missense Z $('{0:0.0}' -f $gc.mis_z) | 3 frequency columns plus ``gnomAD`` call (1 = probably benign: $(@($v | ? gnomAD -eq '1').Count) variants); $(@($v | ? 'gnomAD allele count').Count) rows |"
L "| 3 | cBioPortal | Tumour sequencing studies | $($cb.Count) calls from $cbStudies studies, about $cbPairs patient-mutation pairs, $cbProt protein changes | 3 columns, $(@($v | ? 'cBioPortal patients').Count) rows filled |"
L "| 4 | COSMIC v104 | Catalogue of somatic mutations in cancer | $cosTxt | Not included in the public CSVs (COSMIC licence) |"
L "| 5 | OncoKB | Expert cancer annotation | $($ok.Count) curated alterations ($okGof gain-of-function); $($notes.oncokbLevel) | Not included in the public CSVs (OncoKB terms) |"
L "| 6 | CIViC | Variant-drug evidence | $($civ.Count) evidence items on $(@($civ | Select-Object -Unique Variant).Count) variants | ``CIViC evidence`` column |"
L "| 7 | LOVD (shared) | Diagnostic-lab variant database | $(@($lovd).Count) entries | 2 columns, $(@($v | ? 'LOVD entries').Count) rows filled |"
L "| 8 | DECIPHER | Patients with developmental disorders | $($notes.decipher) | $(if ($notes.decipherRow) { 'Column' } else { 'Gene-level only' }) |"
L "| 9 | AlphaMissense (AlphaFold DB) | Predicted pathogenicity, all 19 substitutions per position | $am substitutions | ``AlphaMissense``, ``AlphaMissense class`` |"
L "| 10 | dbNSFP (via myvariant.info) | Dozens of predictors per single-nucleotide change | $dbn protein changes reachable by one DNA change | 6 core scores (predict file), ~60 more (ext file) |"
L "| 11 | ProteinGym | Variant-effect benchmark | $pg | Not added |"
L "| 12 | IntOGen | Cancer driver genes | $($notes.intogen) | Gene-level only |"
L "| 13 | MaveDB | Deep mutational scan data | $($notes.mavedb) | $(if ($hasDms) { '2 DMS columns' } else { 'Not available' }) |"
L "| - | Dataset EV1 (Jeanpierre 2025) | Structural clusters | JAK1 only | ``Cluster`` left blank |"
L "| - | HGMD | Literature disease variants | Not accessed (licence required) | - |"
L ""
L "## 3. Main findings"
L ""
$i = 1
foreach ($n in $notes.findings) { L "$i. $n"; $i++ }
L "$i. **Most frequent changes in tumours (cBioPortal patients):** $topMis."; $i++
L "$i. **Common in the population (gnomAD AF >= 1E-04 or homozygotes):** $(if ($common) { $common } else { 'none' }). Such variants are unlikely to cause a fully penetrant dominant disease."
L ""
L "## 4. Columns"
L ""
L "| Group | Columns |"
L "|---|---|"
L "| Curation | Variant, Domain (UniProt: FERM, SH2-like, JH2 = pseudokinase, JH1 = kinase), Cluster (blank: EV1 covers JAK1 only), Conclusions, Brief evidence, Reference, DRUG (blank, for curation) |"
if ($hasDms) { L "| MaveDB DMS | DMS signalling (IFN-a 100U/mL): log2 fold change vs WT of IFN-alpha-induced signalling (negative = loss of function, positive = gain); DMS abundance (VAMP-seq): protein abundance vs WT (negative = less stable) |" }
L "| Predictors (predict, ext) | AlphaMissense (> 0.564 likely pathogenic, < 0.34 likely benign), REVEL (>= 0.644 damaging), CADD phred (>= 25), SIFT (<= 0.05 damaging), PolyPhen-2 HVAR (> 0.909 probably damaging), MetaRNN (> 0.5), ESM1b (< -7.5) |"
L "| dbNSFP (ext only) | ``dbNSFP <tool>.score`` / ``.pred`` for ~30 further predictors and conservation scores; ``dbNSFP DNA change (hg19)`` |"
L "| CIViC | CIViC evidence (drug or functional claim, disease, evidence level A-E, review status, EID) |"
L "| ClinVar | ClinVar, Review status, Condition, Last evaluated, Somatic clinical impact, ClinVar DNA change, ClinVar variation ID |"
L "| gnomAD v4 | gnomAD allele count, gnomAD AF, gnomAD homozygotes, gnomAD (1 = probably benign, 2 = rare/absent, not informative) |"
L "| cBioPortal | cBioPortal patients, cBioPortal studies, cBioPortal top cancer types |"
L "| LOVD / DECIPHER | LOVD entries, LOVD reported effect, DECIPHER |"
L ""
L "| Provenance | Seen in (which public sources report the variant) |"
L ""
$pub = Import-Csv "$out\${lc}_variants_inf.csv"
$pubV = @($pub | Where-Object { $_.Variant -notlike 'SECTION:*' })
L "Rows ($($pubV.Count) variants in the public files) are grouped by ``SECTION:`` header rows: priority variants, then ClinVar protein changes, then all other protein changes observed in gnomAD, cBioPortal, LOVD, CIViC or DECIPHER (both sorted by position). Variants known only from COSMIC or OncoKB are kept in the local tables but left out of the public files."
L ""
L "## 5. Methods notes"
L ""
L "- Same pipeline as [JAK1](../JAK1/jak1_sources_summary.md); scripts query NCBI E-utilities, the gnomAD GraphQL API, the cBioPortal API, CIViC GraphQL, the LOVD shared API, AlphaFold DB and myvariant.info."
L "- **gnomAD call:** 1 if AF >= 1E-04 or at least one homozygote, else 2 (ACMG/AMP BS1 practice; no ClinGen threshold for this gene). A ""2"" is not evidence of pathogenicity. $($notes.gnomadCaveat)"
L "- **Predictors** score damaging versus tolerated; they cannot separate gain-of-function from loss-of-function."
L "- **dbNSFP** covers only substitutions reachable by a single DNA change (~1/3 of all 19-per-position substitutions); AlphaMissense covers all. Where two DNA changes give the same protein change, the most damaging core score is kept (ext file: values joined with `` | ``)."
L "- **cBioPortal:** patients deduplicated by patient ID across overlapping studies; ""mixed"" is the study-level label of pan-cancer cohorts."
[IO.File]::WriteAllText("$out\${lc}_sources_summary.md", $md.ToString(), (New-Object Text.UTF8Encoding($false)))
"wrote $out\${lc}_sources_summary.md"
