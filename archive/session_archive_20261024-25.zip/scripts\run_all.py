import marimo._code_mode as cm

ORDER = ["intro", "setup", "config", "rosetta_init", "pose",
         "functions", "run", "table", "chart", "conclusion"]

async def main():
    async with cm.get_context() as ctx:
        for name in ORDER:
            ctx.run_cell(name)
    print("queued", len(ORDER), "cells")

await main()
