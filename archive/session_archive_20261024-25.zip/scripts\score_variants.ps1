param([string[]]$items)   # items like 'JAK3:Y581C'
# Markdown table of main predictor scores (and TYK2 DMS) for variants across JAK1/JAK2/JAK3/TYK2.
$inv = [Globalization.CultureInfo]::InvariantCulture
function Num($s) { $x = 0.0; if ([double]::TryParse([string]$s, [Globalization.NumberStyles]::Float, $inv, [ref]$x)) { $x } else { $null } }
function F($x, $fmt = '0.00') { if ($x -eq $null) { '-' } else { ([double]$x).ToString($fmt, $inv) } }
$src = @{
  JAK1 = @{ am = "$PWD\sources\predictors\AF-P23458-aa-substitutions.csv"; core = "$PWD\sources\predictors\dbnsfp_jak1.csv"; all = "$PWD\sources\predictors\dbnsfp_jak1_all_scores.csv" }
}
foreach ($g in 'JAK2', 'JAK3', 'TYK2') { $src[$g] = @{ am = "$PWD\sources\$g\predictors\alphamissense.csv"; core = "$PWD\sources\$g\predictors\dbnsfp_core.csv"; all = "$PWD\sources\$g\predictors\dbnsfp_all_scores.csv" } }
$cache = @{}
function Load($g) {
  if ($cache[$g]) { return $cache[$g] }
  $am = @{}; Import-Csv $src[$g].am | ForEach-Object { $am[$_.protein_variant] = $_ }
  $core = @{}; Import-Csv $src[$g].core | Group-Object Variant | ForEach-Object { $core[$_.Name] = $_.Group }
  $all = @{}; Import-Csv $src[$g].all | ForEach-Object { $all[$_.Variant] = $_ }
  $cache[$g] = @{ am = $am; core = $core; all = $all }; $cache[$g]
}
$three = @{A='Ala';R='Arg';N='Asn';D='Asp';C='Cys';Q='Gln';E='Glu';G='Gly';H='His';I='Ile';L='Leu';K='Lys';M='Met';F='Phe';P='Pro';S='Ser';T='Thr';W='Trp';Y='Tyr';V='Val'}
$dms = @{}; foreach ($r in (Import-Csv "$PWD\sources\TYK2\mavedb\urn_mavedb_00001270-a-6.csv")) { $dms[$r.hgvs_pro] = $r }
"| Gene | Variant | AlphaMissense | REVEL | CADD | SIFT | PolyPhen-2 | MetaRNN | ESM1b | EVE | TYK2 DMS signalling |"
"|---|---|---|---|---|---|---|---|---|---|---|"
foreach ($it in $items) {
  $g, $v = $it -split ':'; $d = Load $g
  $a = $d.am[$v]; $c = $d.core[$v]; $x = $d.all[$v]
  $mx = { param($f) ($c | ForEach-Object { Num $_.$f } | Where-Object { $_ -ne $null } | Measure-Object -Maximum).Maximum }
  $mn = { param($f) ($c | ForEach-Object { Num $_.$f } | Where-Object { $_ -ne $null } | Measure-Object -Minimum).Minimum }
  $amTxt = if ($a) { "$(F $a.am_pathogenicity) ($(@{LPath='LP';Amb='amb';LBen='LB'}[$a.am_class]))" } else { '-' }
  $eve = if ($x -and $x.'eve.score') { F (Num (($x.'eve.score' -split ' \| ')[0])) } else { '-' }
  $dm = '-'
  if ($g -eq 'TYK2') { $k = "p.$($three[[string]$v[0]])$($v -replace '\D', '')$($three[[string]$v[-1]])"; if ($dms[$k]) { $dm = "$(F $dms[$k].score) +- $(F $dms[$k].se)" } }
  $core = if ($c) { "$(F (& $mx 'REVEL')) | $(F (& $mx 'CADD_phred') '0.0') | $(F (& $mn 'SIFT') '0.000') | $(F (& $mx 'PolyPhen2_HVAR') '0.000') | $(F (& $mx 'MetaRNN')) | $(F (& $mn 'ESM1b') '0.0')" } else { '- | - | - | - | - | -' }
  "| $g | $v | $amTxt | $core | $eve | $dm |"
}
