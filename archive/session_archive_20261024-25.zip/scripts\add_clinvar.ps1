param($in, $clinvar, $lookup, $out)
# Annotate the variant table with ClinVar (protein level, NM_002227) and append ClinVar-only protein variants.
$utf8 = New-Object System.Text.UTF8Encoding($false)
$three = @{Ala='A';Arg='R';Asn='N';Asp='D';Cys='C';Gln='Q';Glu='E';Gly='G';His='H';Ile='I';Leu='L';Lys='K';Met='M';Phe='F';Pro='P';Ser='S';Thr='T';Trp='W';Tyr='Y';Val='V';Ter='*'}
function ToOne($p) { [regex]::Replace($p, 'Ala|Arg|Asn|Asp|Cys|Gln|Glu|Gly|His|Ile|Leu|Lys|Met|Phe|Pro|Ser|Thr|Trp|Tyr|Val|Ter', { param($m) $three[$m.Value] }) }
function Q($s) { $s = [string]$s; if ($s -match '[",\r\n]') { '"' + ($s -replace '"', '""') + '"' } else { $s } }
function Join($vals) { (@($vals) | Where-Object { $_ } | Select-Object -Unique) -join ' | ' }

# Group ClinVar records by protein change on the canonical transcript
$recs = Get-Content -Raw -Encoding UTF8 $clinvar | ConvertFrom-Json
$byP = [ordered]@{}
foreach ($r in $recs) {
  $m = [regex]::Match($r.title, '^NM_002227\.\d+\(JAK1\):(c\.\S+) \(p\.([^)]+)\)$')
  if (-not $m.Success -or $m.Groups[2].Value -match '=$') { continue }
  $p = ToOne $m.Groups[2].Value
  if (-not $byP.Contains($p)) { $byP[$p] = New-Object System.Collections.Generic.List[object] }
  $r | Add-Member -NotePropertyName cdna -NotePropertyValue $m.Groups[1].Value
  $byP[$p].Add($r)
}
function Annot($p) {
  $g = $byP[$p]
  if (-not $g) { return @('', '', '', '', '', '', '') }
  $som = @($g | Where-Object { $_.somatic } | ForEach-Object { "$($_.somatic) ($($_.somaticTr))" })
  @(
    (Join ($g | ForEach-Object { $_.cls })),
    (Join ($g | ForEach-Object { $_.review })),
    (Join ($g | ForEach-Object { $_.traits })),
    (Join ($g | ForEach-Object { if ($_.evaluated -and $_.evaluated -notlike '1/01/01*') { ($_.evaluated -split ' ')[0] } })),
    (Join $som),
    (Join ($g | ForEach-Object { $_.cdna })),
    (Join ($g | ForEach-Object { $_.accession }))
  )
}

$cluster = @{}
Import-Csv $lookup | ForEach-Object { $cluster[$_.variant_id] = $_.cluster }

$lines = [IO.File]::ReadAllLines($in, $utf8)
$rows = Import-Csv $in -Encoding UTF8
$header = 'ClinVar,Review status,Condition,Last evaluated,Somatic clinical impact,ClinVar DNA change (NM_002227),ClinVar variation ID'
$outLines = New-Object System.Collections.Generic.List[string]
$outLines.Add($lines[0] + ',' + $header)
$seen = @{}; $annotated = 0
for ($i = 0; $i -lt $rows.Count; $i++) {
  $m = [regex]::Match($rows[$i].Variant, '\b([A-Z]\d+[A-Z])\b')
  $vals = @('', '', '', '', '', '', '')
  if ($m.Success) { $seen[$m.Groups[1].Value] = $true; $vals = Annot $m.Groups[1].Value; if ($vals[6]) { $annotated++ } }
  $outLines.Add($lines[$i + 1] + ',' + (($vals | ForEach-Object { Q $_ }) -join ','))
}

$new = @($byP.Keys | Where-Object { -not $seen[$_] } | Sort-Object { [int]([regex]::Match($_, '\d+').Value) }, { $_ })
$outLines.Add('SECTION: CLINVAR - ADDITIONAL PROTEIN-LEVEL VARIANTS (NM_002227; not previously in table),,,,,,,,,,,,,')
foreach ($p in $new) {
  $cl = if ($cluster.ContainsKey($p)) { $cluster[$p] } else { '' }
  $outLines.Add((@($p, '', $cl, '', '', '', '') + (Annot $p) | ForEach-Object { Q $_ }) -join ',')
}
[IO.File]::WriteAllLines($out, $outLines, $utf8)
"Protein changes in ClinVar: $($byP.Count); existing rows annotated: $annotated; new rows added: $($new.Count); new rows with EV1 cluster: $(@($new | Where-Object { $cluster.ContainsKey($_) }).Count)"
