param([string[]]$variants, $out)
# For JAK2 variants, report the aligned residue in JAK1/JAK3/TYK2, local alignment context, the equivalent substitution's
# scores, and every variant reported at the equivalent position in each paralog.
$map = Import-Csv "$PWD\sources\alignment\jak2_position_map.csv"
$byPos = @{}; foreach ($r in $map) { $byPos[[int]$r.JAK2_pos] = $r }
$fa = @{}; $cur = $null; foreach ($l in Get-Content ($PWD.Path + '\sources\alignment\jak2_position_map.fasta')) { if ($l -like '>*') { $cur = $l.Substring(1) } else { $fa[$cur] += $l.Trim() } }
function Pos($v) { [int]([regex]::Match($v, '\d+').Value) }
# Per-gene variant tables
$tab = @{}
foreach ($g in 'JAK2', 'JAK3', 'TYK2') { $tab[$g] = Import-Csv "$PWD\upload\$g\$($g.ToLower())_variants_full_local.csv" | Where-Object { $_.Variant -notlike 'SECTION:*' } }
$tab['JAK1'] = Import-Csv "$PWD\JAK1_all_sources.csv"
$jak1Cos = @{}
foreach ($grp in (Import-Csv "$PWD\sources\cosmic\Cosmic_MutantCensus_Tsv_v104_GRCh37.tar" -Delimiter "`t" | Where-Object { $_.MUTATION_AA -match '^p\.[A-Z]\d+' } | Group-Object { $_.MUTATION_AA -replace '^p\.', '' })) { $jak1Cos[$grp.Name] = @($grp.Group | Select-Object -Unique COSMIC_SAMPLE_ID).Count }
$am = @{}
$am['JAK1'] = Import-Csv "$PWD\sources\predictors\AF-P23458-aa-substitutions.csv"
foreach ($g in 'JAK2', 'JAK3', 'TYK2') { $am[$g] = Import-Csv "$PWD\sources\$g\predictors\alphamissense.csv" }
$amIdx = @{}; foreach ($g in $am.Keys) { $h = @{}; foreach ($r in $am[$g]) { $h[$r.protein_variant] = [double]$r.am_pathogenicity }; $amIdx[$g] = $h }
$dms = @{}; foreach ($r in (Import-Csv "$PWD\sources\TYK2\mavedb\urn_mavedb_00001270-a-6.csv")) { $dms[$r.hgvs_pro] = $r }
$three = @{A='Ala';R='Arg';N='Asn';D='Asp';C='Cys';Q='Gln';E='Glu';G='Gly';H='His';I='Ile';L='Leu';K='Lys';M='Met';F='Phe';P='Pro';S='Ser';T='Thr';W='Trp';Y='Tyr';V='Val'}

$md = New-Object System.Text.StringBuilder
function L($s) { [void]$md.AppendLine($s) }
foreach ($v in $variants) {
  $p = Pos $v; $alt = $v[-1]; $r = $byPos[$p]
  L "### JAK2 $v"; L ""
  # alignment context +-6
  L '```'
  foreach ($g in 'JAK2', 'JAK1', 'JAK3', 'TYK2') {
    $line = ''
    for ($k = $p - 6; $k -le $p + 6; $k++) {
      if ($g -eq 'JAK2') { $line += $fa['JAK2'][$k - 1] } else { $j = $byPos[$k]."${g}_pos"; $line += $(if ($j) { $fa[$g][[int]$j - 1] } else { '-' }) }
    }
    $pp = if ($g -eq 'JAK2') { $p } else { $r."${g}_pos" }
    L ("{0,-5} {1}  (centre = {2})" -f $g, $line, $pp)
  }
  L '```'; L ""
  L "| Gene | Residue | Same substitution | AlphaMissense (same subst.) | Position mean AlphaMissense | Variants reported at this position |"
  L "|---|---|---|---|---|---|"
  foreach ($g in 'JAK2', 'JAK1', 'JAK3', 'TYK2') {
    $pos = if ($g -eq 'JAK2') { $p } else { [int]("0" + $r."${g}_pos") }
    if (-not $pos) { L "| $g | gap | - | - | - | - |"; continue }
    $wt = $fa[$g][$pos - 1]; $sub = "$wt$pos$alt"
    $amS = if ($wt -ne $alt -and $amIdx[$g].ContainsKey($sub)) { $amIdx[$g][$sub].ToString('0.00') } else { '-' }
    $vals = @($amIdx[$g].Keys | Where-Object { (Pos $_) -eq $pos } | ForEach-Object { $amIdx[$g][$_] })
    $mean = if ($vals.Count) { ($vals | Measure-Object -Average).Average.ToString('0.00') } else { '-' }
    $here = @($tab[$g] | Where-Object { $_.Variant -match "^[A-Z]$pos([A-Z*]|fs)" } | ForEach-Object {
      $bits = @()
      if ($_.ClinVar) { $bits += "ClinVar $($_.ClinVar)" }
      if ($_.'gnomAD allele count') { $bits += "gnomAD AC $($_.'gnomAD allele count')" }
      if ($_.'cBioPortal patients') { $bits += "cBio $($_.'cBioPortal patients')" }
      $cosN = if ($g -eq 'JAK1') { $jak1Cos[$_.Variant] } else { $_.'COSMIC samples' }
      if ($cosN) { $bits += "COSMIC $cosN" }
      if ($_.'OncoKB oncogenic') { $bits += "OncoKB $($_.'OncoKB oncogenic')/$($_.'OncoKB mutation effect')" }
      if ($_.'In your table') { $bits += 'in curated JAK1 table' }
      "**$($_.Variant)** ($($bits -join '; '))"
    })
    $extra = ''
    if ($g -eq 'TYK2') {
      $k = "p.$($three["$wt"])$pos$($three["$alt"])"
      $posD = @($dms.Values | Where-Object { $_.hgvs_pro -match "^p\.$($three["$wt"])$pos[A-Z][a-z]{2}$" } | ForEach-Object { [double]$_.score })
      $extra = " DMS signalling: same substitution $(if ($dms.ContainsKey($k)) { ([double]$dms[$k].score).ToString('0.00') + ' +- ' + ([double]$dms[$k].se).ToString('0.00') } else { '-' }); range at position $(($posD | Measure-Object -Minimum).Minimum.ToString('0.00')) to $(($posD | Measure-Object -Maximum).Maximum.ToString('0.00'))."
    }
    L "| $g | $wt$pos | $(if ($wt -eq $alt) { "already $alt" } else { $sub }) | $amS | $mean | $(if ($here) { $here -join '<br>' } else { 'none' })$extra |"
  }
  L ""
}
[IO.File]::WriteAllText($out, $md.ToString(), (New-Object Text.UTF8Encoding($false)))
Get-Content $out
