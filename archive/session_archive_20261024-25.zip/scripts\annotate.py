import marimo._code_mode as cm

FUNCTIONS = '''def weighted_terms(p):
    """Weighted score terms of a pose, as a dict (fa_rep = Lennard-Jones repulsion)."""
    scorefxn(p)
    totals = p.energies().total_energies()
    return {st.name: totals[st] * scorefxn.get_weight(st)
            for st in scorefxn.get_nonzero_weighted_scoretypes()}

def minimise_shell(p, position, radius=SHELL):
    """Protocol B: let the backbone AND side chains near the mutation move.
    This is the degree of freedom a repack-only protocol lacks, and the one Flex ddG
    says bulky substitutions need."""
    mm = MoveMap()
    centre = p.residue(position).xyz("CA")
    for i in range(1, p.total_residue() + 1):
        if p.residue(i).has("CA") and (p.residue(i).xyz("CA") - centre).norm() <= radius:
            mm.set_chi(i, True); mm.set_bb(i, True)
    MinMover(mm, scorefxn, "lbfgs_armijo_nonmonotone", 0.01, True).apply(p)
    return p

def ddg_for(position, alt):
    """ddG of one substitution under both protocols.

    Returns, for `<native><position><alt>`:
      A_repack_only  ddG from the pipeline protocol (side chains only).
      B_flexible_bb  ddG after backbone + side-chain minimisation of the shell.
      fa_rep_share   fraction of the destabilisation that is pure steric repulsion.
                     1.0 means the whole number is atoms overlapping, not chemistry.

    Sign: ddG = E(WT) - E(mutant), so NEGATIVE = destabilising (the paper's convention).
    The WT is repacked identically, so neither side is favoured.
    """
    native = pose.residue(position).name1()
    if native == alt:
        return None
    wt = pose.clone(); mutate_residue(wt, position, native, pack_radius=SHELL)
    mut = pose.clone(); mutate_residue(mut, position, alt, pack_radius=SHELL)
    a = scorefxn(wt) - scorefxn(mut)
    d_rep = weighted_terms(mut).get("fa_rep", 0.0) - weighted_terms(wt).get("fa_rep", 0.0)
    b = scorefxn(minimise_shell(wt.clone(), position)) - scorefxn(minimise_shell(mut.clone(), position))
    # a is negative when destabilising and d_rep positive, so negate to get a 0-1 share
    share = round(-d_rep / a, 2) if abs(a) > 1e-9 else None
    return {"variant": f"{native}{position}{alt}", "pos": position, "wt": native, "alt": alt,
            "A_repack_only": round(a, 1), "B_flexible_bb": round(b, 1), "fa_rep_share": share}'''

RUN = '''print(f"{'variant':8s} {'A (repack only)':>16s} {'B (flexible bb)':>16s} {'steric':>8s}")
print(f"{'':8s} {'pipeline value':>16s} {'after bb moves':>16s} {'share':>8s}")
print("-" * 52)

results = []
for _pos in TEST_POSITIONS:
    for _alt in TEST_ALTS:
        _rec = ddg_for(_pos, _alt)
        if _rec:
            results.append(_rec)
            _s = f"{_rec['fa_rep_share']:.0%}" if _rec["fa_rep_share"] is not None else "-"
            print(f"{_rec['variant']:8s} {_rec['A_repack_only']:16.1f} "
                  f"{_rec['B_flexible_bb']:16.1f} {_s:>8s}", flush=True)

print("-" * 52)
print(f"{len(results)} variants. More negative = more destabilising.")
print("A collapsing to B means the ddG was atoms overlapping, not a real energy cost.")'''

CONCLUSION = '''_extreme = ddg_table[ddg_table.A_repack_only < -500]
mo.md(f"""
## What this shows

**The extreme values are not energies.** A folded protein's entire score here is
**{total_wt:.0f} REU** for {pose.total_residue()} residues. A ddG of -3000 therefore puts the
mutant at **+{-total_wt - 3000:.0f} REU** - a positive total energy, which no folded structure
has. The clash alone "costs" more than the whole protein's folding energy.

- **{len(_extreme)} of {len(ddg_table)}** variants fall below -500 under the pipeline protocol.
  Their mean `fa_rep` share is **{_extreme.fa_rep_share.mean():.0%}**: the ddG *is* the repulsive
  term and nothing else.
- Letting the backbone move shrinks them by a median factor of
  **{_extreme.shrink_factor.median():.0f}x**.
- Every extreme position is a **glycine**. Replacing it with W or F in a fixed backbone is exactly
  the case Flex ddG says requires backbone movement; G->A at the same positions is 10-50x milder.
- The ordinary position (**775**) is untouched by the protocol choice, so this is specific to
  clash-prone sites, not a global offset.

**For reference**, real ddG values sit in single digits: Rosetta's own alanine-scan benchmark
discards experimental values above 4, and no mutation can destabilise a domain by more than its
folding free energy (~5-15 kcal/mol). Even protocol B is still 10-30x above that band.

**What survives.** The *ordering* is largely preserved, which is why the project's conclusions
hold: `conclusions_ddG_difference_feature.md` uses rank statistics throughout, and its README
already says "only the ordering is meaningful". The amplitudes should never be quoted as energies.
""")'''

MD_POSE = '''mo.md(
    """
    ## 1. Structure

    The same AlphaFold-3 closed-state model the production run used, relaxed with **FastRelax
    under coordinate constraints** so it stays near the input geometry. The relaxed pose is
    cached on disk: the first run costs ~35 min for 1187 residues, afterwards it is instant.

    Watch the **total REU**: that single number is the yardstick for judging every ddG below.
    """
)'''

MD_RUN = '''mo.md(
    """
    ## 2. Computing ddG three ways

    For each substitution we compute the pipeline's value, the same thing with a mobile
    backbone, and how much of it is pure steric overlap.

    The three extreme positions (**746, 964, 801**) are all **glycine** - chosen because they
    carry the largest ddG in the stored results. **667** and **775** are ordinary controls.
    """
)'''

MD_TABLE = '''mo.md(
    """
    ## 3. Results

    `shrink_factor` is A divided by B: how many times smaller the ddG becomes once the backbone
    is allowed to relax. A factor near 1 means the protocol made no difference; a large factor
    means the original number was a clash the protocol could not resolve.
    """
)'''


async def main():
    async with cm.get_context() as ctx:
        for name in ("functions", "run", "conclusion"):
            _ = ctx.cells[name].code          # read current version (staleness check)
        ctx.edit_cell("functions", code=FUNCTIONS)
        ctx.edit_cell("run", code=RUN)
        ctx.edit_cell("conclusion", code=CONCLUSION)
        ctx.create_cell(MD_POSE, name="md_pose", before="pose", hide_code=False)
        ctx.create_cell(MD_RUN, name="md_run", before="functions", hide_code=False)
        ctx.create_cell(MD_TABLE, name="md_table", before="table", hide_code=False)
        for n in ("md_pose", "md_run", "md_table", "functions", "run", "table", "chart", "conclusion"):
            ctx.run_cell(n)
    print("annotated and re-running")

await main()
