param($src, $out)
# Add the two diagnosis files to the pipeline/ddg README table. Pure ASCII, see note in append_section9.ps1.
$t = [IO.File]::ReadAllText($src, [Text.Encoding]::UTF8)
if ($t -match 'notebook_clash_diagnosis') { 'already documented'; return }
$anchor = '| `sample_TYK2.json`'
$i = $t.IndexOf($anchor)
if ($i -lt 0) { throw 'anchor row not found' }
$rows = @(
  '| `diagnose_clash.py` | **why the magnitudes are not energies.** Reproduces the protocol on selected variants, decomposes the score into terms, and re-runs with a mobile backbone. Output: `data/ddg/clash_diagnosis.json` |'
  '| `notebook_clash_diagnosis.py` | the same diagnosis as a **marimo notebook**: open it on a molab box and run all. Installs PyRosetta if absent, caches the relax, renders a table and chart. See `conclusions_ddG_difference_feature.md` section 9 |'
) -join "`r`n"
$t = $t.Substring(0, $i) + $rows + "`r`n" + $t.Substring($i)

# and a line in the protocol section about what the diagnosis established
$marker = '## Running it'
$j = $t.IndexOf($marker)
if ($j -ge 0) {
  $note = @(
    'The amplitudes are **not energies**: `diagnose_clash.py` measures the extreme values as ~100%'
    '`fa_rep` (steric overlap), and a mobile backbone shrinks them 10-150x. A ddG of -3000 implies a'
    'mutant scoring +311 REU, which no folded protein does. Rank the values; never quote them as kcal/mol.'
    ''
    ''
  ) -join "`r`n"
  $t = $t.Substring(0, $j) + $note + $t.Substring($j)
}
[IO.File]::WriteAllText($out, $t, (New-Object Text.UTF8Encoding($false)))
"written $([math]::Round((Get-Item $out).Length/1KB,1)) KB"
