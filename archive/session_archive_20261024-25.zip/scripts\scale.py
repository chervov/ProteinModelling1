"""Where do the 3,000 units live? Absolute scores, per-residue energies, and whether more
sampling relieves the clash. Uses the cached relaxed pose, so this is fast."""
import json, time
import pyrosetta
from pyrosetta import pose_from_pdb, get_fa_scorefxn
from pyrosetta.toolbox import mutate_residue
from pyrosetta.rosetta.core.scoring import ScoreType
from pyrosetta.rosetta.core.kinematics import MoveMap
from pyrosetta.rosetta.protocols.minimization_packing import MinMover
from pyrosetta.rosetta.protocols.relax import FastRelax

pyrosetta.init("-mute all -ex1 -ex2aro -ignore_unrecognized_res "
               "-ignore_zero_occupancy false -detect_disulf false")
SF = get_fa_scorefxn()
pose = pose_from_pdb("/tmp/ddg/TYK2_relaxed_closed.pdb")
n = pose.total_residue()
wt_total = SF(pose)
print(f"WT relaxed pose: {n} residues, total {wt_total:.1f} REU, {wt_total/n:.2f} REU/residue")

def res_energy(p, i):
    SF(p)
    return p.energies().residue_total_energy(i)

def rep_of(p, i):
    SF(p)
    return p.energies().residue_total_energies(i)[ScoreType.fa_rep] * SF.get_weight(ScoreType.fa_rep)

out = []
for pos, alt in [(746, "W"), (746, "A"), (775, "W")]:
    wt_aa = pose.residue(pos).name1()
    pw = pose.clone(); mutate_residue(pw, pos, wt_aa, pack_radius=8.0)
    rec = {"variant": f"{wt_aa}{pos}{alt}",
           "WT_total": round(SF(pw), 1), "WT_res_E": round(res_energy(pw, pos), 1),
           "WT_res_rep": round(rep_of(pw, pos), 1)}

    # protocol A: repack only
    pm = pose.clone(); mutate_residue(pm, pos, alt, pack_radius=8.0)
    rec["A_total"] = round(SF(pm), 1)
    rec["A_ddg"] = round(rec["WT_total"] - rec["A_total"], 1)
    rec["A_res_E"] = round(res_energy(pm, pos), 1)
    rec["A_res_rep"] = round(rep_of(pm, pos), 1)

    # more sampling: bigger repack shell
    pbig = pose.clone(); mutate_residue(pbig, pos, alt, pack_radius=15.0)
    rec["bigshell_ddg"] = round(rec["WT_total"] - SF(pbig), 1)

    # minimise everything (bb+chi, whole pose) after the mutation, both sides
    def minim(p):
        mm = MoveMap(); mm.set_bb(True); mm.set_chi(True)
        MinMover(mm, SF, "lbfgs_armijo_nonmonotone", 0.01, True).apply(p)
        return p
    t0 = time.time()
    rec["minall_ddg"] = round(SF(minim(pw.clone())) - SF(minim(pm.clone())), 1)
    rec["minall_s"] = round(time.time() - t0)

    # full FastRelax of both states (the honest, expensive answer) - only for the extreme case
    if alt == "W" and pos == 746:
        t0 = time.time()
        fr = FastRelax(SF, 1)
        a = pw.clone(); fr.apply(a)
        b = pm.clone(); fr.apply(b)
        rec["relax_ddg"] = round(SF(a) - SF(b), 1)
        rec["relax_s"] = round(time.time() - t0)
    out.append(rec)
    print(json.dumps(rec), flush=True)

json.dump(out, open("/tmp/ddg/scale.json", "w"), indent=1)
print("SCALE_DONE")
