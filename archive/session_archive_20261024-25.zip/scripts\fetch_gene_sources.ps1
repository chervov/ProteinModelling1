param($gene, $entrez, $canon, $uniprot)
# Fetch the per-variant public sources for one gene into sources/<gene>/ (ClinVar, gnomAD, cBioPortal, CIViC, LOVD, AlphaMissense, dbNSFP core scores).
$d = Join-Path $PWD "sources\$gene"
New-Item -ItemType Directory -Force $d, "$d\predictors" | Out-Null
& "$PSScriptRoot\clinvar_fetch.ps1" -out "$d\clinvar.json" -gene $gene
& "$PSScriptRoot\gnomad_fetch.ps1" -out "$d\gnomad.json" -gene $gene
& "$PSScriptRoot\cbio_fetch.ps1" -out "$d\cbioportal_raw.csv" -entrez $entrez
& "$PSScriptRoot\civic_fetch.ps1" -out "$d\civic.csv" -gene $gene
$l = Invoke-WebRequest "https://databases.lovd.nl/shared/api/rest.php/variants/$gene`?format=application/json" -UseBasicParsing
[IO.File]::WriteAllText("$d\lovd.json", $l.Content); "LOVD entries: $(@($l.Content | ConvertFrom-Json).Count)"
Invoke-WebRequest "https://alphafold.ebi.ac.uk/files/AF-$uniprot-F1-aa-substitutions.csv" -OutFile "$d\predictors\alphamissense.csv" -UseBasicParsing
"AlphaMissense substitutions: $(@(Import-Csv "$d\predictors\alphamissense.csv").Count)"
& "$PSScriptRoot\dbnsfp_fetch.ps1" -out "$d\predictors\dbnsfp_core.csv" -gene $gene -canon $canon
