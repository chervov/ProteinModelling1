# Drop variants known only from COSMIC from the public alignment report, then push report, position map and sequences.
$f = "$PWD\upload\jak2_priority_variants_paralogs.md"
$t = [IO.File]::ReadAllText($f)
$pat = 'tumour databases\)'
$n0 = ([regex]::Matches($t, $pat)).Count
$t = [regex]::Replace($t, '<br>\*\*[^*]+\*\* \(tumour databases\)', '')
$t = [regex]::Replace($t, '\| \*\*[^*]+\*\* \(tumour databases\)<br>', '| ')
$t = [regex]::Replace($t, '\| \*\*[^*]+\*\* \(tumour databases\)( DMS| \|)', '| none$1')
[IO.File]::WriteAllText($f, $t, (New-Object Text.UTF8Encoding($false)))
$n1 = ([regex]::Matches($t, $pat)).Count
"removed $n0 COSMIC-only entries; remaining: $n1"
(Select-String -Path $f -Pattern '^\| TYK2 \| L866').Line
$p = @{ repo = 'chervov/ProteinModelling1'; branch = 'main'; tokenFile = "$PWD\gh_token.txt" }
& "$PSScriptRoot\gh_put.ps1" @p -local $f -remote 'external_data/jak2_priority_variants_paralogs.md' -message 'Add JAK2 priority variants mapped to JAK1/JAK3/TYK2'
& "$PSScriptRoot\gh_put.ps1" @p -local "$PWD\upload\jak_alignment_position_map.csv" -remote 'external_data/jak_alignment_position_map.csv' -message 'Add JAK2 -> JAK1/JAK3/TYK2 position map'
& "$PSScriptRoot\gh_put.ps1" @p -local "$PWD\upload\jak_sequences.fasta" -remote 'external_data/jak_sequences.fasta' -message 'Add JAK family sequences used for the alignment'
