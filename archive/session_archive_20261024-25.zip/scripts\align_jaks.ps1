param($out)
# Pairwise global alignment (Gotoh, BLOSUM62, gap open 11 / extend 1) of JAK2 against JAK1, JAK3 and TYK2,
# then a position map JAK2 -> paralog residue. Sequences from UniProt (canonical isoforms).
$acc = [ordered]@{ JAK1 = 'P23458'; JAK2 = 'O60674'; JAK3 = 'P52333'; TYK2 = 'P29597' }
$seq = @{}
foreach ($g in $acc.Keys) { $f = Invoke-RestMethod "https://rest.uniprot.org/uniprotkb/$($acc[$g]).fasta"; $seq[$g] = (($f -split "`n") | Select-Object -Skip 1) -join '' }
Add-Type -TypeDefinition @'
using System;
public static class NW {
  static string aa = "ARNDCQEGHILKMFPSTWYVBZX*";
  static int[,] B = {
{4,-1,-2,-2,0,-1,-1,0,-2,-1,-1,-1,-1,-2,-1,1,0,-3,-2,0,-2,-1,0,-4},{-1,5,0,-2,-3,1,0,-2,0,-3,-2,2,-1,-3,-2,-1,-1,-3,-2,-3,-1,0,-1,-4},
{-2,0,6,1,-3,0,0,0,1,-3,-3,0,-2,-3,-2,1,0,-4,-2,-3,3,0,-1,-4},{-2,-2,1,6,-3,0,2,-1,-1,-3,-4,-1,-3,-3,-1,0,-1,-4,-3,-3,4,1,-1,-4},
{0,-3,-3,-3,9,-3,-4,-3,-3,-1,-1,-3,-1,-2,-3,-1,-1,-2,-2,-1,-3,-3,-2,-4},{-1,1,0,0,-3,5,2,-2,0,-3,-2,1,0,-3,-1,0,-1,-2,-1,-2,0,3,-1,-4},
{-1,0,0,2,-4,2,5,-2,0,-3,-3,1,-2,-3,-1,0,-1,-3,-2,-2,1,4,-1,-4},{0,-2,0,-1,-3,-2,-2,6,-2,-4,-4,-2,-3,-3,-2,0,-2,-2,-3,-3,-1,-2,-1,-4},
{-2,0,1,-1,-3,0,0,-2,8,-3,-3,-1,-2,-1,-2,-1,-2,-2,2,-3,0,0,-1,-4},{-1,-3,-3,-3,-1,-3,-3,-4,-3,4,2,-3,1,0,-3,-2,-1,-3,-1,3,-3,-3,-1,-4},
{-1,-2,-3,-4,-1,-2,-3,-4,-3,2,4,-2,2,0,-3,-2,-1,-2,-1,1,-4,-3,-1,-4},{-1,2,0,-1,-3,1,1,-2,-1,-3,-2,5,-1,-3,-1,0,-1,-3,-2,-2,0,1,-1,-4},
{-1,-1,-2,-3,-1,0,-2,-3,-2,1,2,-1,5,0,-2,-1,-1,-1,-1,1,-3,-1,-1,-4},{-2,-3,-3,-3,-2,-3,-3,-3,-1,0,0,-3,0,6,-4,-2,-2,1,3,-1,-3,-3,-1,-4},
{-1,-2,-2,-1,-3,-1,-1,-2,-2,-3,-3,-1,-2,-4,7,-1,-1,-4,-3,-2,-2,-1,-2,-4},{1,-1,1,0,-1,0,0,0,-1,-2,-2,0,-1,-2,-1,4,1,-3,-2,-2,0,0,0,-4},
{0,-1,0,-1,-1,-1,-1,-2,-2,-1,-1,-1,-1,-2,-1,1,5,-2,-2,0,-1,-1,0,-4},{-3,-3,-4,-4,-2,-2,-3,-2,-2,-3,-2,-3,-1,1,-4,-3,-2,11,2,-3,-4,-3,-2,-4},
{-2,-2,-2,-3,-2,-1,-2,-3,2,-1,-1,-2,-1,3,-3,-2,-2,2,7,-1,-3,-2,-1,-4},{0,-3,-3,-3,-1,-2,-2,-3,-3,3,1,-2,1,-1,-2,-2,0,-3,-1,4,-3,-2,-1,-4},
{-2,-1,3,4,-3,0,1,-1,0,-3,-4,0,-3,-3,-2,0,-1,-4,-3,-3,4,1,-1,-4},{-1,0,0,1,-3,3,4,-2,0,-3,-3,1,-1,-3,-1,0,-1,-3,-2,-2,1,4,-1,-4},
{0,-1,-1,-1,-2,-1,-1,-1,-1,-1,-1,-1,-1,-1,-2,0,0,-2,-1,-1,-1,-1,-1,-4},{-4,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4,1}};
  static int S(char a, char b) { int i = aa.IndexOf(a), j = aa.IndexOf(b); if (i < 0) i = 22; if (j < 0) j = 22; return B[i, j]; }
  // returns int[] map: for each position (1-based) in a, the aligned position in b (0 = gap)
  public static int[] Align(string a, string b, int go, int ge) {
    int n = a.Length, m = b.Length; const int NEG = -1000000;
    var M = new int[n + 1, m + 1]; var X = new int[n + 1, m + 1]; var Y = new int[n + 1, m + 1];
    for (int i = 0; i <= n; i++) for (int j = 0; j <= m; j++) { M[i, j] = NEG; X[i, j] = NEG; Y[i, j] = NEG; }
    M[0, 0] = 0;
    for (int i = 1; i <= n; i++) X[i, 0] = -go - (i - 1) * ge;
    for (int j = 1; j <= m; j++) Y[0, j] = -go - (j - 1) * ge;
    for (int i = 1; i <= n; i++) for (int j = 1; j <= m; j++) {
      M[i, j] = Math.Max(M[i - 1, j - 1], Math.Max(X[i - 1, j - 1], Y[i - 1, j - 1])) + S(a[i - 1], b[j - 1]);
      X[i, j] = Math.Max(M[i - 1, j] - go, X[i - 1, j] - ge);
      Y[i, j] = Math.Max(M[i, j - 1] - go, Y[i, j - 1] - ge);
    }
    var map = new int[n + 1]; int ii = n, jj = m;
    int state = (M[n, m] >= X[n, m] && M[n, m] >= Y[n, m]) ? 0 : (X[n, m] >= Y[n, m] ? 1 : 2);
    while (ii > 0 || jj > 0) {
      if (state == 0 && ii > 0 && jj > 0) {
        map[ii] = jj; int prev = M[ii, jj] - S(a[ii - 1], b[jj - 1]);
        state = (prev == M[ii - 1, jj - 1]) ? 0 : (prev == X[ii - 1, jj - 1] ? 1 : 2); ii--; jj--;
      } else if (state == 1 || jj == 0) {
        map[ii] = 0; state = (ii > 1 && X[ii, jj] == M[ii - 1, jj] - go) ? 0 : 1; if (ii == 1) state = (jj > 0) ? 2 : 0; ii--;
      } else { state = (jj > 1 && Y[ii, jj] == M[ii, jj - 1] - go) ? 0 : 2; if (jj == 1) state = (ii > 0) ? 1 : 0; jj--; }
    }
    return map;
  }
}
'@
$rows = New-Object System.Collections.Generic.List[object]
$maps = @{}
foreach ($g in 'JAK1', 'JAK3', 'TYK2') {
  $maps[$g] = [NW]::Align($seq['JAK2'], $seq[$g], 11, 1)
  $m = $maps[$g]; $id = 0; $al = 0
  for ($i = 1; $i -le $seq['JAK2'].Length; $i++) { if ($m[$i] -gt 0) { $al++; if ($seq['JAK2'][$i - 1] -eq $seq[$g][$m[$i] - 1]) { $id++ } } }
  "JAK2 vs ${g}: $al aligned positions, identity $([math]::Round(100 * $id / $al, 1))%"
}
for ($i = 1; $i -le $seq['JAK2'].Length; $i++) {
  $o = [ordered]@{ JAK2_pos = $i; JAK2_aa = $seq['JAK2'][$i - 1] }
  foreach ($g in 'JAK1', 'JAK3', 'TYK2') { $j = $maps[$g][$i]; $o["${g}_pos"] = if ($j) { $j } else { '' }; $o["${g}_aa"] = if ($j) { $seq[$g][$j - 1] } else { '-' } }
  $rows.Add([pscustomobject]$o)
}
$rows | Export-Csv -NoTypeInformation -Encoding UTF8 $out
$seq.GetEnumerator() | ForEach-Object { ">$($_.Key)`n$($_.Value)" } | Out-File -Encoding ascii ($out -replace '\.csv$', '.fasta')
