param($mutants, $classGz, $table)
# Summarise COSMIC JAK1 mutations per protein change and add COSMIC columns after the cBioPortal ones (in place).
$fs = [IO.File]::OpenRead($classGz); $gz = New-Object IO.Compression.GZipStream($fs, [IO.Compression.CompressionMode]::Decompress)
$sr = New-Object IO.StreamReader($gz); $text = $sr.ReadToEnd(); $sr.Close()
$cls = $text | ConvertFrom-Csv -Delimiter "`t"
$site = @{}; foreach ($c in $cls) { $site[$c.COSMIC_PHENOTYPE_ID] = $c.PRIMARY_SITE }

$m = Import-Csv $mutants -Delimiter "`t" | Where-Object { $_.MUTATION_AA -and $_.MUTATION_AA -ne 'p.?' -and $_.MUTATION_AA -notmatch '=$' }
$by = @{}
foreach ($g in ($m | Group-Object { $_.MUTATION_AA -replace '^p\.', '' })) {
  $samples = @($g.Group | Sort-Object COSMIC_SAMPLE_ID -Unique)
  $top = ($samples | Group-Object { $s = $site[$_.COSMIC_PHENOTYPE_ID]; if ($s) { $s } else { 'NS' } } | Sort-Object Count -Descending | Select-Object -First 3 | ForEach-Object { "$($_.Name -replace '_', ' ') ($($_.Count))" }) -join '; '
  $by[$g.Name] = [pscustomobject]@{
    n = $samples.Count; top = $top
    ids = (@($g.Group.LEGACY_MUTATION_ID | Where-Object { $_ -and $_ -ne 'None' } | Select-Object -Unique) | Select-Object -First 3) -join ' | '
  }
}

$rows = @(Import-Csv $table -Encoding UTF8)
$cols = @($rows[0].PSObject.Properties.Name)
$i = [array]::IndexOf($cols, 'cBioPortal top cancer types')
$newCols = $cols[0..$i] + 'COSMIC samples', 'COSMIC top primary sites', 'COSMIC mutation ID' + $cols[($i + 1)..($cols.Count - 1)]
$hit = 0
foreach ($r in $rows) {
  $k = [regex]::Match($r.Variant, '^(?:Known GOF: )?([A-Z*]\d+\S*)$')
  $v = if ($k.Success) { $by[$k.Groups[1].Value] } else { $null }
  if ($v) { $hit++ }
  $r | Add-Member -NotePropertyName 'COSMIC samples' -NotePropertyValue $(if ($v) { $v.n } else { '' })
  $r | Add-Member -NotePropertyName 'COSMIC top primary sites' -NotePropertyValue $(if ($v) { $v.top } else { '' })
  $r | Add-Member -NotePropertyName 'COSMIC mutation ID' -NotePropertyValue $(if ($v) { $v.ids } else { '' })
}
$rows | Select-Object $newCols | Export-Csv -NoTypeInformation -Encoding UTF8 $table
"COSMIC protein changes: $($by.Count); table rows matched: $hit"
$by.GetEnumerator() | Sort-Object { $_.Value.n } -Descending | Select-Object -First 12 | ForEach-Object { "{0,-14} {1,4}  {2}" -f $_.Key, $_.Value.n, $_.Value.top }
