param($table, $am, $dbnsfp)
# Add AlphaMissense (all 19 substitutions) and dbNSFP predictor columns after the gnomAD call column (in place).
$inv = [Globalization.CultureInfo]::InvariantCulture
function Num($s) { $x = 0.0; if ([double]::TryParse([string]$s, [Globalization.NumberStyles]::Float, $inv, [ref]$x)) { $x } else { $null } }
$amClass = @{ LPath = 'likely pathogenic'; Amb = 'ambiguous'; LBen = 'likely benign' }
$amMap = @{}; Import-Csv $am | ForEach-Object { $amMap[$_.protein_variant] = $_ }

# dbNSFP: several DNA changes can give the same protein change; keep the most damaging value per score
$db = @{}
foreach ($g in (Import-Csv $dbnsfp | Group-Object Variant)) {
  $x = $g.Group
  $max = { param($f) ($x | ForEach-Object { Num $_.$f } | Where-Object { $_ -ne $null } | Measure-Object -Maximum).Maximum }
  $min = { param($f) ($x | ForEach-Object { Num $_.$f } | Where-Object { $_ -ne $null } | Measure-Object -Minimum).Minimum }
  $db[$g.Name] = [ordered]@{
    'REVEL' = & $max 'REVEL'; 'CADD phred' = & $max 'CADD_phred'
    'SIFT' = & $min 'SIFT'; 'PolyPhen-2 HVAR' = & $max 'PolyPhen2_HVAR'
    'MetaRNN' = & $max 'MetaRNN'; 'ESM1b' = & $min 'ESM1b'
  }
}
$dbCols = 'REVEL', 'CADD phred', 'SIFT', 'PolyPhen-2 HVAR', 'MetaRNN', 'ESM1b'

$rows = @(Import-Csv $table -Encoding UTF8)
$cols = @($rows[0].PSObject.Properties.Name)
$i = [array]::IndexOf($cols, 'gnomAD')
$add = @('AlphaMissense score', 'AlphaMissense class') + $dbCols
$newCols = $cols[0..$i] + $add + $cols[($i + 1)..($cols.Count - 1)]
$nAm = 0; $nDb = 0
foreach ($r in $rows) {
  $k = [regex]::Match($r.Variant, '^(?:Known GOF: )?([A-Z]\d+[A-Z])$')
  $v = if ($k.Success) { $k.Groups[1].Value } else { '' }
  $a = if ($v) { $amMap[$v] } else { $null }; if ($a) { $nAm++ }
  $r | Add-Member -NotePropertyName 'AlphaMissense score' -NotePropertyValue $(if ($a) { $a.am_pathogenicity } else { '' })
  $r | Add-Member -NotePropertyName 'AlphaMissense class' -NotePropertyValue $(if ($a) { $amClass[$a.am_class] } else { '' })
  $d = if ($v) { $db[$v] } else { $null }; if ($d) { $nDb++ }
  foreach ($c in $dbCols) {
    $val = if ($d -and $d[$c] -ne $null) { ([double]$d[$c]).ToString('0.###', $inv) } else { '' }
    $r | Add-Member -NotePropertyName $c -NotePropertyValue $val
  }
}
$rows | Select-Object $newCols | Export-Csv -NoTypeInformation -Encoding UTF8 $table
"rows: $($rows.Count); with AlphaMissense: $nAm; with dbNSFP: $nDb"
