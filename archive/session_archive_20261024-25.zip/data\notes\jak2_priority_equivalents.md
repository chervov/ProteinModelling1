### JAK2 G571R

```
JAK2  REVGDYGQLHETE  (centre = 571)
JAK1  MDYKDTSEEKKIK  (centre = 612)
JAK3  HEVVD-GEARKTE  (centre = 546)
TYK2  RVEGDRGQ--ELR  (centre = 634)
```

| Gene | Residue | Same substitution | AlphaMissense (same subst.) | Position mean AlphaMissense | Variants reported at this position |
|---|---|---|---|---|---|
| JAK2 | G571 | G571R | 0.27 | 0.35 | **G571R** (gnomAD AC 1; COSMIC 1)<br>**G571S** (ClinVar Conflicting classifications of pathogenicity; gnomAD AC 571; cBio 11; COSMIC 11; OncoKB Likely Neutral/Likely Neutral)<br>**G571A** (gnomAD AC 1)<br>**G571C** (gnomAD AC 1)<br>**G571D** (cBio 1; COSMIC 1)<br>**G571Vfs*10** (gnomAD AC 1) |
| JAK1 | S612 | S612R | 0.13 | 0.09 | **S612A** (cBio 2)<br>**S612F** (cBio 2) |
| JAK3 | G546 | G546R | 0.12 | 0.21 | **G546E** (gnomAD AC 6)<br>**G546R** (gnomAD AC 1; cBio 1)<br>**G546W** (gnomAD AC 1) |
| TYK2 | G634 | G634R | 0.11 | 0.14 | **G634E** (ClinVar Likely benign; gnomAD AC 123)<br>**G634A** (gnomAD AC 22)<br>**G634W** (gnomAD AC 1) DMS signalling: same substitution -0.05 +- 0.25; range at position -2.44 to 0.67. |

### JAK2 V578I

```
JAK2  QLHETEVLLKVLD  (centre = 578)
JAK1  EEKKIKVILKVLD  (centre = 619)
JAK3  EARKTEVLLKVMD  (centre = 553)
TYK2  Q--ELRVVLKVLD  (centre = 639)
```

| Gene | Residue | Same substitution | AlphaMissense (same subst.) | Position mean AlphaMissense | Variants reported at this position |
|---|---|---|---|---|---|
| JAK2 | V578 | V578I | 0.24 | 0.89 | **V578I** (gnomAD AC 1)<br>**V578F** (ClinVar Uncertain significance; gnomAD AC 2) |
| JAK1 | V619 | V619I | 0.36 | 0.93 | none |
| JAK3 | V553 | V553I | 0.20 | 0.83 | **V553fs** (ClinVar Likely pathogenic)<br>**V553M** (gnomAD AC 1) |
| TYK2 | V639 | V639I | 0.33 | 0.87 | none DMS signalling: same substitution -0.09 +- 0.27; range at position -2.47 to 0.67. |

### JAK2 L805I

```
JAK2  RAIIRDLNSLFTP  (centre = 805)
JAK1  RAIMRDINKLEEQ  (centre = 845)
JAK3  RAVIRDLNSLISS  (centre = 777)
TYK2  RTILRDLTRLQPH  (centre = 866)
```

| Gene | Residue | Same substitution | AlphaMissense (same subst.) | Position mean AlphaMissense | Variants reported at this position |
|---|---|---|---|---|---|
| JAK2 | L805 | L805I | 0.15 | 0.83 | **L805I** (gnomAD AC 15; cBio 1) |
| JAK1 | I845 | already I | - | 0.82 | **I845del** (cBio 2)<br>**I845V** (ClinVar Uncertain significance; gnomAD AC 12) |
| JAK3 | L777 | L777I | 0.11 | 0.80 | **L777F** (gnomAD AC 1)<br>**L777P** (gnomAD AC 2; cBio 1) |
| TYK2 | L866 | L866I | 0.11 | 0.70 | **L866F** (gnomAD AC 1)<br>**L866H** (COSMIC 1)<br>**L866I** (COSMIC 1) DMS signalling: same substitution 0.57 +- 0.33; range at position -2.79 to 0.57. |

### JAK2 V1110E

```
JAK2  ECWNNNVNQRPSF  (centre = 1110)
JAK1  KCWEFQPSNRTSF  (centre = 1136)
JAK3  LCWAPSPQDRPSF  (centre = 1082)
TYK2  NCWETEASFRPTF  (centre = 1156)
```

| Gene | Residue | Same substitution | AlphaMissense (same subst.) | Position mean AlphaMissense | Variants reported at this position |
|---|---|---|---|---|---|
| JAK2 | V1110 | V1110E | 0.29 | 0.23 | **V1110E** ()<br>**V1110I** (cBio 1; COSMIC 2)<br>**V1110L** (gnomAD AC 2; cBio 1; COSMIC 1) |
| JAK1 | P1136 | P1136E | 0.69 | 0.68 | **P1136S** (gnomAD AC 1) |
| JAK3 | P1082 | P1082E | 0.47 | 0.38 | **P1082L** (cBio 2; COSMIC 1)<br>**P1082S** (COSMIC 1)<br>**P1082T** (gnomAD AC 1) |
| TYK2 | A1156 | A1156E | 0.46 | 0.46 | **A1156V** (gnomAD AC 14; cBio 2; COSMIC 2) DMS signalling: same substitution -0.08 +- 0.35; range at position -2.31 to 0.34. |

