param($expr, $sample = 'SARC9371_BONE', $lineage = '_BONE')
# Rank one CCLE line's JAK/STAT gene expression within its lineage and across all lines.
$rows = Import-Csv $expr
$byGene = @{}
foreach ($r in $rows) { if (-not $byGene[$r.gene]) { $byGene[$r.gene] = @{} }; $byGene[$r.gene][$r.sampleId] = [double]$r.value }
$allS = @($rows | Select-Object -Unique sampleId | ForEach-Object { $_.sampleId })
$lin = @($allS | Where-Object { $_ -like "*$lineage" })
"$sample present: $($allS -contains $sample); lineage lines with expression: $($lin.Count); all lines: $($allS.Count)"
function Pct($vals, $v) { if (-not $vals.Count) { return $null }; [math]::Round(100 * (@($vals | Where-Object { $_ -lt $v }).Count) / $vals.Count, 0) }
$ctrl = 'HEL_HAEMATOPOIETIC_AND_LYMPHOID_TISSUE', 'SET2_HAEMATOPOIETIC_AND_LYMPHOID_TISSUE'
$out = foreach ($g in ($byGene.Keys | Sort-Object)) {
  $h = $byGene[$g]
  $v = $h[$sample]; if ($v -eq $null) { continue }
  $linV = @($lin | Where-Object { $h.ContainsKey($_) } | ForEach-Object { $h[$_] })
  $allV = @($h.Values)
  $med = ($linV | Measure-Object -Average).Average
  $sd = if ($linV.Count -gt 1) { [math]::Sqrt((($linV | ForEach-Object { ($_ - $med) * ($_ - $med) } | Measure-Object -Sum).Sum) / ($linV.Count - 1)) } else { 0 }
  [pscustomobject]@{
    Gene = $g
    Value = [math]::Round($v, 2)
    'Lineage mean' = [math]::Round($med, 2)
    'Z (lineage)' = if ($sd -gt 0) { [math]::Round(($v - $med) / $sd, 2) } else { '-' }
    'Pct in lineage' = Pct $linV $v
    'Pct in all lines' = Pct $allV $v
    'HEL pct(all)' = Pct $allV $h[$ctrl[0]]
    'SET2 pct(all)' = Pct $allV $h[$ctrl[1]]
  }
}
$out | Format-Table -AutoSize | Out-String -Width 200
$sets = [ordered]@{
  'STAT5 targets (GOF markers)' = 'CISH', 'SOCS1', 'SOCS2', 'SOCS3', 'PIM1', 'BCL2L1', 'MYC', 'CCND1', 'ID1', 'OSM', 'MCL1'
  'IFN-gamma response (LOF markers)' = 'GBP1', 'CXCL9', 'CXCL10', 'IRF1', 'STAT1', 'B2M', 'TAP1', 'HLA-DRA', 'HLA-A'
  'Receptors / pathway input' = 'EPOR', 'MPL', 'CSF2RB', 'IL3RA', 'IFNGR1', 'IL6ST', 'IFNAR1'
  'Negative regulators' = 'PTPN1', 'PTPN2', 'PTPN6', 'PTPN11', 'SH2B3'
}
"`nSet means of lineage z-score (and median percentile in lineage):"
foreach ($k in $sets.Keys) {
  $sel = @($out | Where-Object { $sets[$k] -contains $_.Gene -and $_.'Z (lineage)' -ne '-' })
  $z = ($sel | ForEach-Object { [double]$_.'Z (lineage)' } | Measure-Object -Average).Average
  $p = @($sel | ForEach-Object { [int]$_.'Pct in lineage' } | Sort-Object)[[int]($sel.Count / 2)]
  "  {0,-34} n={1,2}  mean z = {2,6}  median pct = {3}" -f $k, $sel.Count, [math]::Round($z, 2), $p
}
