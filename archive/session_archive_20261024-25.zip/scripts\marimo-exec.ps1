param(
  [Parameter(Mandatory = $true)][string]$Url,
  [string]$Code,
  [string]$File,          # path to a .py file holding the code
  [string]$Session,
  [string]$FileKey,       # marimo notebook file key, to pick among sessions
  [string]$TokenFile = "$PSScriptRoot\..\molab_token.txt"
)
# PowerShell port of the marimo-pair skill's execute-code.sh: run code in a live marimo
# kernel's scratchpad over the HTTP API. Needed because this machine has no usable bash.
$ErrorActionPreference = 'Stop'
if (-not $Code) {
  if (-not $File) { throw 'Pass -Code or -File.' }
  $Code = [IO.File]::ReadAllText($File, [Text.Encoding]::UTF8)
}
$base = $Url.TrimEnd('/')
$headers = @{ 'User-Agent' = 'claude-marimo-pair' }
if (Test-Path $TokenFile) {
  $tok = (Get-Content -Raw $TokenFile).Trim()
  if ($tok) { $headers['Authorization'] = "Bearer $tok" }
}
# 1. resolve the session
if ($Session) { $sid = $Session }
else {
  # the box can be slow to answer while a detached job pins the CPU, so retry with a long timeout
  $sessions = $null
  foreach ($try in 1..3) {
    try { $sessions = Invoke-RestMethod "$base/api/sessions" -Headers $headers -TimeoutSec 120; break }
    catch { if ($try -eq 3) { throw "Failed to connect to marimo server at ${base}: $($_.Exception.Message)" }; Start-Sleep 15 }
  }
  $ids = @($sessions.PSObject.Properties.Name)
  if (-not $ids.Count) { throw 'No active sessions on the server. Open the notebook in the browser.' }
  if ($FileKey) {
    $ids = @($sessions.PSObject.Properties | Where-Object { $_.Value.path -eq $FileKey -or $_.Value.filename -eq $FileKey } | ForEach-Object { $_.Name })
    if (-not $ids.Count) { throw "No active session matches -FileKey '$FileKey'." }
  }
  if ($ids.Count -gt 1) {
    $sessions.PSObject.Properties | ForEach-Object { Write-Host "  $($_.Name)  $($_.Value.path)" }
    throw 'Multiple sessions on server; pass -FileKey or -Session.'
  }
  $sid = $ids[0]
}
# 2. execute, reading the SSE stream
$h2 = $headers.Clone(); $h2['Marimo-Session-Id'] = $sid; $h2['Content-Type'] = 'application/json'
$body = (@{ code = $Code } | ConvertTo-Json -Compress -Depth 5)
$req = [Net.HttpWebRequest]::Create("$base/api/kernel/execute")
$req.Method = 'POST'; $req.ContentType = 'application/json'; $req.Timeout = 2700000; $req.ReadWriteTimeout = 2700000
foreach ($k in $h2.Keys) { if ($k -notin 'Content-Type', 'User-Agent') { $req.Headers.Add($k, $h2[$k]) } }
$req.UserAgent = 'claude-marimo-pair'
$bytes = [Text.Encoding]::UTF8.GetBytes($body)
$req.ContentLength = $bytes.Length
$s = $req.GetRequestStream(); $s.Write($bytes, 0, $bytes.Length); $s.Close()
try { $resp = $req.GetResponse() }
catch [Net.WebException] {
  $r = $_.Exception.Response
  if ($r) { $sr = New-Object IO.StreamReader($r.GetResponseStream()); throw "HTTP error: $($sr.ReadToEnd())" }
  throw
}
$reader = New-Object IO.StreamReader($resp.GetResponseStream(), [Text.Encoding]::UTF8)
$event = ''; $done = $false; $failed = $false; $unparsed = ''
while (-not $reader.EndOfStream -and -not $done) {
  $line = $reader.ReadLine()
  if ($line -eq $null) { break }
  $line = $line.TrimEnd("`r")
  if ($line -like 'event:*') { $event = $line.Substring(6).Trim(); continue }
  if ($line -eq '') { continue }
  if ($line -like 'data:*') {
    $payload = $line.Substring(5).TrimStart()
    try { $o = $payload | ConvertFrom-Json } catch { $unparsed += "$payload`n"; continue }
    switch ($event) {
      'stdout' { Write-Output $o.data.TrimEnd("`n") }   # pipeline, so callers can capture it
      'stderr' { [Console]::Error.Write($o.data) }
      'done' {
        $done = $true
        if ($o.success -eq $false) { $failed = $true } elseif ($o.output.data) { Write-Output $o.output.data }
      }
    }
    continue
  }
  $unparsed += "$line`n"
}
$reader.Close(); $resp.Close()
if (-not $done) { Write-Error "Execution did not complete.`n$unparsed"; exit 1 }
if ($failed) { exit 1 }
