param($table, $civic, $sources)
# Add a "CIViC evidence" column right after DRUG, and append rows for CIViC variants not yet in the table.
$lvl = @{ A = 'validated'; B = 'clinical'; C = 'case study'; D = 'preclinical'; E = 'inferential' }
function Fmt($e) {
  $sig = ($e.Significance -replace 'SENSITIVITYRESPONSE', 'sensitivity' -replace '_', ' ').ToLower()
  $dir = if ($e.Direction -eq 'DOES_NOT_SUPPORT') { 'NOT ' } else { '' }
  $what = if ($e.Type -eq 'PREDICTIVE') { "$($e.Therapies): $dir$sig" } else { "Functional: $dir$sig" }
  $dis = if ($e.Disease) { ", $($e.Disease)" } else { '' }
  "$what$dis (level $($e.Level) $($lvl[$e.Level]), $($e.Status.ToLower()), $($e.EID))"
}
$ev = Import-Csv $civic
$byVar = @{}; foreach ($g in ($ev | Group-Object Variant)) { $byVar[$g.Name] = (($g.Group | Sort-Object Type -Descending | ForEach-Object { Fmt $_ }) -join '; ') }

$rows = @(Import-Csv $table -Encoding UTF8)
$cols = @($rows[0].PSObject.Properties.Name)
$i = [array]::IndexOf($cols, 'DRUG')
$newCols = $cols[0..$i] + 'CIViC evidence' + $cols[($i + 1)..($cols.Count - 1)]
$seen = @{}; $hit = 0
foreach ($r in $rows) {
  $m = [regex]::Match($r.Variant, '^(?:Known GOF: )?([A-Z*]\d+\S*)$')
  $val = ''
  if ($m.Success) { $seen[$m.Groups[1].Value] = $true; if ($byVar.ContainsKey($m.Groups[1].Value)) { $val = $byVar[$m.Groups[1].Value]; $hit++ } }
  $r | Add-Member -NotePropertyName 'CIViC evidence' -NotePropertyValue $val
}

# Rows for CIViC entries not in the table (specific variants plus gene-level entries)
$src = @{}; Import-Csv $sources | ForEach-Object { $src[$_.Variant] = $_ }
$label = @{ 'Mutation' = 'JAK1 mutation (any; gene-level CIViC entry)'; 'OVEREXPRESSION' = 'JAK1 overexpression (gene-level CIViC entry)' }
$extra = New-Object System.Collections.Generic.List[object]
$blank = { $o = [ordered]@{}; foreach ($c in $newCols) { $o[$c] = '' }; $o }
$h = & $blank; $h['Variant'] = 'SECTION: CIVIC - VARIANTS WITH DRUG/FUNCTIONAL EVIDENCE NOT PREVIOUSLY IN TABLE'; $extra.Add([pscustomobject]$h)
foreach ($v in ($byVar.Keys | Where-Object { -not $seen[$_] } | Sort-Object { $m = [regex]::Match($_, '\d+'); if ($m.Success) { [int]$m.Value } else { 99999 } })) {
  $o = & $blank
  $o['Variant'] = if ($label.ContainsKey($v)) { $label[$v] } else { $v }
  $o['CIViC evidence'] = $byVar[$v]
  if ($src.ContainsKey($v)) {
    $s = $src[$v]
    $o['Cluster'] = $s.'EV1 cluster'
    foreach ($c in 'gnomAD allele count','gnomAD AF','gnomAD homozygotes','cBioPortal patients','cBioPortal studies','cBioPortal top cancer types','OncoKB oncogenic','OncoKB mutation effect','LOVD entries','LOVD reported effect','DECIPHER') { $o[$c] = $s.$c }
    if ($s.ClinVar) { $o['ClinVar'] = $s.ClinVar; $o['Review status'] = $s.'ClinVar review' }
    $af = 0.0; [void][double]::TryParse($s.'gnomAD AF', [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$af)
    $o['gnomAD'] = if ($af -ge 1e-4 -or [int]('0' + $s.'gnomAD homozygotes') -ge 1) { '1' } else { '2' }
  }
  $extra.Add([pscustomobject]$o)
}
($rows | Select-Object $newCols) + $extra | Export-Csv -NoTypeInformation -Encoding UTF8 $table
"existing rows with CIViC evidence: $hit; new rows: $($extra.Count - 1) ($((($extra | Select-Object -Skip 1).Variant) -join ', '))"
