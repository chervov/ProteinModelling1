# Add an OMIM row to each gene summary, then push the OMIM files and the updated variant tables.
$counts = @{ JAK1 = '4 allelic variants (A634D, S703I, H596D, P733L+P832S)'; JAK2 = '5 allelic variants (V617F, K607N, K539L, V617I, R715T)'
             JAK3 = '7 allelic variants (5 with a simple protein change)'; TYK2 = '12 allelic variants (7 with a simple protein change)' }
$mim = @{ JAK1 = '147795'; JAK2 = '147796'; JAK3 = '600173'; TYK2 = '176941' }
foreach ($g in 'JAK2', 'JAK3', 'TYK2') {
  $f = "$PWD\upload\$g\$($g.ToLower())_sources_summary.md"
  $t = [IO.File]::ReadAllText($f)
  if ($t -match 'OMIM allelic') { "$g summary: already mentions OMIM"; continue }
  $row = "| 14 | OMIM (MIM $($mim[$g])) | Curated, literature-backed disease variants | $($counts[$g]) | ``OMIM allelic variant`` column |`r`n"
  $t = $t -replace '(?m)^(\| - \| Dataset EV1)', ($row + '$1')
  [IO.File]::WriteAllText($f, $t, (New-Object Text.UTF8Encoding($false)))
  "$g summary: OMIM row added"
}
$p = @{ repo = 'chervov/ProteinModelling1'; branch = 'main'; tokenFile = "$PWD\gh_token.txt" }
& "$PSScriptRoot\gh_put.ps1" @p -local "$PWD\sources\omim\omim_allelic_variants.csv" -remote 'external_data/omim_allelic_variants.csv' -message 'Add OMIM allelic variants for JAK1/JAK2/JAK3/TYK2'
& "$PSScriptRoot\gh_put.ps1" @p -local "$PWD\upload\JAK2\jak2_omim.md" -remote 'external_data/JAK2/jak2_omim.md' -message 'Add JAK2 OMIM allelic variants and R715T analysis (Song et al. 2024)'
foreach ($g in 'JAK2', 'JAK3', 'TYK2') {
  $lc = $g.ToLower()
  foreach ($n in 'sources_summary.md', 'variants_inf.csv', 'variants_inf_predict.csv', 'variants_inf_predict_ext.csv') {
    $f = "${lc}_$n"
    & "$PSScriptRoot\gh_put.ps1" @p -local "$PWD\upload\$g\$f" -remote "external_data/$g/$f" -message "$g ${f}: add OMIM allelic variant column"
  }
}
foreach ($n in 'variants_inf.csv', 'variants_inf_predict.csv', 'variants_inf_predict_ext.csv') {
  & "$PSScriptRoot\gh_put.ps1" @p -local "$PWD\upload\jak1_$n" -remote "external_data/JAK1/jak1_$n" -message "JAK1 jak1_${n}: add OMIM allelic variant column"
}
