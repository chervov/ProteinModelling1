param($repo, $branch, $local, $remote, $message, $tokenFile)
# Create or update one file in a GitHub repo via the contents API. The token is read from a file and never printed.
$t = (Get-Content $tokenFile -Raw).Trim()
$h = @{ Authorization = "Bearer $t"; 'User-Agent' = 'claude'; Accept = 'application/vnd.github+json' }
$bytes = [IO.File]::ReadAllBytes($local)
if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) { $bytes = $bytes[3..($bytes.Length - 1)] }  # strip UTF-8 BOM
$body = @{ message = $message; content = [Convert]::ToBase64String($bytes); branch = $branch }
$url = "https://api.github.com/repos/$repo/contents/$remote"
try { $cur = Invoke-RestMethod "$url`?ref=$branch" -Headers $h; $body.sha = $cur.sha } catch { }
# GitHub's ruleset check sometimes times out (403/500) on the first attempt, so retry a few times
for ($try = 1; $try -le 4; $try++) {
  try { $r = Invoke-RestMethod -Method Put -Uri $url -Headers $h -ContentType 'application/json' -Body ($body | ConvertTo-Json); break }
  catch { if ($try -eq 4) { throw }; Write-Warning "attempt $try failed: $($_.Exception.Message); retrying"; Start-Sleep -Seconds (3 * $try) }
}
"$(if ($body.sha) { 'updated' } else { 'created' }): $($r.content.html_url) (commit $($r.commit.sha.Substring(0,7)))"
