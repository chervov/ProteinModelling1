import marimo._code_mode as cm
import sys, platform, shutil, os, urllib.request, json

ctx = cm.get_context()
print("cells:", len(list(ctx.cells.keys())))
for c in ctx.cells:
    body = (c.code or "").strip().replace("\n", " ⏎ ")
    print(f"  [{c.id}] {c.name or '-'} :: {body[:110]}")
print("globals (non-private):", sorted(k for k in ctx.globals if not k.startswith("_"))[:40])

print("\npython:", sys.version.split()[0], "|", platform.platform(), "|", platform.machine())
print("cpus:", os.cpu_count())
try:
    import subprocess
    print("mem:", subprocess.run(["free", "-h"], capture_output=True, text=True).stdout.splitlines()[1])
    print("disk:", subprocess.run(["df", "-h", "/"], capture_output=True, text=True).stdout.splitlines()[1])
except Exception as e:
    print("sys info failed:", e)
print("uv:", shutil.which("uv"), "| pip:", shutil.which("pip"))

# internet?
for url in ("https://pypi.org/simple/pyrosetta-installer/", "https://files.rcsb.org/download/4OLI.pdb"):
    try:
        with urllib.request.urlopen(url, timeout=20) as r:
            print(f"OK   {r.status}  {url}")
    except Exception as e:
        print(f"FAIL       {url} -> {type(e).__name__}: {e}")
