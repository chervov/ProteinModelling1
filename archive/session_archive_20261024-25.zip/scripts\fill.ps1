param($in, $lookup, $out)
$map = @{}
Import-Csv $lookup | ForEach-Object { if ($_.variant_id -match '^[A-Z]\d+[A-Z]$') { $map[$_.variant_id] = $_.cluster } }
$utf8 = New-Object System.Text.UTF8Encoding($false)
$lines = [IO.File]::ReadAllLines($in, $utf8)
$rows = Import-Csv $in -Encoding UTF8
$report = New-Object System.Collections.Generic.List[object]
for ($i = 0; $i -lt $rows.Count; $i++) {
  $r = $rows[$i]; $line = $lines[$i + 1]
  $m = [regex]::Match($r.Variant, '\b([A-Z]\d+[A-Z])\b')
  $key = if ($m.Success) { $m.Groups[1].Value } else { $null }
  $found = if ($key) { $map[$key] } else { $null }
  if ($r.Cluster -eq 'Pending lookup') {
    if ($found) { $lines[$i + 1] = $line.Replace(',Pending lookup,', ",$found,"); $status = 'FILLED' } else { $status = 'NOT FOUND' }
    $report.Add([pscustomobject]@{Variant=$r.Variant; Old=$r.Cluster; New=$found; Status=$status})
  } elseif ($r.Cluster -match '^\d$') {
    $status = if (-not $found) { 'existing, not in EV1' } elseif ($found -eq $r.Cluster) { 'existing, matches' } else { 'existing, MISMATCH' }
    $report.Add([pscustomobject]@{Variant=$r.Variant; Old=$r.Cluster; New=$found; Status=$status})
  }
}
[IO.File]::WriteAllLines($out, $lines, $utf8)
$report | Format-Table -AutoSize | Out-String -Width 200
