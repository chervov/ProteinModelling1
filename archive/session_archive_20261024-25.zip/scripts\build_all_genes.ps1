# Build the variant tables for JAK2, JAK3 and TYK2 (priority variants on top). Domains are UniProt boundaries.
$cls = (Get-ChildItem "$PWD\sources\cosmic\cls" -Filter *.tsv.gz | Select-Object -First 1).FullName
$genes = @(
  @{ gene = 'JAK2'; nm = 'NM_004972'; priority = @('V1110E', 'G571R', 'V578I', 'L805I')
     domains = [ordered]@{ FERM = @(37, 380); 'SH2-like' = @(401, 482); JH2 = @(545, 809); JH1 = @(849, 1124) } },
  @{ gene = 'JAK3'; nm = 'NM_000215'; priority = @('Y581C')
     domains = [ordered]@{ FERM = @(24, 356); 'SH2-like' = @(375, 475); JH2 = @(521, 781); JH1 = @(822, 1111) }
     decipher = @{ 'Q39Sfs*108' = 'homozygous, pathogenic (SCID), 1 open-access patient' } },
  @{ gene = 'TYK2'; nm = 'NM_003331'; priority = @('V678M', 'P982A')
     domains = [ordered]@{ FERM = @(26, 431); 'SH2-like' = @(450, 529); JH2 = @(589, 875); JH1 = @(897, 1176) } }
)
foreach ($x in $genes) {
  $cos = "$PWD\sources\$($x.gene)\cosmic_mutantcensus.tsv"
  $args = @{ gene = $x.gene; nm = $x.nm; priority = $x.priority; domains = $x.domains; outDir = "$PWD\upload\$($x.gene)" }
  if (Test-Path $cos) { $args.cosmic = $cos; $args.classGz = $cls }
  if ($x.decipher) { $args.decipher = $x.decipher }
  & "$PSScriptRoot\build_gene_tables.ps1" @args
}
