param($orig, $section, $out)
# Insert the section (read as UTF-8 from its own file, so no encoding loss) before the data footer.
$utf8 = New-Object Text.UTF8Encoding($false)
$t = [IO.File]::ReadAllText($orig, [Text.Encoding]::UTF8)
$sec = [IO.File]::ReadAllText($section, [Text.Encoding]::UTF8)
if ($t -match '## 8\. Published context') { 'already present'; return }
$marker = '*Data: `data/ddg/ddg_TYK2_all.json`'
$i = $t.IndexOf($marker)
if ($i -lt 0) { throw 'footer marker not found' }
$res = $t.Substring(0, $i).TrimEnd() + "`r`n`r`n" + $sec.Trim() + "`r`n`r`n" + $t.Substring($i)
[IO.File]::WriteAllText($out, $res, $utf8)
"written: $([math]::Round((Get-Item $out).Length/1KB)) KB"
